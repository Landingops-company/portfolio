<!DOCTYPE html>
<html lang="ko">
<head>
<title>법무법인 글로리</title>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="format-detection" content="telephone=no"/>
	<meta name="description" content="법무법인 글로리 홈페이지 입니다" />
	<meta name="keywords" content="법무법인 글로리, 글로리, 대전이혼전문변호사, 개인회생, 대전개인회생,  이혼전문변호사, 대전, 법무법인, 글로리" />

	<meta property="og:type" content="website">
	<meta property="og:title" content="법무법인 글로리">
	<meta property="og:description" content="법무법인 글로리 홈페이지 입니다">

	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, minimum-scale=1.0, user-scalable=no" />
	<link href="https://fonts.googleapis.com/css2?family=Noto+Serif+KR:wght@200;300;400;500;600;700;900&display=swap" rel="stylesheet"><!-- font-family: 'Noto Serif KR', serif; -->

	<!-- font -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;500;600;700;800;900&family=Montserrat:wght@100;200;300;400;500;600;700;800;900&family=Nanum+Myeongjo:wght@400;700;800&display=swap" rel="stylesheet">

	<link href="../css/base.css?230830" rel="stylesheet" type="text/css" />
	<link href="../css/common.css?230830" rel="stylesheet" type="text/css" />
	<link href="../css/main.css?230830" rel="stylesheet" type="text/css" />
	<link href="../css/sub.css?230830" rel="stylesheet" type="text/css" />
	<link href="../css/board.css?230830" rel="stylesheet" type="text/css" />
    <link rel="shortcut icon" href="../images/favicon.ico" type="image/x-icon">
	<!--[if lt IE 9]>
		<script src="../js/html5shiv.js"></script>
		<script src="../js/respond.min.js"></script>
		<script type="text/javascript">
			alert('현재 업데이트의 지원이 중단되어 보안이 취약한 하위버전의 브라우저를 사용하고 계십니다.\n원활한 사이트 이용을 위해서는 Internet Explorer 최신 버전으로 업데이트 하시거나,\n타 브라우저 (구글 크롬, 파이어폭스, 네이버 웨일) 사용을 권장합니다.');
		</script>
	<![endif]-->

	<!-- Google Tag Manager -->
	<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
	new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
	j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
	'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
	})(window,document,'script','dataLayer','GTM-5G8269NP');</script>
	<!-- End Google Tag Manager -->

	<script src="../js/jquery-3.7.0.min.js"></script>
	<script src="../js/slick.min.js"></script>
	<script src="../js/common.js"></script>

	<!-- aos -->
	<link href="../css/aos.css" rel="stylesheet" type="text/css" />
	<script src="../js/aos.js"></script>

	<meta name="naver-site-verification" content="2f95426658d0c9954d3c8c8822f0aecc856dd101" />
<meta name="google-site-verification" content="xMd0V-C2YI-S5zDVVCNYLFLwDSwEHHBEzqDG_Jrz6HE" />
<meta name="google-site-verification" content="xMd0V-C2YI-S5zDVVCNYLFLwDSwEHHBEzqDG_Jrz6HE" />	
	<!-- Danggeun Market Code -->
	<script src="https://karrot-pixel.business.daangn.com/0.2/karrot-pixel.umd.js"></script>
	<script>
	window.karrotPixel.init('1724042065698400001');
	window.karrotPixel.track('ViewPage');
	</script>
	<!-- End Danggeun Market Code -->
	<!-- Danggeun Market Code -->
	<script src="https://karrot-pixel.business.daangn.com/0.4/karrot-pixel.umd.js"></script>
	<script>
	  window.karrotPixel.init('1738542627560100001');
	  window.karrotPixel.track('ViewPage');
	</script>
	<!-- End Danggeun Market Code -->

</head>

<body id="sub">

	<!-- Google Tag Manager (noscript) -->
	<noscript>
	<iframe	src="https://www.googletagmanager.com/ns.html?id=GTM-5G8269NP"	height="0" width="0" style="display:none;visibility:hidden"></iframe>
	</noscript>
	<!-- End Google Tag Manager (noscript) -->

	<div id="skipNavi">
		<ul>
			<li>
				<a href="#container">본문 바로가기</a>
				<a href="#gnb">주메뉴 바로가기</a>
			</li>
		</ul>
	</div>

	<div id="wrap">
		<header id="header" class="type3">
			<div class="h_top">
				<div class="h_inner">
					<ul class="l_bx">
						<li><a href="../main/">홈페이지</a></li>
						<li><a href="../revive/">글로리 회생센터</a></li>
						<li><a href="../divorce/" class="col2">글로리 이혼센터</a></li>
						<li><a href="https://glorylawfirm-crime.com/" target="_blank">글로리 형사센터</a></li>
					</ul>
					<ul class="r_bx">
						<li class="en">Law&amp;Firm Glory</li>
						<!-- <li><a href="tel:1544-0904" class="en col2">1544-0904(대표번호) / 042-721-0608(회생파산) / 042-721-0606(송무)</a></li> -->
						<li><a href="tel:1544-0904" class="en col2">1544-0904(대표번호) / 02-6954-0478(서울회생파산) / 02-6954-0378(서울송무) / 042-721-0608(대전회생파산) / 042-721-0606(대전송무)</a></li>
					</ul>
				</div>
			</div>
			<div class="h_btm">
				<div class="h_inner">
					<a href="../main/" class="logo">법무법인 글로리</a>

					<div class="menu_bx">
						<ul class="dep1_wrap">
							<li class="dep1 dep01 a_none">
								<a href="../main/">공식 홈페이지</a>
							</li>
							<li class="dep1 dep02 a_none">
								<a href="../divorce/#divorce_02">글로리의 약속</a>
							</li>
							<li class="dep1 dep03 a_none">
								<a href="../divorce/#divorce_03"> 이혼절차</a>
							</li>
							<li class="dep1 dep04 a_none">
								<a href="../divorce/#divorce_04">성공사례 </a>
							</li>
							<li class="dep1 dep05 a_none">
								<a href="../divorce/#divorce_05">상담신청</a>
							</li>
						</ul>
					</div>

					<div class="r_bx">
						<div class="lang">
							<div class="on_t">KOR</div>
							<ul>
								<li><a href="#">KOR</a></li>
								<li><a href="#">ENG</a></li>
							</ul>
						</div>

						<div class="menu_btn m_show">
							<span></span>
							<span></span>
							<span></span>
						</div>
					</div>
				</div>
			</div>

			<div class="sm_bx">
				<div class="sm_w">
					<div class="m_top m_show">
						<ul>
							<li><a href="../main/" class="col2">홈페이지</a></li>
							<li><a href="../revive/">글로리 회생센터</a></li>
							<li><a href="../divorce/">글로리 이혼센터</a></li>
							<li><a href="https://glorylawfirm-crime.com/" target="_blank">글로리 형사센터</a></li>
						</ul>
					</div>
					<div class="sm_inner"></div>
				</div>
			</div>
		</header><!-- //header -->

		<script type="text/javascript">
			$("#header.type3 .menu_bx .dep02 > a").click(function(){
				$('html, body').animate({
					scrollTop: $('#divorce_02').offset().top - 70
				}, 700);
				return false;
			});

			$("#header.type3 .menu_bx .dep03 > a").click(function(){
				$('html, body').animate({
					scrollTop: $('#divorce_03').offset().top - 70
				}, 700);
				return false;
			});

			$("#header.type3 .menu_bx .dep04 > a").click(function(){
				$('html, body').animate({
					scrollTop: $('#divorce_04').offset().top - 70
				}, 700);
				return false;
			});

			$("#header.type3 .menu_bx .dep05 > a").click(function(){
				$('html, body').animate({
					scrollTop: $('#divorce_05').offset().top - 70
				}, 700);
				return false;
			});

			function mMenuT() {
				$("#header.type3 .sm_bx .dep02 > a").click(function(){
					$('html, body').animate({
						scrollTop: $('#divorce_02').offset().top
					}, 700);

					$("#header .menu_btn").trigger("click");

					return false;
				});

				$("#header.type3 .sm_bx .dep03 > a").click(function(){
					$('html, body').animate({
						scrollTop: $('#divorce_03').offset().top
					}, 700);

					$("#header .menu_btn").trigger("click");

					return false;
				});

				$("#header.type3 .sm_bx .dep04 > a").click(function(){
					$('html, body').animate({
						scrollTop: $('#divorce_04').offset().top
					}, 700);

					$("#header .menu_btn").trigger("click");

					return false;
				});

				$("#header.type3 .sm_bx .dep05 > a").click(function(){
					$('html, body').animate({
						scrollTop: $('#divorce_05').offset().top
					}, 700);

					$("#header .menu_btn").trigger("click");

					return false;
				});
			}
		</script>

		<link href="../css/sub_divorce.css" rel="stylesheet" type="text/css">

		<div id="container">
			<div class="divorce_case">
				<div id="board">
										<div class="tit_bx">
						<strong>이혼/가사 성공사례</strong>
						<p>글로리 이혼의 다양한 사례들을 한눈에 확인할 수 있도록 <br class="m_show"/>주제 및 키워드별로 정리하였습니다.</p>
					</div>
										<script type="text/javascript" src="/se2/js/HuskyEZCreator.js" charset="utf-8"></script>

<div class="caseList">
		<ul>
			
    	<li>
        	<div class="bx">
        		<div class="tit">
        			<p>대전변호사 혼인 당시 재산 0원, 8년간 전업주부, 이혼 시 재산분할을 받을 수 있을까?</p>
        		</div>
        		<div class="txt">
        			<p>전업주부의 가사노동에 대한 기여도를 인정받고 재산분할을 청구한 사례</p>
        			<a href="/kor/divorce/case_list.php?m=v&idx=223&pNo=1&code=divorce"><span>성공사례 확인하러 가기</span></a>
        		</div>
        	</div>
        </li>
        	
    	<li>
        	<div class="bx">
        		<div class="tit">
        			<p>대전 이혼변호사 특유재산 관련 재산분할 사례 : 억울한 재산분할 판결, 포기해야 할까요?</p>
        		</div>
        		<div class="txt">
        			<p>특유재산이 적극재산으로 인정되어 재산분할 대상이 되는 것일까?</p>
        			<a href="/kor/divorce/case_list.php?m=v&idx=222&pNo=1&code=divorce"><span>성공사례 확인하러 가기</span></a>
        		</div>
        	</div>
        </li>
        	
    	<li>
        	<div class="bx">
        		<div class="tit">
        			<p>대전변호사 기여분은 그대로, 분할 대상 재산을 축소하여 지급할 분할금을 감액한 사례</p>
        		</div>
        		<div class="txt">
        			<p>적극재산 인정여부에 대해 항소심을 거쳐 재산분할 금액 감액 사례</p>
        			<a href="/kor/divorce/case_list.php?m=v&idx=221&pNo=1&code=divorce"><span>성공사례 확인하러 가기</span></a>
        		</div>
        	</div>
        </li>
        	
    	<li>
        	<div class="bx">
        		<div class="tit">
        			<p>남편의 가사노동 기여도 인정 사례</p>
        		</div>
        		<div class="txt">
        			<p>부인명의 재산, 가사와 육아를 도운 남편의 재산분할 청</p>
        			<a href="/kor/divorce/case_list.php?m=v&idx=220&pNo=1&code=divorce"><span>성공사례 확인하러 가기</span></a>
        		</div>
        	</div>
        </li>
        	
    	<li>
        	<div class="bx">
        		<div class="tit">
        			<p>이혼상대방의 혼인 전 재산에 대한 분할성공사례</p>
        		</div>
        		<div class="txt">
        			<p>고유재산인 혼인전 재산에 대한 재산분할 청구가 가능할</p>
        			<a href="/kor/divorce/case_list.php?m=v&idx=219&pNo=1&code=divorce"><span>성공사례 확인하러 가기</span></a>
        		</div>
        	</div>
        </li>
        	
    	<li>
        	<div class="bx">
        		<div class="tit">
        			<p>아파트 분양권 프리미엄을 이혼 재산분할에 포함시킨 성공사례</p>
        		</div>
        		<div class="txt">
        			<p>대전 신축아파트 분양권 프리미엄을 재산분할에 포함시키는 방법</p>
        			<a href="/kor/divorce/case_list.php?m=v&idx=218&pNo=1&code=divorce"><span>성공사례 확인하러 가기</span></a>
        		</div>
        	</div>
        </li>
        	</ul>
		
	</div>

<!-- 페이징 -->
<div class="page_bx">
    <a class='page_first'>first</a>
<a class='page_prev'>prev</a>
<a class='num on'>1</a>
<a href='/kor/divorce/case_list.php?pNo=2&amp;code=divorce' class='num'>2</a>
<a href='/kor/divorce/case_list.php?pNo=3&amp;code=divorce' class='num'>3</a>
<a href='/kor/divorce/case_list.php?pNo=4&amp;code=divorce' class='num'>4</a>
<a class='page_next'>next</a>
<a class='page_last'>last</a>
</div>

<script>
	$('#spart').on('change', function(){
		$('form#bd_search').submit();
	});

    $('select#sitem').val('');
    $('#btn_search').on('click', function () {
        $('form#bd_search').submit();
    });
</script>
									</div>
			</div>
		</div><!-- //container -->

		<footer id="footer" class="indexNum_03">
			<div class="top_bx">
				<div class="f_inner">
					<div class="l_bx">
						<span class="ttl">상담문의</span>
						<!-- <p>
    							<strong>1544-0904(대표번호) / 042-721-0608(회생파산) / 042-721-0606(송무)</strong>업무시간 09:00 ~ 18:00 (주말, 공휴일 휴무)
    						</p> -->
						<p>
							<strong>대표번호 1544-0904</strong>
							<strong>02-6954-0478(서울회생파산) / 02-6954-0378(서울송무)</strong>
							<strong>042-721-0608(대전회생파산) / 042-721-0606(대전송무)</strong>
						<p>업무시간 09:00 ~ 18:00 (주말, 공휴일 휴무)</p>
						</p>
					</div>
					<div class="r_bx">
						<span class="ttl">glory sns</span>
						<ul class="sns_bx">
							<li class="instagram"><a href="https://www.instagram.com/glory_lawfirm/?igshid=MzRlODBiNWFlZA%3D%3D" target="_blank">instagram</a></li>
							<li class="youtube"><a href="#none" >youtube</a></li>
							<li class="facebook"><a href="#none" >facebook</a></li>
						</ul>
					</div>
				</div>
			</div>
			<div class="btm_bx">
				<div class="f_inner">
					<img src="../images/common/logo.png" class="logo" alt="법무법인 글로리">
					<ul class="link_bx">
						<li><a href="../company/intro.php">법인소개</a></li>
						<li><a href="../policy/privacy.php">개인정보처리방침</a></li>
						<li><a href="../business/areas.php">업무영역</a></li>
						<li class="dotN"><a href="../review/list.php">후기</a></li>
																					<li><a href="../divorce/#divorce_05">상담신청</a></li>
																			<li><a href="../community/notice.php">커뮤니티</a></li>
					</ul>
					<!-- <ul class="info_bx">
    						<li>상호 : 법무법인 글로리</li>
    						<li>사업자등록번호 : 604-86-02992</li>
    						<li>대표변호사 : 이아무</li>
    						<li>주소 : 대전광역시 서구 둔산중로 78번길 26, 민석타워 3층 301호</li>
    						<li>대표번호 : 1544-0904(대표번호) / 042-721-0608(회생파산) / 042-721-0606(송무)</li>
    						<li>팩스 : 042-721-0707</li>
    						<li>이메일 : glory@glorylawfirm.kr</li>
    					</ul> -->
					<ul class="info_bx">
						<li>상호 : 법무법인 글로리</li>
						<li>사업자등록번호 : 604-86-02992</li>
						<li>대표변호사 : 이아무</li>
						<li>대표번호 : 1544-0904</li>
						<li>이메일 : glorylawfirm@daum.net</li>
						<li>서울본사 : 서울특별시 강남구 테헤란로8길 13, 9층 (역삼동, WD빌딩) <span>| TEL : 02-6954-0478(회생파산), 02-6954-0378(송무)</span> <span>| FAX : 02-6954-0878</span></li>
						<li>대전지점 : 대전광역시 서구 둔산중로 78번길 26, 민석타워 3층 301호 <span>| TEL : 042-721-0608(회생파산), 042-721-0606(송무)</spaan> <span>| FAX : 042-721-0707</span></li>
					</ul>
					<p class="btm_txt">Copyright © 2023 Law Firm Glory. All Rights Reserved.</p>
				</div>
			</div>
		</footer>
		</div><!-- //wrap -->

		<script type="text/javascript">
			AOS.init({
				once: true,
				startEvent: 'load',
				disable: function() {
					//var maxWidth = 1024;
					//return window.innerWidth < maxWidth;
				}
			});
										$(".divorce_btn").click(function() {
					if ($(window).width() > 1024) {
						var scroll = $('#divorce_05').offset().top - 70;
					} else {
						var scroll = $('#divorce_05').offset().top;
					}

					$('html, body').animate({
						scrollTop: scroll
					}, 700);
					return false;
				});
					</script>

		
		<!-- 공통 적용 스크립트 , 모든 페이지에 노출되도록 설치. 단 전환페이지 설정값보다 항상 하단에 위치해야함 -->
		<script type="text/javascript" src="//wcs.naver.net/wcslog.js"> </script>
		<script type="text/javascript">
			if (!wcs_add) var wcs_add = {};
			wcs_add["wa"] = "s_35d04fef83bb";
			if (!_nasa) var _nasa = {};
			if (window.wcs) {
				wcs.inflow();
				wcs_do(_nasa);
			}
		</script>


		</body>

		</html>
<!-- 상담신청 팝업 -->
<div id="contact_pop">
	<div class="pop_w">
		<div class="pop_c">
			<div class="close_btn">닫기</div>
			<ul class="tab_bx">
				<li class="on">온라인 상담신청</li>
			</ul>
			<div class="con_bx">
				<div class="con_w on">
					<div class="ttl_bx">
						<strong>ONLINE SOLUTION</strong>
						<p>1:1온라인 상담을 통해 신속하고 정확하게 고객의 니즈를 충족하는 법률서비스를 제공하고 있습니다.</p>
					</div>
					<ul class="list_bx">
						<li><strong>1.</strong>최대 12시간이내, 담당자가 유선 연락을 드립니다.</li>
						<li><strong>2.</strong>예약 후 내방하시면 담당변호사와 1:1심층면담이 이루어집니다.</li>
						<li><strong>3.</strong>상담분야를 특정하여 주시면 즉시 담당자와 연결해 드립니다.</li>
					</ul>
					<div class="form_bx">
						<form method="post" action="/process/online.php" id="onlineform" enctype="multipart/form-data">
						<input type="hidden" name="gubun" value="divorce_popup"> <!--이혼상담-->
							<div class="f_w">
								<input type="text" name="name" placeholder="이름">
								<input type="text" name="tel" placeholder="연락처">
							</div>
							<textarea name="content" placeholder="기타 문의내용 (필요할 경우 상담내용을 입력해 주시면 됩니다.)"></textarea>
							<div class="chk_bx">
								<input type="checkbox" id="agree1" name="safeguard">
								<label for="agree1">개인정보 수집 및 이용에 동의</label>
							</div>
							<a href="#" onclick="onlineSend(); return false;" class="btn"><span>법률상담 신청하기</span></a>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
	function onlineSend(){
		var f = document.getElementById('onlineform');
		var safeguard = $('#onlineform [name=safeguard]:checkbox').prop('checked');

		if(!$.trim(f.name.value)){
			alert("이름을 입력해주세요.");
			f.name.focus();
			return false;
		}else if(!$.trim(f.tel.value)){
			alert("연락처를 입력해주세요.");
			f.tel.focus();
			return false;
		}else if(safeguard == false){
			alert("개인정보수집 및 이용동의 약관에 동의하세요.");
			return false;
		}else{
			f.submit();
		}
	}
</script>


<script>    
	document.querySelector('#reCaptcha2').addEventListener('click', function() {
		this.innerHTML = '<img src="/kor/inc/kcaptcha/?form=divorcequickform&PHPSESSID=q25mjso2juik2cjnnsqs3lcugk&rand=' + Math.random() + '">';
	});
</script>

