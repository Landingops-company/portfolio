
<!DOCTYPE html>
<html lang="ko">

<head>
	<title>법무법인 글로리 회생파산센터 - 대전 개인회생, 대전 개인파산, 대전개인회생 전문, 대전개인회생변호사, 대전회생변호사, 대전회생, 대전법인파산</title>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="format-detection" content="telephone=no" />
	<link rel="canonical" href="https://glorylawfirm.kr/kor/revive/visit.php" />

	<meta name="description" content="개인회생,개인회생신청자격,개인파산,개인회생신청,개인회생금지명령,개인회생파산,회생전문변호사,개인회생변제금,개인회생신용회복,회생,개인회생변호사,개인회생기간단축,개인워크아웃,대전개인회생,대구개인회생,수원회생법원,파산신청,창원개인회생,부산개인회생,개인회생재신청,개인회생비용,개인회생절차,채무조정,채무조정제도,대구개인파산,개인파산신청방법,부산개인파산,도박개인회생,부산개인회생상담,개인회생서류,개인회생기간,개인회생보정권고,개인회생신청자격요건,회생신청,개인파산신청자격요건,개인회생면책신청,개인회생인가결정,개인회생개시결정,개인회생조회,개인회생파산차이,개인파산신청,개인회생미납,파산관재인,개인파산면책,서울개인회생,개인회생변호사비용,개인회생수임료,개인회생조건" />
	<meta name="keywords" content="개인회생,개인회생신청자격,개인파산,개인회생신청,개인회생금지명령,개인회생파산,회생전문변호사,개인회생변제금,개인회생신용회복,회생,개인회생변호사,개인회생기간단축,개인워크아웃,대전개인회생,대구개인회생,수원회생법원,파산신청,창원개인회생,부산개인회생,개인회생재신청,개인회생비용,개인회생절차,채무조정,채무조정제도,대구개인파산,개인파산신청방법,부산개인파산,도박개인회생,부산개인회생상담,개인회생서류,개인회생기간,개인회생보정권고,개인회생신청자격요건,회생신청,개인파산신청자격요건,개인회생면책신청,개인회생인가결정,개인회생개시결정,개인회생조회,개인회생파산차이,개인파산신청,개인회생미납,파산관재인,개인파산면책,서울개인회생,개인회생변호사비용,개인회생수임료,개인회생조건" />

	<meta property="og:type" content="website">
	<meta property="og:title" content="법무법인 글로리 회생파산센터 - 대전 개인회생, 대전 개인파산, 대전개인회생 전문, 대전개인회생변호사, 대전회생변호사, 대전회생, 대전법인파산">
	<meta property="og:description" content="대전개인회생파산센터 법무법인 글로리 대전개인회생,대전개인회생전문,대전개인파산,대전개인회생변호사,대전회생변호사,대전회생,대전법인파산, 대전 충남 최대규모 회생파산팀, 합리적인 수임료로 대한민국 1%의 회생파산서비스, 토탈케어서비스">

	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, minimum-scale=1.0, user-scalable=no" />
	<link href="https://fonts.googleapis.com/css2?family=Noto+Serif+KR:wght@200;300;400;500;600;700;900&display=swap" rel="stylesheet"><!-- font-family: 'Noto Serif KR', serif; -->
	<link href="https://fonts.googleapis.com/css2?family=Noto+Serif:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
	<link rel="stylesheet" as="style" crossorigin href="https://cdn.jsdelivr.net/gh/ungveloper/web-fonts/GmarketSans/font-face.css" />
	<link rel="stylesheet" as="style" crossorigin href="https://cdn.jsdelivr.net/gh/ungveloper/web-fonts/GmarketSans/font-face.css" /> <!-- 지마켓산스 -->

	<!-- font -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;500;600;700;800;900&family=Montserrat:wght@100;200;300;400;500;600;700;800;900&family=Nanum+Myeongjo:wght@400;700;800&display=swap" rel="stylesheet">

	<link href="../css/base.css?230830" rel="stylesheet" type="text/css" />
	<link href="../css/common.css?230830" rel="stylesheet" type="text/css" />
	<link href="../css/main.css?230830" rel="stylesheet" type="text/css" />
	<link href="../css/sub.css?230830" rel="stylesheet" type="text/css" />
	<link href="../css/board.css?230830" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="../images/favicon.ico" type="image/x-icon">

	<!--[if lt IE 9]>
		<script src="../js/html5shiv.js"></script>
		<script src="../js/respond.min.js"></script>
		<script type="text/javascript">
			alert('현재 업데이트의 지원이 중단되어 보안이 취약한 하위버전의 브라우저를 사용하고 계십니다.\n원활한 사이트 이용을 위해서는 Internet Explorer 최신 버전으로 업데이트 하시거나,\n타 브라우저 (구글 크롬, 파이어폭스, 네이버 웨일) 사용을 권장합니다.');
		</script>
	<![endif]-->

	<!-- Google Tag Manager -->
	<script>
		(function(w, d, s, l, i) {
			w[l] = w[l] || [];
			w[l].push({
				'gtm.start': new Date().getTime(),
				event: 'gtm.js'
			});
			var f = d.getElementsByTagName(s)[0],
				j = d.createElement(s),
				dl = l != 'dataLayer' ? '&l=' + l : '';
			j.async = true;
			j.src =
				'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
			f.parentNode.insertBefore(j, f);
		})(window, document, 'script', 'dataLayer', 'GTM-5G8269NP');
	</script>
	<!-- End Google Tag Manager -->
	<!-- Google tag (gtag.js) -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=AW-16871756070"></script>
	<script>
	window.dataLayer = window.dataLayer || [];
	function gtag(){dataLayer.push(arguments);}
	gtag('js', new Date());
	gtag('config', 'AW-16871756070');
	</script>
	<!--  END Google tag (gtag.js) -->

	<script src="../js/jquery-3.7.0.min.js"></script>
	<script src="../js/slick.min.js"></script>
	<!-- <script src="../js/common.js"></script> -->
	<script src="../js/common_2024.js"></script>
	<script src="/aseoul/js/dev.js"></script>

	<!-- aos -->
	<link href="../css/aos.css" rel="stylesheet" type="text/css" />
	<script src="../js/aos.js"></script>

	<meta name="naver-site-verification" content="2f95426658d0c9954d3c8c8822f0aecc856dd101" />
<meta name="google-site-verification" content="xMd0V-C2YI-S5zDVVCNYLFLwDSwEHHBEzqDG_Jrz6HE" />
<meta name="google-site-verification" content="xMd0V-C2YI-S5zDVVCNYLFLwDSwEHHBEzqDG_Jrz6HE" />
	<!-- Danggeun Market Code -->
	<script src="https://karrot-pixel.business.daangn.com/0.2/karrot-pixel.umd.js"></script>
	<script>
		window.karrotPixel.init('1724042065698400001');
		window.karrotPixel.track('ViewPage');
	</script>
	<!-- End Danggeun Market Code -->
	<!-- Danggeun Market Code -->
	<script src="https://karrot-pixel.business.daangn.com/0.4/karrot-pixel.umd.js"></script>
	<script>
		window.karrotPixel.init('1738542627560100001');
		window.karrotPixel.track('ViewPage');
	</script>
	<!-- End Danggeun Market Code -->

<!-- Enliple Tracker Start -->
<script async src="https://cdn.onetag.co.kr/0/tcs.js?eid=1k1zhc4s5tb8y1k1zhc4s5"></script>
<!-- Enliple Tracker End -->

</head>

<body id="sub">

	<!-- Google Tag Manager (noscript) -->
	<noscript>
		<iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5G8269NP" height="0" width="0" style="display:none;visibility:hidden"></iframe>
	</noscript>
	<!-- End Google Tag Manager (noscript) -->

	<div id="skipNavi">
		<ul>
			<li>
				<a href="#container">본문 바로가기</a>
				<a href="#gnb">주메뉴 바로가기</a>
			</li>
		</ul>
	</div>

	<div id="wrap" class="renew2024">
		<header id="header" class="type4 ">
			<div class="h_top">
				<div class="h_inner">
					<div class="l_bx gm_font">
						Law&amp;Firm Glory
					</div>
					<div class="r_bx gm_font">
						회생파산센터 서울본사 02-6954-0478 / 회생파산센터 대전지점 042-721-0608 / 대표번호 1544-0904
					</div>
				</div>
			</div>

			<a href="../revive/" class="logo">법무법인 글로리</a>

			<div class="rightFixed">
				<div class="menu_bx">
					<div class="menu_bx_inner">
						<ul class="dep1_wrap">
							<li class="dep1 dep01 a_none">
								<a href="../main/">공식 홈페이지</a>
							</li>
							<li class="dep1 dep02 a_none">
								<a href="../revive/index.php?sec12">성공사례</a>
							</li>
							<li class="dep1 dep03 a_none">
								<a href="../revive/index.php?sec09">전문가 소개</a>
							</li>
							<li class="dep1 dep04 a_none">
								<a href="../revive/index.php?sec13_2">고객 후기</a>
							</li>
							<li class="dep1 dep05 a_none">
								<a href="../revive/index.php?sec16">오시는 길</a>
							</li>
							<li class="dep1 dep06 a_none">
								<a href="../community/notice.php">커뮤니티</a>
							</li>
						</ul>

						<div class="contact_wrap">
							<form method="post" action="/process/revive_quick.php" id="quickform" enctype="multipart/form-data">
								<input type="hidden" name="gubun" value="revive_quick">
								<input type="hidden" name="captcha_form" value="revivequick">
								<div class="contact_tel">
									<span>1:1 전화상담</span>
									<a href="tel:15440904" class="telNum gm_font">1544-0904</a>
								</div>
								<div class="contact_form">
									<div><input type="text" name="name" placeholder="성함" autocomplete='off'></div>
									<div>
										<select name="region">
												<option value="">지역</option>
																									<option  value="1">서울</option>
																									<option  value="2">인천</option>
																									<option  value="3">세종</option>
																									<option  value="4">대전</option>
																									<option  value="5">대구</option>
																									<option  value="6">울산</option>
																									<option  value="7">광주</option>
																									<option  value="8">부산</option>
																									<option  value="9">제주</option>
																									<option  value="10">강원도</option>
																									<option  value="11">경기도</option>
																									<option  value="12">충청북도</option>
																									<option  value="13">충청남도</option>
																									<option  value="14">경상북도</option>
																									<option  value="15">경상남도</option>
																									<option  value="16">전라북도</option>
																									<option  value="17">전라남도</option>
																						</select>
									</div>
									<div>
										<select name="fields">
											<option value="" data-ph="true">분야</option>
											<option value="1">개인회생</option>
											<option value="2">개인파산</option>
											<option value="3">법인회생/파산</option>
										</select>
									</div>
									<div><input type="text" name="tel" placeholder="연락처" autocomplete='off'></div>
									<div class="chk_bx">
										<input type="checkbox" id="q_agree" name="safeguard" checked="checked">
										<label for="q_agree">개인정보수집에 동의합니다.</label>
									</div>
									<div class="captcha" style="height: 60px">
										<span id="reCaptcha4">
											<img src="/kor/inc/kcaptcha/?form=revivequick&PHPSESSID=q25mjso2juik2cjnnsqs3lcugk&rand=963280378">
										</span>
										<p><input type="text" name="captcha" placeholder="보안 문자 입력" /></p>
									</div>

									<button type="button" onclick="quickSend(); return false;" class="contactBtn">신청하기</button>

								</div>
							</form>
						</div>

						<div class="consultLink_bx">
							<a href="../consult/list.php" class="btn"><img src="../images/icon/consult_1.png">게시판 상담</a>
							<a href="../revive/visit.php" class="btn"><img src="../images/icon/consult_2.png">방문상담</a>
						</div>

						<div class="sns_bx">
							<a href="https://pf.kakao.com/_gPkyxj" target="_blank" class="btn"><img src="../images/icon/sns_kakao.png">카카오톡 실시간 상담</a>
							<a href="https://blog.naver.com/tphyak80" target="_blank" class="btn"><img src="../images/icon/sns_naver.png">블로그</a>
							<a href="https://www.instagram.com/glory_lawfirm/?igshid=MzRlODBiNWFlZA%3D%3D" target="_blank" class="btn"><img src="../images/icon/sns_insta.png">인스타그램</a>
						</div>
					</div>
				</div>
			</div>

			<div class="sm_bx">
				<div class="sm_w">
				</div>
			</div>

			<div class="r_bx">
				<div class="menu_btn m_show">
					<span></span>
					<span></span>
					<span></span>
				</div>
			</div>
		</header><!-- //header -->

		<script type="text/javascript">
			$("#main #header.type4 .logo").click(function() {
				$('html, body').animate({
					scrollTop: $('#sec01').offset().top
				}, 700);
				return false;
			});

			$("#main #header.type4 .menu_bx .dep02 > a").click(function() {
				$('html, body').animate({
					scrollTop: $('#sec12').offset().top
				}, 700);
				return false;
			});

			$("#main #header.type4 .menu_bx .dep03 > a").click(function() {
				$('html, body').animate({
					scrollTop: $('#sec09').offset().top
				}, 700);
				return false;
			});

			$("#main #header.type4 .menu_bx .dep04 > a").click(function() {
				$('html, body').animate({
					scrollTop: $('#sec13_2').offset().top - 70
				}, 700);
				return false;
			});

			$("#main #header.type4 .menu_bx .dep05 > a").click(function() {
				$('html, body').animate({
					scrollTop: $('#sec16').offset().top
				}, 700);
				return false;
			});

			// $("#main #header.type4 .menu_bx .dep06 > a").click(function() {
			// 	$('html, body').animate({
			// 		scrollTop: $('#sec05_2').offset().top - 70
			// 	}, 700);
			// 	return false;
			// });

			function mMenu() {
				$("#main #header.type4 .logo").click(function() {
					$('html, body').animate({
						scrollTop: $('#sec01').offset().top
					}, 700);
					return false;
				});

				$("#main #header.type4 .sm_bx .dep02 > a").click(function() {
					$('html, body').animate({
						scrollTop: $('#sec12').offset().top
					}, 700);

					$("#header .menu_btn").trigger("click");

					return false;
				});

				$("#main #header.type4 .sm_bx .dep03 > a").click(function() {
					$('html, body').animate({
						scrollTop: $('#sec09').offset().top
					}, 700);

					$("#header .menu_btn").trigger("click");

					return false;
				});

				$("#main #header.type4 .sm_bx .dep04 > a").click(function() {
					$('html, body').animate({
						scrollTop: $('#sec13_2').offset().top
					}, 700);

					$("#header .menu_btn").trigger("click");

					return false;
				});

				$("#main #header.type4 .sm_bx .dep05 > a").click(function() {
					$('html, body').animate({
						scrollTop: $('#sec16').offset().top
					}, 700);

					$("#header .menu_btn").trigger("click");

					return false;
				});

				// $("#main #header.type4 .sm_bx .dep06 > a").click(function() {
				// 	$('html, body').animate({
				// 		scrollTop: $('#sec05_2').offset().top
				// 	}, 700);

				// 	$("#header .menu_btn").trigger("click");

				// 	return false;
				// });
			}

			var thisUrl = window.location.href;
			if (thisUrl.split("?").length > 1) {
				var thisUrlId = thisUrl.split("?")[1];

				setTimeout(function() {
					if ($(window).width() > 1024) {
						$('html, body').animate({
							scrollTop: $('#' + thisUrlId).offset().top - 70
						}, 500);
					} else {
						$('html, body').animate({
							scrollTop: $('#' + thisUrlId).offset().top
						}, 500);
					}
				}, 200);
			}
		</script>
		<script>
			function quickSend() {
				var f = document.getElementById('quickform');
				var safeguard = $('#quickform [name=safeguard]:checkbox').prop('checked');

				if (!$.trim(f.name.value)) {
					alert("이름을 입력해주세요.");
					f.name.focus();
					return false;
				} else if (!$.trim(f.tel.value)) {
					alert("연락처를 입력해주세요.");
					f.tel.focus();
					return false;
				} else if(!$.trim(f.region.value)){
					alert("지역을 선택해주세요.");
					return false;
				} else if (!$.trim(f.fields.value)) {
					alert("상담분야를 선택해주세요.");
					return false;
				} else if (safeguard == false) {
					alert("개인정보수집 및 이용동의 약관에 동의하세요.");
					return false;
				}else if (!f.captcha.value.trim()) {
					alert("보안 문자를 입력해 주십시오.");
					return false;
				} else {
					// Danggeun Market Code
					window.karrotPixel.track('SubmitApplication');
					// End Danggeun Market Code
					gtag('event', 'conversion', {
						'send_to': 'AW-16871756070/Ahg0CIGttqkaEKaiiu0-',
						'value': 1.0,
						'currency': 'KRW'
						});
					f.submit();
				}
			}

		</script>

		<script>
    document.querySelector('#reCaptcha4').addEventListener('click', function() {
        this.innerHTML = '<img src="/kor/inc/kcaptcha/?form=revivequick&PHPSESSID=q25mjso2juik2cjnnsqs3lcugk&rand=' + Math.random() + '">';
    });
		</script>
<link href="../css/main_revive.css" rel="stylesheet" type="text/css">
<link href="../css/sub_revive_2024.css" rel="stylesheet" type="text/css">
<script>
function next_month(){
	var currentArr = $(".currentMonth").text().split('. ');
	var cal_year = parseInt(currentArr[0]);
	var cal_month = parseInt(currentArr[1]);
	
    (cal_month == 12) ? cal_year = (cal_year+1) : cal_year = cal_year;  //  다음 연도
    (cal_month == 12) ? cal_month = 1 : cal_month = (cal_month+1);  //  다음 월

	calender_load(cal_year,numberPad(cal_month,2));
}
function prev_month(cal_class){

	var currentArr = $(".currentMonth").text().split('. ');
	var cal_year = parseInt(currentArr[0]);
	var cal_month = parseInt(currentArr[1]);
	
	(cal_month == 1) ? cal_year = (cal_year-1) : cal_year = cal_year;  //  이전 연도
    (cal_month == 1) ? cal_month = 12 : cal_month = (cal_month-1);  // 이전 월

	calender_load(cal_year,numberPad(cal_month,2));
        
}
function numberPad(n, width) {
    n = n + '';
    return n.length >= width ? n : new Array(width - n.length + 1).join('0') + n;
}

</script>
<div id="container" class="sub2024">
	<div id="contents">
		<div id="review" class="revive_board">
			<div class="box box1">
				<div class="ttl_bx">
					<strong>방문상담</strong>
					<p>상담신청하시면 예약확인 연락을 드립니다.<br />예약확인 연락을 받으신 후 방문 부탁드립니다. 감사합니다.</p>
				</div>

				<div class="inner_bx">
					<div id="board">
						
						<div class="visitFormWrap">							
							
							<form id="visitForm" action="./insert_visit.php" method="post" class="visitForm">								
								<input type="hidden" name="day" value="">
								<input type="hidden" name="captcha_form" value="revivevisit">
								<div class="visitCalender">
									<div class="title">예약 날짜 선택</div>
									<div class="calenderWrap">
										<div class="month">
											<a href="" onclick="" class="prevMonth">이전달</a>
											<a href="" onclick="" class="currentMonth">2025. 12</a>
											<a href="" onclick="" class="nextMonth">이전달</a>
										</div>
										<div class="calTableWrap">
											<table class="calTable" summary="날짜선택">
												<thead>
													<tr>
														<th scope="col">일</th>
														<th scope="col">월</th>
														<th scope="col">화</th>
														<th scope="col">수</th>
														<th scope="col">목</th>
														<th scope="col">금</th>
														<th scope="col" class="last">토</th>
													</tr>
												</thead>
												<tbody>
													<tr>
														<td></td>
														<td></td>
														<td></td>
														<td></td>
														<td></td>
														<td class="not">1</td> <!-- .not 예약불가능-->
														<td>2</td>
													</tr>
													<tr>
														<td>3</td>
														<td class="not">4</td>
														<td>5</td>
														<td>6</td>
														<td>7</td>
														<td>8</td>
														<td>9</td>
													</tr>
													<tr>
														<td>10</td>
														<td class="on">11</td> <!-- .on 날짜 선택 -->
														<td>12</td>
														<td>13</td>
														<td>14</td>
														<td>15</td>
														<td>16</td>
													</tr>
													<tr>
														<td>17</td>
														<td>18</td>
														<td>19</td>
														<td>20</td>
														<td>21</td>
														<td>22</td>
														<td>23</td>
													</tr>
													<tr>
														<td>24</td>
														<td>25</td>
														<td>26</td>
														<td>27</td>
														<td>28</td>
														<td>29</td>
														<td>30</td>
													</tr>
													<tr>
														<td>31</td>
														<td></td>
														<td></td>
														<td></td>
														<td></td>
														<td></td>
														<td></td>
													</tr>
												</tbody>
											</table>
										</div>
										<div class="visitDateText">
											<span class="visitDate"><!--2024년 3월 11일--></span><span>을 선택하셨습니다.</span>
										</div>
									</div>
								</div>																
								<div class="writeFormWrap">
									<p class="tip"><span class="imp">필수</span><span class="text">표시는 필수 항목입니다.</span></p>
									<div class="writeForm">
										<dl>
											<dt><lable for="name">이름<span class="imp">필수</span></lable></dt>
											<dd><input type="text" name="name" value="" id="name" class="input"></dd>
										</dl>
										<dl>
											<dt><lable for="tel">전화번호<span class="imp">필수</span></lable></dt>
											<dd><input type="text" name="tel" value="" id="tel" class="input"></dd>
										</dl>
										<dl>
											<dt><lable for="region">지역<span class="imp">필수</span></lable></dt>
											<dd>
												<select name="region" class="input">
													<option value="">지역</option>
																											<option  value="1">서울</option>
																											<option  value="2">인천</option>
																											<option  value="3">세종</option>
																											<option  value="4">대전</option>
																											<option  value="5">대구</option>
																											<option  value="6">울산</option>
																											<option  value="7">광주</option>
																											<option  value="8">부산</option>
																											<option  value="9">제주</option>
																											<option  value="10">강원도</option>
																											<option  value="11">경기도</option>
																											<option  value="12">충청북도</option>
																											<option  value="13">충청남도</option>
																											<option  value="14">경상북도</option>
																											<option  value="15">경상남도</option>
																											<option  value="16">전라북도</option>
																											<option  value="17">전라남도</option>
																									</select>
											</dd>
										</dl>
										<dl>
											<dt><lable for="time">시간<span class="imp">필수</span></lable></dt>
											<dd>
												<select name="time" id="time" class="input">
													<option value="09:00">09시00분</option>
													<option value="09:30">09시30분</option>
													<option value="10:00">10시00분</option>
													<option value="10:30">10시30분</option>
													<option value="11:00">11시00분</option>
													<option value="11:30">11시30분</option>
													<option value="12:00">12시00분</option>
													<option value="12:30">12시30분</option>
													<option value="13:00">13시00분</option>
													<option value="13:30">13시30분</option>
													<option value="14:00">14시00분</option>
													<option value="14:30">14시30분</option>
													<option value="15:00">15시00분</option>
													<option value="15:30">15시30분</option>
													<option value="16:00">16시00분</option>
													<option value="16:30">16시30분</option>
													<option value="17:00">17시00분</option>
													<option value="17:30">17시30분</option>
													<option value="18:00">18시00분</option>
													<option value="18:30">18시30분</option>
												</select>
											</dd>
										</dl>
										<dl>
											<dt><lable for="desc">상담내용</lable></dt>
											<dd><textarea name="content" id="desc" class="input"></textarea></dd>
										</dl>
										<dl>
											<dt><lable for="">보안 문자 입력</lable></dt>
											<dd>
												<div class="captcha">
													<span id="reCaptcha5">
														<img src="/kor/inc/kcaptcha/?form=revivevisit&PHPSESSID=q25mjso2juik2cjnnsqs3lcugk&rand=1576498723">
													</span>
													<input type="text" name="captcha" placeholder="" class="input" />
												</div>
											</dd>
										</dl>
										<dl class="agree_bx">
											<dt></dt>
											<dd>
												<div class="chk_bx">
													<input type="checkbox" id="agree" name="safeguard" checked="checked">
													<label for="agree">개인정보 수집 및 이용에 동의합니다.</label>
												</div>
											</dd>
										</dl>
										<dl class="visitBtnWrap">
											<dt></dt>
											<dd>
												<button type="button" onclick="submitWrite(this.form); return false" class="visitBtn">예약하기</button>	
											</dd>
										</dl>
									</div>

								</div>

							</form>
						</div>



					</div>
				</div>
			</div>
		</div>
	</div><!-- //contents -->
</div><!-- //container -->
<script>
	$(document).ready(function() {
		calender_load('2025','12');
	});
	function calender_load(cal_year,cal_month)
	{
		if(window.XMLHttpRequest)
			xmlhttp=new XMLHttpRequest();
		else
			xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		
		xmlhttp.onreadystatechange = function() {
			if(xmlhttp.readyState==4 && xmlhttp.status==200)
			{
				str = xmlhttp.responseText;
				
				$('.visitCalender').html(str);
			}
		}

		var sel_day = $("input[name='day']").val();
		
		url = './visit_cal.php';
		url += '?cal_year='+cal_year;
		url += '&cal_month='+cal_month;
		url += '&sel_day='+sel_day;
		
		xmlhttp.open("GET", url, true);
		xmlhttp.send();
	}

	$(".visitFormWrap").on("click", "td:not(.not)", function() {				
		$(this).closest('table').find('td').removeClass("on");		
		$(this).addClass("on");
		var currentMonth = $(".currentMonth").text();		
		var selDate = currentMonth.replace(/[^0-9]/g,'') +numberPad($(this).text().trim(),2);
		$(".visitDate").text(selDate.replace(/(\d{4})(\d{2})(\d{2})/g, '$1년$2월$3일'));
		$("input[name='day']").val(selDate.replace(/(\d{4})(\d{2})(\d{2})/g, '$1-$2-$3'));
	});
</script>
<script>
    function submitWrite(f) {
        if(!$.trim(f.day.value)){
            alert("날짜를 선택하세요.");
            f.day.focus();
        }else if(!$.trim(f.name.value)){
            alert("이름을 입력하세요.");
            f.name.focus();
        }else if(!$.trim(f.tel.value)){
            alert("전화번호를 입력하세요.");
            f.tel.focus();
        }else if(!$.trim(f.region.value)){
            alert("지역을 선택하세요.");
            f.region.focus();
        }else if(!$.trim(f.time.value)){
            alert("시간을 선택하세요.");
            f.time.focus();
        }else if(!$.trim(f.content.value)){
            alert("내용을 입력하세요.");
            f.content.focus();
        }else if(!$('#agree').is(':checked')){
            alert("개인정보 수집 및 이용목적에 동의해주세요.");
        }else{
            var day1 = new Date();
			var day2 = new Date($.trim(f.day.value)+' ' +$.trim(f.time.value)+':00');
			if(day1 > day2){
				alert("현재보다 이후 시간으로로 선택해 주세요.");				
			}else{
				f.submit();
			}			
        }
    }

    document.querySelector('#reCaptcha5').addEventListener('click', function() {
        this.innerHTML = '<img src="/kor/inc/kcaptcha/?form=revivevisit&PHPSESSID=q25mjso2juik2cjnnsqs3lcugk&rand=' + Math.random() + '">';
    });
</script>

		<footer id="footer" class="indexNum_">	
		<div class="inner">		
			<div class="btm_bx">
				<div class="f_inner">
					<img src="../images/common/f_logo.png" class="logo" alt="법무법인 글로리">
					<ul class="link_bx">
						<li><a href="../company/intro.php">법인소개</a></li>
						<li><a href="../policy/privacy.php">개인정보처리방침</a></li>
						<li><a href="../business/areas.php">업무영역</a></li>
						<li class="dotN"><a href="/kor/revive/review.php">후기</a></li>
												<li><a class="quick_btn">상담신청</a></li>
												<li><a href="../community/notice.php">커뮤니티</a></li>
					</ul>
					<!-- <ul class="info_bx">
    						<li>상호 : 법무법인 글로리</li>
    						<li>사업자등록번호 : 604-86-02992</li>
    						<li>대표변호사 : 이아무</li>
    						<li>주소 : 대전광역시 서구 둔산중로 78번길 26, 민석타워 3층 301호</li>
    						<li>대표번호 : 1544-0904(대표번호) / 042-721-0608(회생파산) / 042-721-0606(송무)</li>
    						<li>팩스 : 042-721-0707</li>
    						<li>이메일 : glory@glorylawfirm.kr</li>
    					</ul> -->
						<ul class="info_bx">
						<li>상호 : 법무법인 글로리</li>
						<li>사업자등록번호 : 604-86-02992</li>
						<li>대표변호사 : 이아무</li>
						<li>대표번호 : 1544-0904</li>
						<li>이메일 : glorylawfirm@daum.net</li>
						<li>서울본사 : 서울특별시 강남구 테헤란로8길 13, 9층 (역삼동, WD빌딩) <span>| TEL : 02-6954-0478(회생파산), 02-6954-0378(송무)</span> <span>| FAX : 02-6954-0878</span></li>
						<li>대전지점 : 대전광역시 서구 둔산중로 78번길 26, 민석타워 3층 301호 <span>| TEL : 042-721-0608(회생파산), 042-721-0606(송무)</spaan> <span>| FAX : 042-721-0707</span></li>
					</ul>
					<p class="btm_txt">Copyright © 2023 Law Firm Glory. All Rights Reserved.</p>
				</div>
			</div>
			</div>
		</footer>
	</div><!-- //wrap -->
	
	<script type="text/javascript">
		AOS.init({
			once: true,
			startEvent: 'load',
			disable: function() {
				//var maxWidth = 1024;
				//return window.innerWidth < maxWidth;
			}
		});
                
		
	</script>

		
<!-- NAVER SCRIPT START -->
<script type="text/javascript" src="//wcs.naver.net/wcslog.js"></script>
<script type="text/javascript">
if (!wcs_add) var wcs_add={};
wcs_add["wa"] = "s_35d04fef83bb";
if(window.wcs) {
        wcs.inflow("glorylawfirm.kr");
}
wcs_do();
</script>
<!-- NAVER SCRIPT END -->
	
	<!-- Smartlog -->
    <script type="text/javascript"> 
        var hpt_info={'_account':'UHPT-23580', '_server': 'a26'};
    </script>
    <script language="javascript" src="//cdn.smlog.co.kr/core/smart.js" charset="utf-8"></script>
    <noscript><img src="//a26.smlog.co.kr/smart_bda.php?_account=23580" style="display:none;width:0;height:0;" border="0"/></noscript>  	
</body>
</html>
