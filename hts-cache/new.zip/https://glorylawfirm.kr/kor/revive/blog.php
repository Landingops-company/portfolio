
<!DOCTYPE html>
<html lang="ko">

<head>
	<title>법무법인 글로리 회생파산센터 - 대전 개인회생, 대전 개인파산, 대전개인회생 전문, 대전개인회생변호사, 대전회생변호사, 대전회생, 대전법인파산</title>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="format-detection" content="telephone=no" />
	<link rel="canonical" href="https://glorylawfirm.kr/kor/revive/blog.php" />

	<meta name="description" content="개인회생,개인회생신청자격,개인파산,개인회생신청,개인회생금지명령,개인회생파산,회생전문변호사,개인회생변제금,개인회생신용회복,회생,개인회생변호사,개인회생기간단축,개인워크아웃,대전개인회생,대구개인회생,수원회생법원,파산신청,창원개인회생,부산개인회생,개인회생재신청,개인회생비용,개인회생절차,채무조정,채무조정제도,대구개인파산,개인파산신청방법,부산개인파산,도박개인회생,부산개인회생상담,개인회생서류,개인회생기간,개인회생보정권고,개인회생신청자격요건,회생신청,개인파산신청자격요건,개인회생면책신청,개인회생인가결정,개인회생개시결정,개인회생조회,개인회생파산차이,개인파산신청,개인회생미납,파산관재인,개인파산면책,서울개인회생,개인회생변호사비용,개인회생수임료,개인회생조건" />
	<meta name="keywords" content="개인회생,개인회생신청자격,개인파산,개인회생신청,개인회생금지명령,개인회생파산,회생전문변호사,개인회생변제금,개인회생신용회복,회생,개인회생변호사,개인회생기간단축,개인워크아웃,대전개인회생,대구개인회생,수원회생법원,파산신청,창원개인회생,부산개인회생,개인회생재신청,개인회생비용,개인회생절차,채무조정,채무조정제도,대구개인파산,개인파산신청방법,부산개인파산,도박개인회생,부산개인회생상담,개인회생서류,개인회생기간,개인회생보정권고,개인회생신청자격요건,회생신청,개인파산신청자격요건,개인회생면책신청,개인회생인가결정,개인회생개시결정,개인회생조회,개인회생파산차이,개인파산신청,개인회생미납,파산관재인,개인파산면책,서울개인회생,개인회생변호사비용,개인회생수임료,개인회생조건" />

	<meta property="og:type" content="website">
	<meta property="og:title" content="법무법인 글로리 회생파산센터 - 대전 개인회생, 대전 개인파산, 대전개인회생 전문, 대전개인회생변호사, 대전회생변호사, 대전회생, 대전법인파산">
	<meta property="og:description" content="대전개인회생파산센터 법무법인 글로리 대전개인회생,대전개인회생전문,대전개인파산,대전개인회생변호사,대전회생변호사,대전회생,대전법인파산, 대전 충남 최대규모 회생파산팀, 합리적인 수임료로 대한민국 1%의 회생파산서비스, 토탈케어서비스">

	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, minimum-scale=1.0, user-scalable=no" />
	<link href="https://fonts.googleapis.com/css2?family=Noto+Serif+KR:wght@200;300;400;500;600;700;900&display=swap" rel="stylesheet"><!-- font-family: 'Noto Serif KR', serif; -->
	<link href="https://fonts.googleapis.com/css2?family=Noto+Serif:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
	<link rel="stylesheet" as="style" crossorigin href="https://cdn.jsdelivr.net/gh/ungveloper/web-fonts/GmarketSans/font-face.css" />
	<link rel="stylesheet" as="style" crossorigin href="https://cdn.jsdelivr.net/gh/ungveloper/web-fonts/GmarketSans/font-face.css" /> <!-- 지마켓산스 -->

	<!-- font -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;500;600;700;800;900&family=Montserrat:wght@100;200;300;400;500;600;700;800;900&family=Nanum+Myeongjo:wght@400;700;800&display=swap" rel="stylesheet">

	<link href="../css/base.css?230830" rel="stylesheet" type="text/css" />
	<link href="../css/common.css?230830" rel="stylesheet" type="text/css" />
	<link href="../css/main.css?230830" rel="stylesheet" type="text/css" />
	<link href="../css/sub.css?230830" rel="stylesheet" type="text/css" />
	<link href="../css/board.css?230830" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="../images/favicon.ico" type="image/x-icon">

	<!--[if lt IE 9]>
		<script src="../js/html5shiv.js"></script>
		<script src="../js/respond.min.js"></script>
		<script type="text/javascript">
			alert('현재 업데이트의 지원이 중단되어 보안이 취약한 하위버전의 브라우저를 사용하고 계십니다.\n원활한 사이트 이용을 위해서는 Internet Explorer 최신 버전으로 업데이트 하시거나,\n타 브라우저 (구글 크롬, 파이어폭스, 네이버 웨일) 사용을 권장합니다.');
		</script>
	<![endif]-->

	<!-- Google Tag Manager -->
	<script>
		(function(w, d, s, l, i) {
			w[l] = w[l] || [];
			w[l].push({
				'gtm.start': new Date().getTime(),
				event: 'gtm.js'
			});
			var f = d.getElementsByTagName(s)[0],
				j = d.createElement(s),
				dl = l != 'dataLayer' ? '&l=' + l : '';
			j.async = true;
			j.src =
				'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
			f.parentNode.insertBefore(j, f);
		})(window, document, 'script', 'dataLayer', 'GTM-5G8269NP');
	</script>
	<!-- End Google Tag Manager -->
	<!-- Google tag (gtag.js) -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=AW-16871756070"></script>
	<script>
	window.dataLayer = window.dataLayer || [];
	function gtag(){dataLayer.push(arguments);}
	gtag('js', new Date());
	gtag('config', 'AW-16871756070');
	</script>
	<!--  END Google tag (gtag.js) -->

	<script src="../js/jquery-3.7.0.min.js"></script>
	<script src="../js/slick.min.js"></script>
	<!-- <script src="../js/common.js"></script> -->
	<script src="../js/common_2024.js"></script>
	<script src="/aseoul/js/dev.js"></script>

	<!-- aos -->
	<link href="../css/aos.css" rel="stylesheet" type="text/css" />
	<script src="../js/aos.js"></script>

	<meta name="naver-site-verification" content="2f95426658d0c9954d3c8c8822f0aecc856dd101" />
<meta name="google-site-verification" content="xMd0V-C2YI-S5zDVVCNYLFLwDSwEHHBEzqDG_Jrz6HE" />
<meta name="google-site-verification" content="xMd0V-C2YI-S5zDVVCNYLFLwDSwEHHBEzqDG_Jrz6HE" />
	<!-- Danggeun Market Code -->
	<script src="https://karrot-pixel.business.daangn.com/0.2/karrot-pixel.umd.js"></script>
	<script>
		window.karrotPixel.init('1724042065698400001');
		window.karrotPixel.track('ViewPage');
	</script>
	<!-- End Danggeun Market Code -->
	<!-- Danggeun Market Code -->
	<script src="https://karrot-pixel.business.daangn.com/0.4/karrot-pixel.umd.js"></script>
	<script>
		window.karrotPixel.init('1738542627560100001');
		window.karrotPixel.track('ViewPage');
	</script>
	<!-- End Danggeun Market Code -->

<!-- Enliple Tracker Start -->
<script async src="https://cdn.onetag.co.kr/0/tcs.js?eid=1k1zhc4s5tb8y1k1zhc4s5"></script>
<!-- Enliple Tracker End -->

</head>

<body id="sub">

	<!-- Google Tag Manager (noscript) -->
	<noscript>
		<iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5G8269NP" height="0" width="0" style="display:none;visibility:hidden"></iframe>
	</noscript>
	<!-- End Google Tag Manager (noscript) -->

	<div id="skipNavi">
		<ul>
			<li>
				<a href="#container">본문 바로가기</a>
				<a href="#gnb">주메뉴 바로가기</a>
			</li>
		</ul>
	</div>

	<div id="wrap" class="renew2024">
		<header id="header" class="type4 headOn">
			<div class="h_top">
				<div class="h_inner">
					<div class="l_bx gm_font">
						Law&amp;Firm Glory
					</div>
					<div class="r_bx gm_font">
						회생파산센터 서울본사 02-6954-0478 / 회생파산센터 대전지점 042-721-0608 / 대표번호 1544-0904
					</div>
				</div>
			</div>

			<a href="../revive/" class="logo">법무법인 글로리</a>

			<div class="rightFixed">
				<div class="menu_bx">
					<div class="menu_bx_inner">
						<ul class="dep1_wrap">
							<li class="dep1 dep01 a_none">
								<a href="../main/">공식 홈페이지</a>
							</li>
							<li class="dep1 dep02 a_none">
								<a href="../revive/index.php?sec12">성공사례</a>
							</li>
							<li class="dep1 dep03 a_none">
								<a href="../revive/index.php?sec09">전문가 소개</a>
							</li>
							<li class="dep1 dep04 a_none">
								<a href="../revive/index.php?sec13_2">고객 후기</a>
							</li>
							<li class="dep1 dep05 a_none">
								<a href="../revive/index.php?sec16">오시는 길</a>
							</li>
							<li class="dep1 dep06 a_none">
								<a href="../community/notice.php">커뮤니티</a>
							</li>
						</ul>

						<div class="contact_wrap">
							<form method="post" action="/process/revive_quick.php" id="quickform" enctype="multipart/form-data">
								<input type="hidden" name="gubun" value="revive_quick">
								<input type="hidden" name="captcha_form" value="revivequick">
								<div class="contact_tel">
									<span>1:1 전화상담</span>
									<a href="tel:15440904" class="telNum gm_font">1544-0904</a>
								</div>
								<div class="contact_form">
									<div><input type="text" name="name" placeholder="성함" autocomplete='off'></div>
									<div>
										<select name="region">
												<option value="">지역</option>
																									<option  value="1">서울</option>
																									<option  value="2">인천</option>
																									<option  value="3">세종</option>
																									<option  value="4">대전</option>
																									<option  value="5">대구</option>
																									<option  value="6">울산</option>
																									<option  value="7">광주</option>
																									<option  value="8">부산</option>
																									<option  value="9">제주</option>
																									<option  value="10">강원도</option>
																									<option  value="11">경기도</option>
																									<option  value="12">충청북도</option>
																									<option  value="13">충청남도</option>
																									<option  value="14">경상북도</option>
																									<option  value="15">경상남도</option>
																									<option  value="16">전라북도</option>
																									<option  value="17">전라남도</option>
																						</select>
									</div>
									<div>
										<select name="fields">
											<option value="" data-ph="true">분야</option>
											<option value="1">개인회생</option>
											<option value="2">개인파산</option>
											<option value="3">법인회생/파산</option>
										</select>
									</div>
									<div><input type="text" name="tel" placeholder="연락처" autocomplete='off'></div>
									<div class="chk_bx">
										<input type="checkbox" id="q_agree" name="safeguard" checked="checked">
										<label for="q_agree">개인정보수집에 동의합니다.</label>
									</div>
									<div class="captcha" style="height: 60px">
										<span id="reCaptcha4">
											<img src="/kor/inc/kcaptcha/?form=revivequick&PHPSESSID=q25mjso2juik2cjnnsqs3lcugk&rand=768838244">
										</span>
										<p><input type="text" name="captcha" placeholder="보안 문자 입력" /></p>
									</div>

									<button type="button" onclick="quickSend(); return false;" class="contactBtn">신청하기</button>

								</div>
							</form>
						</div>

						<div class="consultLink_bx">
							<a href="../consult/list.php" class="btn"><img src="../images/icon/consult_1.png">게시판 상담</a>
							<a href="../revive/visit.php" class="btn"><img src="../images/icon/consult_2.png">방문상담</a>
						</div>

						<div class="sns_bx">
							<a href="https://pf.kakao.com/_gPkyxj" target="_blank" class="btn"><img src="../images/icon/sns_kakao.png">카카오톡 실시간 상담</a>
							<a href="https://blog.naver.com/tphyak80" target="_blank" class="btn"><img src="../images/icon/sns_naver.png">블로그</a>
							<a href="https://www.instagram.com/glory_lawfirm/?igshid=MzRlODBiNWFlZA%3D%3D" target="_blank" class="btn"><img src="../images/icon/sns_insta.png">인스타그램</a>
						</div>
					</div>
				</div>
			</div>

			<div class="sm_bx">
				<div class="sm_w">
				</div>
			</div>

			<div class="r_bx">
				<div class="menu_btn m_show">
					<span></span>
					<span></span>
					<span></span>
				</div>
			</div>
		</header><!-- //header -->

		<script type="text/javascript">
			$("#main #header.type4 .logo").click(function() {
				$('html, body').animate({
					scrollTop: $('#sec01').offset().top
				}, 700);
				return false;
			});

			$("#main #header.type4 .menu_bx .dep02 > a").click(function() {
				$('html, body').animate({
					scrollTop: $('#sec12').offset().top
				}, 700);
				return false;
			});

			$("#main #header.type4 .menu_bx .dep03 > a").click(function() {
				$('html, body').animate({
					scrollTop: $('#sec09').offset().top
				}, 700);
				return false;
			});

			$("#main #header.type4 .menu_bx .dep04 > a").click(function() {
				$('html, body').animate({
					scrollTop: $('#sec13_2').offset().top - 70
				}, 700);
				return false;
			});

			$("#main #header.type4 .menu_bx .dep05 > a").click(function() {
				$('html, body').animate({
					scrollTop: $('#sec16').offset().top
				}, 700);
				return false;
			});

			// $("#main #header.type4 .menu_bx .dep06 > a").click(function() {
			// 	$('html, body').animate({
			// 		scrollTop: $('#sec05_2').offset().top - 70
			// 	}, 700);
			// 	return false;
			// });

			function mMenu() {
				$("#main #header.type4 .logo").click(function() {
					$('html, body').animate({
						scrollTop: $('#sec01').offset().top
					}, 700);
					return false;
				});

				$("#main #header.type4 .sm_bx .dep02 > a").click(function() {
					$('html, body').animate({
						scrollTop: $('#sec12').offset().top
					}, 700);

					$("#header .menu_btn").trigger("click");

					return false;
				});

				$("#main #header.type4 .sm_bx .dep03 > a").click(function() {
					$('html, body').animate({
						scrollTop: $('#sec09').offset().top
					}, 700);

					$("#header .menu_btn").trigger("click");

					return false;
				});

				$("#main #header.type4 .sm_bx .dep04 > a").click(function() {
					$('html, body').animate({
						scrollTop: $('#sec13_2').offset().top
					}, 700);

					$("#header .menu_btn").trigger("click");

					return false;
				});

				$("#main #header.type4 .sm_bx .dep05 > a").click(function() {
					$('html, body').animate({
						scrollTop: $('#sec16').offset().top
					}, 700);

					$("#header .menu_btn").trigger("click");

					return false;
				});

				// $("#main #header.type4 .sm_bx .dep06 > a").click(function() {
				// 	$('html, body').animate({
				// 		scrollTop: $('#sec05_2').offset().top
				// 	}, 700);

				// 	$("#header .menu_btn").trigger("click");

				// 	return false;
				// });
			}

			var thisUrl = window.location.href;
			if (thisUrl.split("?").length > 1) {
				var thisUrlId = thisUrl.split("?")[1];

				setTimeout(function() {
					if ($(window).width() > 1024) {
						$('html, body').animate({
							scrollTop: $('#' + thisUrlId).offset().top - 70
						}, 500);
					} else {
						$('html, body').animate({
							scrollTop: $('#' + thisUrlId).offset().top
						}, 500);
					}
				}, 200);
			}
		</script>
		<script>
			function quickSend() {
				var f = document.getElementById('quickform');
				var safeguard = $('#quickform [name=safeguard]:checkbox').prop('checked');

				if (!$.trim(f.name.value)) {
					alert("이름을 입력해주세요.");
					f.name.focus();
					return false;
				} else if (!$.trim(f.tel.value)) {
					alert("연락처를 입력해주세요.");
					f.tel.focus();
					return false;
				} else if(!$.trim(f.region.value)){
					alert("지역을 선택해주세요.");
					return false;
				} else if (!$.trim(f.fields.value)) {
					alert("상담분야를 선택해주세요.");
					return false;
				} else if (safeguard == false) {
					alert("개인정보수집 및 이용동의 약관에 동의하세요.");
					return false;
				}else if (!f.captcha.value.trim()) {
					alert("보안 문자를 입력해 주십시오.");
					return false;
				} else {
					// Danggeun Market Code
					window.karrotPixel.track('SubmitApplication');
					// End Danggeun Market Code
					gtag('event', 'conversion', {
						'send_to': 'AW-16871756070/Ahg0CIGttqkaEKaiiu0-',
						'value': 1.0,
						'currency': 'KRW'
						});
					f.submit();
				}
			}

		</script>

		<script>
    document.querySelector('#reCaptcha4').addEventListener('click', function() {
        this.innerHTML = '<img src="/kor/inc/kcaptcha/?form=revivequick&PHPSESSID=q25mjso2juik2cjnnsqs3lcugk&rand=' + Math.random() + '">';
    });
		</script>
<link href="../css/main_revive.css" rel="stylesheet" type="text/css">
<link href="../css/sub_revive_2024.css" rel="stylesheet" type="text/css">

<div id="container" class="sub2024">
	<div id="contents">
		<div id="blog" class="blog_board">
			<div class="box box1">
				<div class="ttl_bx">
					<strong>글로리 칼럼</strong>
					<p>개인회생파산에 대한 모든것</p>
				</div>

				<div class="inner_bx">

					
					<div id="board">
						
						<div class="list_top">
							<div class="count">총 <span>23 </span>개의 게시물</div>
							<div class="search_bx">
								<form name="searchFrm" id="bd_search">									
									<input type="text" name="sorder" id="sorder" value="" placeholder="검색어를 입력해주세요.">
									<a href="#" class="btn" id="btn_search">검색</a>
								</form>
							</div>
						</div>

						<div class="list_st06">
							<div class="list_w">
																<a href="https://blog.naver.com/tphyak80/223206068562" target="_blank" class="con_bx">
									<div class="imgBox">
										<div style="background:url(../images/blog/blog_thumbImg03.jpg)"></div>
									</div>
									<div class="textBox">
										<div class="subject">개인회생 부양가족 관계 변수가 있나 [출처] 법무법인 글로리 블로그</div>
										<div class="txt">네이버 블로그(법무법인 글로리)</div>
									</div>
								</a>
																<a href="https://blog.naver.com/PostView.naver?blogId=tphyak80&logNo=223313527449&categoryNo=13&parentCategoryNo=0&viewDate=&currentPage=1&postListTopCurrentPage=&from=postList&userTopListOpen=true&userTopListCount=30&userTopListManageOpen=false&userTopListCurrent" target="_blank" class="con_bx">
									<div class="imgBox">
										<div style="background:url(../images/blog/blog_thumbImg07.jpg)"></div>
									</div>
									<div class="textBox">
										<div class="subject">신용회복제도 신청 조건 절차까지</div>
										<div class="txt">개인신용회복제도 신청 조건 절차까지 : 네이버 블로그 (naver.com)</div>
									</div>
								</a>
																<a href="https://blog.naver.com/PostView.naver?blogId=tphyak80&logNo=223298466896&categoryNo=13&parentCategoryNo=0&viewDate=&currentPage=1&postListTopCurrentPage=&from=postList&userTopListOpen=true&userTopListCount=30&userTopListManageOpen=false&userTopListCurrent" target="_blank" class="con_bx">
									<div class="imgBox">
										<div style="background:url(../images/blog/blog_thumbImg04.jpg)"></div>
									</div>
									<div class="textBox">
										<div class="subject">개인회생 접수, 기간, 신청부터 개시까지 </div>
										<div class="txt">개인회생 접수 기간 신청부터 개시결정까지 : 네이버 블로그 (naver.com)</div>
									</div>
								</a>
																<a href="https://cafe.naver.com/daejintechclub/355" target="_blank" class="con_bx">
									<div class="imgBox">
										<div style="background:url(../images/blog/blog_thumbImg07.jpg)"></div>
									</div>
									<div class="textBox">
										<div class="subject">비트코인으로 인하여 생긴 채무 개인 회생가능할까?</div>
										<div class="txt">글로리 회생파산 네이버 카페 (https://cafe.naver.com/daejintechclub)</div>
									</div>
								</a>
																<a href="https://blog.naver.com/tphyak80/223291571093" target="_blank" class="con_bx">
									<div class="imgBox">
										<div style="background:url(../images/blog/blog_thumbImg03.jpg)"></div>
									</div>
									<div class="textBox">
										<div class="subject">세금체납 개인회생 면책 가능할까?</div>
										<div class="txt">세금체납 개인회생 면책 가능할까? : 네이버 블로그(https://blog.naver.com/tphyak80/223291571093)</div>
									</div>
								</a>
																<a href="https://blog.naver.com/tphyak80/223310217868" target="_blank" class="con_bx">
									<div class="imgBox">
										<div style="background:url(../images/blog/blog_thumbImg05.jpg)"></div>
									</div>
									<div class="textBox">
										<div class="subject">채무조정교섭 추심에서 벗어날 방법으로</div>
										<div class="txt">채무조정교섭 추심에서 벗어날 방법으로 : 네이버블로그(https://blog.naver.com/tphyak80)</div>
									</div>
								</a>
																
							</div>
													</div>
						<!-- 페이징 -->
						<div class="page_bx">
							<a class='page_first'>first</a>
<a class='page_prev'>prev</a>
<a class='num on'>1</a>
<a href='/kor/revive/blog.php?pNo=2' class='num'>2</a>
<a href='/kor/revive/blog.php?pNo=3' class='num'>3</a>
<a href='/kor/revive/blog.php?pNo=4' class='num'>4</a>
<a class='page_next'>next</a>
<a class='page_last'>last</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div><!-- //contents -->
</div><!-- //container -->

<script>
	$('select#sitem').val('all');
	$('#btn_search').on('click', function() {
		$('form#bd_search').submit();
	});
</script>

		<footer id="footer" class="indexNum_">	
		<div class="inner">		
			<div class="btm_bx">
				<div class="f_inner">
					<img src="../images/common/f_logo.png" class="logo" alt="법무법인 글로리">
					<ul class="link_bx">
						<li><a href="../company/intro.php">법인소개</a></li>
						<li><a href="../policy/privacy.php">개인정보처리방침</a></li>
						<li><a href="../business/areas.php">업무영역</a></li>
						<li class="dotN"><a href="/kor/revive/review.php">후기</a></li>
												<li><a class="quick_btn">상담신청</a></li>
												<li><a href="../community/notice.php">커뮤니티</a></li>
					</ul>
					<!-- <ul class="info_bx">
    						<li>상호 : 법무법인 글로리</li>
    						<li>사업자등록번호 : 604-86-02992</li>
    						<li>대표변호사 : 이아무</li>
    						<li>주소 : 대전광역시 서구 둔산중로 78번길 26, 민석타워 3층 301호</li>
    						<li>대표번호 : 1544-0904(대표번호) / 042-721-0608(회생파산) / 042-721-0606(송무)</li>
    						<li>팩스 : 042-721-0707</li>
    						<li>이메일 : glory@glorylawfirm.kr</li>
    					</ul> -->
						<ul class="info_bx">
						<li>상호 : 법무법인 글로리</li>
						<li>사업자등록번호 : 604-86-02992</li>
						<li>대표변호사 : 이아무</li>
						<li>대표번호 : 1544-0904</li>
						<li>이메일 : glorylawfirm@daum.net</li>
						<li>서울본사 : 서울특별시 강남구 테헤란로8길 13, 9층 (역삼동, WD빌딩) <span>| TEL : 02-6954-0478(회생파산), 02-6954-0378(송무)</span> <span>| FAX : 02-6954-0878</span></li>
						<li>대전지점 : 대전광역시 서구 둔산중로 78번길 26, 민석타워 3층 301호 <span>| TEL : 042-721-0608(회생파산), 042-721-0606(송무)</spaan> <span>| FAX : 042-721-0707</span></li>
					</ul>
					<p class="btm_txt">Copyright © 2023 Law Firm Glory. All Rights Reserved.</p>
				</div>
			</div>
			</div>
		</footer>
	</div><!-- //wrap -->
	
	<script type="text/javascript">
		AOS.init({
			once: true,
			startEvent: 'load',
			disable: function() {
				//var maxWidth = 1024;
				//return window.innerWidth < maxWidth;
			}
		});
                
		
	</script>

		
<!-- NAVER SCRIPT START -->
<script type="text/javascript" src="//wcs.naver.net/wcslog.js"></script>
<script type="text/javascript">
if (!wcs_add) var wcs_add={};
wcs_add["wa"] = "s_35d04fef83bb";
if(window.wcs) {
        wcs.inflow("glorylawfirm.kr");
}
wcs_do();
</script>
<!-- NAVER SCRIPT END -->
	
	<!-- Smartlog -->
    <script type="text/javascript"> 
        var hpt_info={'_account':'UHPT-23580', '_server': 'a26'};
    </script>
    <script language="javascript" src="//cdn.smlog.co.kr/core/smart.js" charset="utf-8"></script>
    <noscript><img src="//a26.smlog.co.kr/smart_bda.php?_account=23580" style="display:none;width:0;height:0;" border="0"/></noscript>  	
</body>
</html>
