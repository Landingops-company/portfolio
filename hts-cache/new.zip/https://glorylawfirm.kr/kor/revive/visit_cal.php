						
<div class="title">예약 날짜 선택</div>
<div class="calenderWrap">
	<div class="month">
		<a href="" onclick="prev_month();return false;" class="prevMonth">이전달</a>
		<a href="" onclick="" class="currentMonth">. </a>
		<a href="" onclick="next_month();return false;" class="nextMonth">다음달</a>
	</div>
	<div class="calTableWrap">
		<table class="calTable" summary="날짜선택">
			<thead>
				<tr>
					<th scope="col">일</th>
					<th scope="col">월</th>
					<th scope="col">화</th>
					<th scope="col">수</th>
					<th scope="col">목</th>
					<th scope="col">금</th>
					<th scope="col" class="last">토</th>
				</tr>
			</thead>
			<tbody>
            <tr><td class="not"></td><td class="not"></td><td class="not"></td><td class="not"></td><td class="not">1 </td><td class="not">2 </td><td class="not">3 </td></tr><tr><td class="not">4 </td><td class="not">5 </td><td class="not">6 </td><td class="not">7 </td><td class="not">8 </td><td class="not">9 </td><td class="not">10 </td></tr><tr><td class="not">11 </td><td class="not">12 </td><td class="not">13 </td><td class="not">14 </td><td class="not">15 </td><td class="not">16 </td><td class="not">17 </td></tr><tr><td class="not">18 </td><td class="not">19 </td><td class="not">20 </td><td class="not">21 </td><td class="not">22 </td><td class="not">23 </td><td class="not">24 </td></tr><tr><td class="not">25 </td><td class="not">26 </td><td class="not">27 </td><td class="not">28 </td><td class="not">29 </td><td class="not"></td><td class="not"></td></tr>  </tbody>		</table>
	</div>
	<div class="visitDateText">
		<span class="visitDate"></span><span>을 선택하셨습니다.</span>
	</div>
</div>						