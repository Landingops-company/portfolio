
<!DOCTYPE html>
<html lang="ko">

<head>
	<title>법무법인 글로리 회생파산센터 - 대전 개인회생, 대전 개인파산, 대전개인회생 전문, 대전개인회생변호사, 대전회생변호사, 대전회생, 대전법인파산</title>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="format-detection" content="telephone=no" />
	<link rel="canonical" href="https://glorylawfirm.kr/kor/revive/review.php" />

	<meta name="description" content="개인회생,개인회생신청자격,개인파산,개인회생신청,개인회생금지명령,개인회생파산,회생전문변호사,개인회생변제금,개인회생신용회복,회생,개인회생변호사,개인회생기간단축,개인워크아웃,대전개인회생,대구개인회생,수원회생법원,파산신청,창원개인회생,부산개인회생,개인회생재신청,개인회생비용,개인회생절차,채무조정,채무조정제도,대구개인파산,개인파산신청방법,부산개인파산,도박개인회생,부산개인회생상담,개인회생서류,개인회생기간,개인회생보정권고,개인회생신청자격요건,회생신청,개인파산신청자격요건,개인회생면책신청,개인회생인가결정,개인회생개시결정,개인회생조회,개인회생파산차이,개인파산신청,개인회생미납,파산관재인,개인파산면책,서울개인회생,개인회생변호사비용,개인회생수임료,개인회생조건" />
	<meta name="keywords" content="개인회생,개인회생신청자격,개인파산,개인회생신청,개인회생금지명령,개인회생파산,회생전문변호사,개인회생변제금,개인회생신용회복,회생,개인회생변호사,개인회생기간단축,개인워크아웃,대전개인회생,대구개인회생,수원회생법원,파산신청,창원개인회생,부산개인회생,개인회생재신청,개인회생비용,개인회생절차,채무조정,채무조정제도,대구개인파산,개인파산신청방법,부산개인파산,도박개인회생,부산개인회생상담,개인회생서류,개인회생기간,개인회생보정권고,개인회생신청자격요건,회생신청,개인파산신청자격요건,개인회생면책신청,개인회생인가결정,개인회생개시결정,개인회생조회,개인회생파산차이,개인파산신청,개인회생미납,파산관재인,개인파산면책,서울개인회생,개인회생변호사비용,개인회생수임료,개인회생조건" />

	<meta property="og:type" content="website">
	<meta property="og:title" content="법무법인 글로리 회생파산센터 - 대전 개인회생, 대전 개인파산, 대전개인회생 전문, 대전개인회생변호사, 대전회생변호사, 대전회생, 대전법인파산">
	<meta property="og:description" content="대전개인회생파산센터 법무법인 글로리 대전개인회생,대전개인회생전문,대전개인파산,대전개인회생변호사,대전회생변호사,대전회생,대전법인파산, 대전 충남 최대규모 회생파산팀, 합리적인 수임료로 대한민국 1%의 회생파산서비스, 토탈케어서비스">

	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, minimum-scale=1.0, user-scalable=no" />
	<link href="https://fonts.googleapis.com/css2?family=Noto+Serif+KR:wght@200;300;400;500;600;700;900&display=swap" rel="stylesheet"><!-- font-family: 'Noto Serif KR', serif; -->
	<link href="https://fonts.googleapis.com/css2?family=Noto+Serif:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
	<link rel="stylesheet" as="style" crossorigin href="https://cdn.jsdelivr.net/gh/ungveloper/web-fonts/GmarketSans/font-face.css" />
	<link rel="stylesheet" as="style" crossorigin href="https://cdn.jsdelivr.net/gh/ungveloper/web-fonts/GmarketSans/font-face.css" /> <!-- 지마켓산스 -->

	<!-- font -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;500;600;700;800;900&family=Montserrat:wght@100;200;300;400;500;600;700;800;900&family=Nanum+Myeongjo:wght@400;700;800&display=swap" rel="stylesheet">

	<link href="../css/base.css?230830" rel="stylesheet" type="text/css" />
	<link href="../css/common.css?230830" rel="stylesheet" type="text/css" />
	<link href="../css/main.css?230830" rel="stylesheet" type="text/css" />
	<link href="../css/sub.css?230830" rel="stylesheet" type="text/css" />
	<link href="../css/board.css?230830" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="../images/favicon.ico" type="image/x-icon">

	<!--[if lt IE 9]>
		<script src="../js/html5shiv.js"></script>
		<script src="../js/respond.min.js"></script>
		<script type="text/javascript">
			alert('현재 업데이트의 지원이 중단되어 보안이 취약한 하위버전의 브라우저를 사용하고 계십니다.\n원활한 사이트 이용을 위해서는 Internet Explorer 최신 버전으로 업데이트 하시거나,\n타 브라우저 (구글 크롬, 파이어폭스, 네이버 웨일) 사용을 권장합니다.');
		</script>
	<![endif]-->

	<!-- Google Tag Manager -->
	<script>
		(function(w, d, s, l, i) {
			w[l] = w[l] || [];
			w[l].push({
				'gtm.start': new Date().getTime(),
				event: 'gtm.js'
			});
			var f = d.getElementsByTagName(s)[0],
				j = d.createElement(s),
				dl = l != 'dataLayer' ? '&l=' + l : '';
			j.async = true;
			j.src =
				'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
			f.parentNode.insertBefore(j, f);
		})(window, document, 'script', 'dataLayer', 'GTM-5G8269NP');
	</script>
	<!-- End Google Tag Manager -->
	<!-- Google tag (gtag.js) -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=AW-16871756070"></script>
	<script>
	window.dataLayer = window.dataLayer || [];
	function gtag(){dataLayer.push(arguments);}
	gtag('js', new Date());
	gtag('config', 'AW-16871756070');
	</script>
	<!--  END Google tag (gtag.js) -->

	<script src="../js/jquery-3.7.0.min.js"></script>
	<script src="../js/slick.min.js"></script>
	<!-- <script src="../js/common.js"></script> -->
	<script src="../js/common_2024.js"></script>
	<script src="/aseoul/js/dev.js"></script>

	<!-- aos -->
	<link href="../css/aos.css" rel="stylesheet" type="text/css" />
	<script src="../js/aos.js"></script>

	<meta name="naver-site-verification" content="2f95426658d0c9954d3c8c8822f0aecc856dd101" />
<meta name="google-site-verification" content="xMd0V-C2YI-S5zDVVCNYLFLwDSwEHHBEzqDG_Jrz6HE" />
<meta name="google-site-verification" content="xMd0V-C2YI-S5zDVVCNYLFLwDSwEHHBEzqDG_Jrz6HE" />
	<!-- Danggeun Market Code -->
	<script src="https://karrot-pixel.business.daangn.com/0.2/karrot-pixel.umd.js"></script>
	<script>
		window.karrotPixel.init('1724042065698400001');
		window.karrotPixel.track('ViewPage');
	</script>
	<!-- End Danggeun Market Code -->
	<!-- Danggeun Market Code -->
	<script src="https://karrot-pixel.business.daangn.com/0.4/karrot-pixel.umd.js"></script>
	<script>
		window.karrotPixel.init('1738542627560100001');
		window.karrotPixel.track('ViewPage');
	</script>
	<!-- End Danggeun Market Code -->

<!-- Enliple Tracker Start -->
<script async src="https://cdn.onetag.co.kr/0/tcs.js?eid=1k1zhc4s5tb8y1k1zhc4s5"></script>
<!-- Enliple Tracker End -->

</head>

<body id="sub">

	<!-- Google Tag Manager (noscript) -->
	<noscript>
		<iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5G8269NP" height="0" width="0" style="display:none;visibility:hidden"></iframe>
	</noscript>
	<!-- End Google Tag Manager (noscript) -->

	<div id="skipNavi">
		<ul>
			<li>
				<a href="#container">본문 바로가기</a>
				<a href="#gnb">주메뉴 바로가기</a>
			</li>
		</ul>
	</div>

	<div id="wrap" class="renew2024">
		<header id="header" class="type4 ">
			<div class="h_top">
				<div class="h_inner">
					<div class="l_bx gm_font">
						Law&amp;Firm Glory
					</div>
					<div class="r_bx gm_font">
						회생파산센터 서울본사 02-6954-0478 / 회생파산센터 대전지점 042-721-0608 / 대표번호 1544-0904
					</div>
				</div>
			</div>

			<a href="../revive/" class="logo">법무법인 글로리</a>

			<div class="rightFixed">
				<div class="menu_bx">
					<div class="menu_bx_inner">
						<ul class="dep1_wrap">
							<li class="dep1 dep01 a_none">
								<a href="../main/">공식 홈페이지</a>
							</li>
							<li class="dep1 dep02 a_none">
								<a href="../revive/index.php?sec12">성공사례</a>
							</li>
							<li class="dep1 dep03 a_none">
								<a href="../revive/index.php?sec09">전문가 소개</a>
							</li>
							<li class="dep1 dep04 a_none">
								<a href="../revive/index.php?sec13_2">고객 후기</a>
							</li>
							<li class="dep1 dep05 a_none">
								<a href="../revive/index.php?sec16">오시는 길</a>
							</li>
							<li class="dep1 dep06 a_none">
								<a href="../community/notice.php">커뮤니티</a>
							</li>
						</ul>

						<div class="contact_wrap">
							<form method="post" action="/process/revive_quick.php" id="quickform" enctype="multipart/form-data">
								<input type="hidden" name="gubun" value="revive_quick">
								<input type="hidden" name="captcha_form" value="revivequick">
								<div class="contact_tel">
									<span>1:1 전화상담</span>
									<a href="tel:15440904" class="telNum gm_font">1544-0904</a>
								</div>
								<div class="contact_form">
									<div><input type="text" name="name" placeholder="성함" autocomplete='off'></div>
									<div>
										<select name="region">
												<option value="">지역</option>
																									<option  value="1">서울</option>
																									<option  value="2">인천</option>
																									<option  value="3">세종</option>
																									<option  value="4">대전</option>
																									<option  value="5">대구</option>
																									<option  value="6">울산</option>
																									<option  value="7">광주</option>
																									<option  value="8">부산</option>
																									<option  value="9">제주</option>
																									<option  value="10">강원도</option>
																									<option  value="11">경기도</option>
																									<option  value="12">충청북도</option>
																									<option  value="13">충청남도</option>
																									<option  value="14">경상북도</option>
																									<option  value="15">경상남도</option>
																									<option  value="16">전라북도</option>
																									<option  value="17">전라남도</option>
																						</select>
									</div>
									<div>
										<select name="fields">
											<option value="" data-ph="true">분야</option>
											<option value="1">개인회생</option>
											<option value="2">개인파산</option>
											<option value="3">법인회생/파산</option>
										</select>
									</div>
									<div><input type="text" name="tel" placeholder="연락처" autocomplete='off'></div>
									<div class="chk_bx">
										<input type="checkbox" id="q_agree" name="safeguard" checked="checked">
										<label for="q_agree">개인정보수집에 동의합니다.</label>
									</div>
									<div class="captcha" style="height: 60px">
										<span id="reCaptcha4">
											<img src="/kor/inc/kcaptcha/?form=revivequick&PHPSESSID=q25mjso2juik2cjnnsqs3lcugk&rand=1266979159">
										</span>
										<p><input type="text" name="captcha" placeholder="보안 문자 입력" /></p>
									</div>

									<button type="button" onclick="quickSend(); return false;" class="contactBtn">신청하기</button>

								</div>
							</form>
						</div>

						<div class="consultLink_bx">
							<a href="../consult/list.php" class="btn"><img src="../images/icon/consult_1.png">게시판 상담</a>
							<a href="../revive/visit.php" class="btn"><img src="../images/icon/consult_2.png">방문상담</a>
						</div>

						<div class="sns_bx">
							<a href="https://pf.kakao.com/_gPkyxj" target="_blank" class="btn"><img src="../images/icon/sns_kakao.png">카카오톡 실시간 상담</a>
							<a href="https://blog.naver.com/tphyak80" target="_blank" class="btn"><img src="../images/icon/sns_naver.png">블로그</a>
							<a href="https://www.instagram.com/glory_lawfirm/?igshid=MzRlODBiNWFlZA%3D%3D" target="_blank" class="btn"><img src="../images/icon/sns_insta.png">인스타그램</a>
						</div>
					</div>
				</div>
			</div>

			<div class="sm_bx">
				<div class="sm_w">
				</div>
			</div>

			<div class="r_bx">
				<div class="menu_btn m_show">
					<span></span>
					<span></span>
					<span></span>
				</div>
			</div>
		</header><!-- //header -->

		<script type="text/javascript">
			$("#main #header.type4 .logo").click(function() {
				$('html, body').animate({
					scrollTop: $('#sec01').offset().top
				}, 700);
				return false;
			});

			$("#main #header.type4 .menu_bx .dep02 > a").click(function() {
				$('html, body').animate({
					scrollTop: $('#sec12').offset().top
				}, 700);
				return false;
			});

			$("#main #header.type4 .menu_bx .dep03 > a").click(function() {
				$('html, body').animate({
					scrollTop: $('#sec09').offset().top
				}, 700);
				return false;
			});

			$("#main #header.type4 .menu_bx .dep04 > a").click(function() {
				$('html, body').animate({
					scrollTop: $('#sec13_2').offset().top - 70
				}, 700);
				return false;
			});

			$("#main #header.type4 .menu_bx .dep05 > a").click(function() {
				$('html, body').animate({
					scrollTop: $('#sec16').offset().top
				}, 700);
				return false;
			});

			// $("#main #header.type4 .menu_bx .dep06 > a").click(function() {
			// 	$('html, body').animate({
			// 		scrollTop: $('#sec05_2').offset().top - 70
			// 	}, 700);
			// 	return false;
			// });

			function mMenu() {
				$("#main #header.type4 .logo").click(function() {
					$('html, body').animate({
						scrollTop: $('#sec01').offset().top
					}, 700);
					return false;
				});

				$("#main #header.type4 .sm_bx .dep02 > a").click(function() {
					$('html, body').animate({
						scrollTop: $('#sec12').offset().top
					}, 700);

					$("#header .menu_btn").trigger("click");

					return false;
				});

				$("#main #header.type4 .sm_bx .dep03 > a").click(function() {
					$('html, body').animate({
						scrollTop: $('#sec09').offset().top
					}, 700);

					$("#header .menu_btn").trigger("click");

					return false;
				});

				$("#main #header.type4 .sm_bx .dep04 > a").click(function() {
					$('html, body').animate({
						scrollTop: $('#sec13_2').offset().top
					}, 700);

					$("#header .menu_btn").trigger("click");

					return false;
				});

				$("#main #header.type4 .sm_bx .dep05 > a").click(function() {
					$('html, body').animate({
						scrollTop: $('#sec16').offset().top
					}, 700);

					$("#header .menu_btn").trigger("click");

					return false;
				});

				// $("#main #header.type4 .sm_bx .dep06 > a").click(function() {
				// 	$('html, body').animate({
				// 		scrollTop: $('#sec05_2').offset().top
				// 	}, 700);

				// 	$("#header .menu_btn").trigger("click");

				// 	return false;
				// });
			}

			var thisUrl = window.location.href;
			if (thisUrl.split("?").length > 1) {
				var thisUrlId = thisUrl.split("?")[1];

				setTimeout(function() {
					if ($(window).width() > 1024) {
						$('html, body').animate({
							scrollTop: $('#' + thisUrlId).offset().top - 70
						}, 500);
					} else {
						$('html, body').animate({
							scrollTop: $('#' + thisUrlId).offset().top
						}, 500);
					}
				}, 200);
			}
		</script>
		<script>
			function quickSend() {
				var f = document.getElementById('quickform');
				var safeguard = $('#quickform [name=safeguard]:checkbox').prop('checked');

				if (!$.trim(f.name.value)) {
					alert("이름을 입력해주세요.");
					f.name.focus();
					return false;
				} else if (!$.trim(f.tel.value)) {
					alert("연락처를 입력해주세요.");
					f.tel.focus();
					return false;
				} else if(!$.trim(f.region.value)){
					alert("지역을 선택해주세요.");
					return false;
				} else if (!$.trim(f.fields.value)) {
					alert("상담분야를 선택해주세요.");
					return false;
				} else if (safeguard == false) {
					alert("개인정보수집 및 이용동의 약관에 동의하세요.");
					return false;
				}else if (!f.captcha.value.trim()) {
					alert("보안 문자를 입력해 주십시오.");
					return false;
				} else {
					// Danggeun Market Code
					window.karrotPixel.track('SubmitApplication');
					// End Danggeun Market Code
					gtag('event', 'conversion', {
						'send_to': 'AW-16871756070/Ahg0CIGttqkaEKaiiu0-',
						'value': 1.0,
						'currency': 'KRW'
						});
					f.submit();
				}
			}

		</script>

		<script>
    document.querySelector('#reCaptcha4').addEventListener('click', function() {
        this.innerHTML = '<img src="/kor/inc/kcaptcha/?form=revivequick&PHPSESSID=q25mjso2juik2cjnnsqs3lcugk&rand=' + Math.random() + '">';
    });
		</script>
<link href="../css/main_revive.css" rel="stylesheet" type="text/css">
<link href="../css/sub_revive_2024.css" rel="stylesheet" type="text/css">

<div id="container" class="sub2024">
	<div id="contents">
		<div id="review" class="revive_board">
			<div class="box box1">
				<div class="ttl_bx">
					<strong>글로리의 회생 후기</strong>
					<p>고객의 올바른 동반자로서 진실된 서비스를 제공하기 위하여<br />구성원 각자 끊임없이 혁신에 매진하여 고객의 미래를 설계합니다.</p>
				</div>

				<div class="inner_bx">

										<div class="tab_bx">
						<ul>
														<li>
								<a href="/kor/revive/review.php?lawyer=1">
									<!-- 96x96 -->
									<div class="img" style="background:url('/data/staffData/0392283001686815526.jpg')"></div>
									<div class="name">
										이아무										<span>Lee Ah Moor</span>									</div>
								</a>
							</li>
														<li>
								<a href="/kor/revive/review.php?lawyer=18">
									<!-- 96x96 -->
									<div class="img" style="background:url('/data/staffData/0943916001707983510.jpg')"></div>
									<div class="name">
										김민희										<span>Kim Min Hee</span>									</div>
								</a>
							</li>
														<li>
								<a href="/kor/revive/review.php?lawyer=22">
									<!-- 96x96 -->
									<div class="img" style="background:url('/data/staffData/0651915001733809829.jpg')"></div>
									<div class="name">
										강문영										<span>Kang Moon Young</span>									</div>
								</a>
							</li>
													</ul>
					</div>
					
					<div id="board">
						<div class="list_top">
							<div class="count">총 <span>102</span>개의 게시물</div>
							<div class="search_bx">
								<form name="searchFrm" id="bd_search">
									<input type="hidden" name="lawyer" value="">
									<input type="text" name="sorder" id="sorder" value="" placeholder="검색어를 입력해주세요.">
									<a href="#" class="btn" id="btn_search">검색</a>
								</form>
							</div>
						</div>

						<div class="list_st02">
							<div class="list_w">
																<a href="review_view.php?idx=44&sorder=" class="con_bx">
									<div class="subject">면책후기입니다.</div>
									<div class="txt">안녕하세요. 

 

저는 확정된 개인회생 변제기간 동안 변제를 모두 마치고 오늘 면책결정을 받은 신청인입니다.

 

어느덧 3년이라는 시간이 흘러 면책결정을 받은 지금 이 순간이 너무 행복해서 저의 개인회생이 면책결정을 받기까지 도움을 주

 

신 법무법인 글로리의 변호사님 이하 직원분들에게 감사를 표하고자 글을 적습니다.

 

저는 빚이 많았습니다.. 어린 나이에 아내를 만나서 변변한 직업 없이 결혼을 하게 되었고 대학교도 졸업하지 못한 어린 나이에

 

좋은 직장에 들어가기는 어려웠습니다. 공사 현장에서 막노동도 하고, 아르바이트도 하고 아내와 함께 살아보고자 여러가지 일

 

을 가리지 않고 열심히 살았습니다. 그러던 중에 저희 부부를 축복해주는 것 같이 아이가 생겼고 저는 더 열심히 살아야겠다는

 

다짐과 함께 열심히 살았습니다. 하지만, 고정적으로 지출되는 생활비는 늘어만 갔고 아내는 아이를 맡아 돌봐야 했기에 일을 할

 

수가 없었습니다. 오로지 생활비는 저혼자 부담을 해야 했고 밤,낮 가리지 않고 열심히 일했습니다. 그때 갑작스러운 교통사고를

 

당해서 장기간 병원에 입원을 할 수 밖에 없는 상황에 놓여졌고, 모아놓은 돈이 없었던 저는 대출을 받아 생활해야 했습니다. 제

 

가 얻는 수익으로는 대출금을 갚으며 생활하기에 어려웠고 쌓여만 가는 대출금과 카드값은 무거운 짐이 되어 돌아왔습니다. 오

 

늘을 버티기 위해 카드론을 받아서 돌려막기를 하고 오늘을 버티기 위해 저축은행에서 대출을 받아서 돌려막고, 눈 앞이 캄캄했

 

습니다. 이렇게 무의미한 돌려막기만 한다고 해서 해결이 되지 않는다는 판단 하에 방법을 찾아봤고 개인회생이라는 제도를 접

 

했습니다. 인터넷에 검색도 해보고 카페글, 블로그글 등 여러 곳에 상담 신청도 해봤습니다. 그 중에서 가장 마음에 들었던 곳이

 

법무법인 글로리였습니다. 상담시부터 저의 심정을 헤아려주시고, 유형별로 어떠한 진행이 예측되는지 섬세한 상담에 이끌려 계

 

약까지 하게 되었고 모든 법원의 보정 절차를 마쳐 개시결정까지 받았습니다. 개시결정 이후 매월 변제금 납부를 밀리지 않기 위

 

해서 계획하고 철저한 삶을 살았습니다. 오늘 면책 결정을 받기까지 여러 어려움이 있었지만, 현재 부담하고 있는 채무를 모두 

 

갚을 수는 없어도 제가 가지고 있는 능력 안에서 최선을 다해 변제를 하고 면책을 받고 싶은 마음 뿐이었습니다. 제가 모든 채

 

무에 대하여 면책 결정을 받을 수 있도록 도와주셔서 무한한 감사의 인사를 드리며, 앞으로 저희 세가족 더 열심히 살겠습니다.

 

현재 많은 부채로 인해서 힘들 삶을 살고 계신 분들을 위해서 힘써주시는 법무법인 글로리의 번창을 기원합니다. </div>
									<div class="info">
										<!-- 36x36 -->
										<div class="img" style="background:url('/data/staffData/0392283001686815526.jpg')"></div>
										<span>개인회생</span>
									</div>
								</a>
																<a href="review_view.php?idx=38&sorder=" class="con_bx">
									<div class="subject">개인회생 두번째 확정됐습니다.</div>
									<div class="txt">글로리 모든 직원분들 감사합니다. 

6개월만에 개인회생 확정되었습니다.

약 2억을 주식으로 다 날렸거든요..

 

일단, 글로리가 좋은점!

 

첫번째 개인회생이 빠르다

 

두번째 법무법인글로리는 채권자를 추가할 때 추가비를 요구하지 않는다.

저는 채권자가 다 어디있는지 잘 몰라서 중간중간 채권자를 추가 많이 했거든요. 채권자 추가해도 추가 비용이 없어요!

부채증명서 발급 받거나 그런 수수료는 당연히 들어가는 비용이니까 뺐습니다!

 

세번째 글로리는 개인회생 비용 및 변호사비가 저렴하다. 그리고 분납도 가능해요.

 

이제 제 얘기를 하겠습니다!

 

처음에 확정 받은 개인회생은 변제금이 150만원 정도로 확정을 받아서 너무 힘들었구요. 급여는 200만원이었습니다.

 

50만원 정도로 생활은 힘들죠.. 밥값에 차비 하면,

 

5년간 개인 빚이 있어서 혼자여도 생활이 불가능했고 2년 정도 납부하다가 포기했습니다.

 

그래서 처음 개인회생은 확정을 받고 못 갚아서 취소됐구요.

 

두번째는 아버지 부양하는 걸 추가생계비로 인정 받아서 월 변제금이 많이 낮아졌구요. 100만원 정도

 

3년으로 갚을 수 있어서 너무 좋아요.

 

제가 두번째 개인회생 하면서 느낀 중요한 점은요.

 

개인회생 하실때 준비서류 빨리 제출하시면 빨리 진행되구요.

 

법률 비용 빨리 내시구요.

 

개인회생 할때 월 변제금을 낮출 수 있는 방법이 있는지 꼭 물어보셔야 해요.

 

직원분이 하라는대로 하면 빨리 개인회생 개시결정 됩니다!</div>
									<div class="info">
										<!-- 36x36 -->
										<div class="img" style="background:url('/data/staffData/0392283001686815526.jpg')"></div>
										<span>개인회생</span>
									</div>
								</a>
																<a href="review_view.php?idx=34&sorder=" class="con_bx">
									<div class="subject">개인회생사례</div>
									<div class="txt">갑자기 금전적인 문제가 생겨서 급하게 개인회생을 신청해야되는 상황해 놓였습니다. 

개인회생에 대한 정보가 전무하다보니 혼자 진행을 하는 것이 맞는지, 아니면 사건을 맞겨야 하는지 

사소한 부분에서부터도 확신이 서지 않을 때 운연히 개인회생 정보를 검색하다가 법무법인 글로리를 알게되었습니다. 

처음에는 간단히 상담이라도 해보자는 심정으로 상담을 신청했는데 생각보다 자세하게 설명해주셔서 제가 알지 못했던

개인회생에 대한 정보를 많이 알 수 있었습니다. 

개인회생에 대해서 성급하게 사건을 맡겼다가 낭패를 봤다는 사례들도 많이 봐서 고민을 많이 했습니다. 

금액도 적당하고 상담을 하고 가장 믿음이 가서 가족들과 고민 끝에 가족들과 상의해서 글로리에 사건을 맡기게 됐습니다.

이후에 사건이 하나씩 진행이 됐고 불안한 마음도 있었지만 많이 도와주신 덕분에 잘 이겨낼 수 있었습니다.

개인회생이 진행되는 과정에서 제가 궁금한 것들 그리고 염려스러운 부분들을 상세하게 알려주시고 

진행되는 과정을 지속적으로 안내해주셔서 마음이 놓였고 직장생활로 서류 준비와 소통에 어려움이 있었음에도 

큰 불편함 없이 일을 진행할 구 있었던 것 같습니다. 

글로리가 제일 좋은 곳인지는 알 수 없지만 맡긴 후에 후회는 없었습니다. 

개인회생은 고려하시는 분들은 제 사례를 보고 참고하셨으면 좋겠습니다. 

여기까지 오는 동안 많이 애써주신 변호사님 직원분들 모두 감사합니다.</div>
									<div class="info">
										<!-- 36x36 -->
										<div class="img" style="background:url('/data/staffData/0392283001686815526.jpg')"></div>
										<span>개인회생</span>
									</div>
								</a>
																<a href="review_view.php?idx=33&sorder=" class="con_bx">
									<div class="subject">힘들었던 시간, 모든 부분을 맡아 도와주셔서 정말 고맙습니다!</div>
									<div class="txt">로나 때문에 살아생전 처음 연체.. 미납.. 추징.. 이 모든걸 최근에 겪었던 탓에 너무 힘들었습니다.

한번도 연체라는 것 없이 수 십년 동안을 지켜왔던 모든 것이 한순간 허무하게 무너져 버렸을때 정말 그 암담한 마음이라는 건 겪어보지 않은 사람은 결코 이해하기 어려운 일이겠죠.

인터넷으로 알아보고 또 망설이고..

계속해서 고민한 하고 고민 끝에 글로리를 결정한 이유는 비용도 비용이지만 상담을 받았을 때 왜 그랬는지 모르겠지만 그냥.. 인간적으로 끌렸고 음.. 뭐랄까 상당히 체계적으로 움직이고 있다는 느낌이 들었어요.

용기를 내서 다른 몇군데를 상담했을 때는 정말 사무장이라는 사람들이 너무도 장사를 한다고 느꼈거든요.

개인회생에 대해서 잘 아는건 아니지만 책임도 못질 뭐 월 10만원 나오게 해준다 뭐 그런 말들 

어디라고 말 하기는 어렵지만 고객이라는 걸 떠나서 그냥 가르치려고만 하고 점점 떨어져가는 마음까지도 더 힘들게 만들었던 사무장, 팀장이라는 사람들까지

나중에 회생이 결정되서 월 비용이 확정되면 법원 탓만 하면서 본인들이 했던 말에 책임 회피만 할 사람들 같은 그런 느낌으로 상담을 받을 때마다 죽고싶은 마음까지 들었던 그 시간들..

그런 상태에서 마지막으로 상담 받은 곳이 글로리였네요.

결과만 놓고 본다면 매달 내야하는 비용도 처음에 예상해주셨던 금액보다 더 낮게 결정이 되도록 도와주셨으니 더없이 감사할 일이구요. 지금 되돌아 생각해보면 국장님과 상담을 하고, 계약하고, 비용도 분할해서 사정 봐주시고, 진행하면서 제가 한 일은 필요한 서류 준비와 마음가짐 뿐이었던 것 같네요.

그렇게 처음부터 끝까지 제가 준비하는 부분은 최소화 해서 다 해주실 줄은 몰랐거든요. 감사의 표현이 감사합니다. 고맙습니다. 이렇게 전부인게 오히려 죄송할 따름입니다.

개시결정문 보내주셨을때 정말 많이 울었어요.

실제로 지난 몇 개월 동안 따뜻하게 저를 생각해주셨던 마음, 저를 공감해주시고 확실하게 말씀해주실 부분은 똑부러지게 해주셨어요. 정말 감사하고 고마웠습니다.

처음 방문했을때 저는 맞이해주셨던 여자 분도, 상담 진행하시면서 제 마음이 열릴때까지 기다려주신 국장님도, 제가 전화하면 안내해주시는 여자분도, 정말 한분 한분 모두 고맙습니다. 

이제 법원에만 다녀오면 모든 절차가 확정된다고 들었습니다. 잘 다녀와서 연락드릴께요.

부족한 글 읽어주셔서 정말 감사합니다. 

이 글을 읽으시는 모든 분들 모드 행복하시길 바래요.</div>
									<div class="info">
										<!-- 36x36 -->
										<div class="img" style="background:url('/data/staffData/0392283001686815526.jpg')"></div>
										<span>개인회생</span>
									</div>
								</a>
																<a href="review_view.php?idx=15&sorder=" class="con_bx">
									<div class="subject">만족합니다.</div>
									<div class="txt">처음 글로리를 찾았을 때는 과연 나도 도움을 받을 수 있을까라는 생각으로 방문했습니다. 

따로 예약도 하지 않았고 지나가다가 방문을 했는데 친절하게 맞이해주셨습니다.

매달 원금, 이자로 내는 돈만 150만원이 넘는 상태여서 실제 생활이 되지 않았고 매월 원금, 이자를 내는 날만 다가오면 숨이 쉬어지지 않을 정도로 심리적인 압박이 심했습니다. 

담당자님께서 현재 나의 상황에 대해서 전체적으로 상담을 도와주셨고 개인회생이 진행 가능하다는 말씀에 저는 뛸 것 같이 기뻤습니다. 

그리고 앞으로 진행 과정에 대해서 상세하게 알려주시고, 매월 내는 돈이 단돈 10만원이라도 줄어든다면 조금 여유있게 살 수 있겠다 싶었습니다.

바로 계약을 마치고, 준비서류를 빠짐 없이 준비하여 신청서를 제출한 결과 한차례의 보정을 마치고 개시결정을 받을 수 있었습니다. 개시결정까지 이렇게 빨리 나올 줄 예상하지 못해서 너무 놀라 담당자님께 재차 물어볼 정도였습니다.

정말 놀라울 정도로 빠르게 개시결정까지 받을 수 있었고, 보정도 너무 간단하게 지나가서 담당자분께서 얼마나 저를 신경써주셨는지 느꼈습니다.

너무너무 감사합니다.  </div>
									<div class="info">
										<!-- 36x36 -->
										<div class="img" style="background:url('/data/staffData/0392283001686815526.jpg')"></div>
										<span>개인회생</span>
									</div>
								</a>
																<a href="review_view.php?idx=49&sorder=" class="con_bx">
									<div class="subject">"회생"한다고 하면 무조건 글로리 강추합니다!!!</div>
									<div class="txt">우선 친절하게 상담해주신 국장님, 전체적으로 꼼꼼하게 진행 담당해주신 대리님!

 

다시한번 고개숙여 감사하다는 말씀드리고 싶습니다!! 최고!!

 

저희는 부부가 동시에 개인회생을 진행했습니다. 

 

오랜기간의 사업과 생활비로 인해 채무가 쌓여 결국 빚이 과다하게 불어났고 도저히 감당할 수 없는 지경에 이르러 

 

매일 지옥같은 삶을 살아가고 있었고 회생이라는 제도를 알게되어 인터넷을 검색하던 중 글로리를 알게되었습니다.

 

무엇보다 제일 끌렸던건 불안했던 저희 부부에게 일관된 친절함으로 상담해주셨던 국장님

 

전반적인 진행상황 및 저희 부부에게 맞춰진 컨설팅으로 정말 많은 심리적인 안정감을 주셨습니다.

 

덕분에 글로리에서 진행을 하기로 하였고 서류 제출 후 대리님이 실무 담당자로 배정이 되어 접수를 하게 되었습니다.

 

서류 접수 꼼꼼히 검토해주셨으며 저희 부부에게 맞춰 최소한의 변제율 및 보정권고에 빠른 대응 해주셨습니다.

 

덕분에 금지결정도 바로 받을 수 있었고 보정도 한번에 끝났습니다!!

 

현재는 개시 받고 인가까지 난 상황입니다.

 

무엇보다도 다른 변호사 사무실과는 비교할 수 없는 글로리 자체 어플로 실시간 진행상황 및 모든 정보 확인이 가능하다는 점

 

입니다. 수임료도 정말 저렴합니다!! 주변에 회생하신다는 분이 있으면 무조건 추천하려고 합니다!!</div>
									<div class="info">
										<!-- 36x36 -->
										<div class="img" style="background:url('/data/staffData/')"></div>
										<span>개인회생</span>
									</div>
								</a>
																
							</div>
													</div>
						<!-- 페이징 -->
						<div class="page_bx">
							<a class='page_first'>first</a>
<a class='page_prev'>prev</a>
<a class='num on'>1</a>
<a href='/kor/revive/review.php?pNo=2' class='num'>2</a>
<a href='/kor/revive/review.php?pNo=3' class='num'>3</a>
<a href='/kor/revive/review.php?pNo=4' class='num'>4</a>
<a href='/kor/revive/review.php?pNo=5' class='num'>5</a>
<a href='/kor/revive/review.php?pNo=6' class='page_next'>next</a>
<a href='/kor/revive/review.php?pNo=17' class='page_last'>last</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div><!-- //contents -->
</div><!-- //container -->
<script>
	$('select#sitem').val('all');
	$('#btn_search').on('click', function() {
		$('form#bd_search').submit();
	});
</script>
		<footer id="footer" class="indexNum_">	
		<div class="inner">		
			<div class="btm_bx">
				<div class="f_inner">
					<img src="../images/common/f_logo.png" class="logo" alt="법무법인 글로리">
					<ul class="link_bx">
						<li><a href="../company/intro.php">법인소개</a></li>
						<li><a href="../policy/privacy.php">개인정보처리방침</a></li>
						<li><a href="../business/areas.php">업무영역</a></li>
						<li class="dotN"><a href="/kor/revive/review.php">후기</a></li>
												<li><a class="quick_btn">상담신청</a></li>
												<li><a href="../community/notice.php">커뮤니티</a></li>
					</ul>
					<!-- <ul class="info_bx">
    						<li>상호 : 법무법인 글로리</li>
    						<li>사업자등록번호 : 604-86-02992</li>
    						<li>대표변호사 : 이아무</li>
    						<li>주소 : 대전광역시 서구 둔산중로 78번길 26, 민석타워 3층 301호</li>
    						<li>대표번호 : 1544-0904(대표번호) / 042-721-0608(회생파산) / 042-721-0606(송무)</li>
    						<li>팩스 : 042-721-0707</li>
    						<li>이메일 : glory@glorylawfirm.kr</li>
    					</ul> -->
						<ul class="info_bx">
						<li>상호 : 법무법인 글로리</li>
						<li>사업자등록번호 : 604-86-02992</li>
						<li>대표변호사 : 이아무</li>
						<li>대표번호 : 1544-0904</li>
						<li>이메일 : glorylawfirm@daum.net</li>
						<li>서울본사 : 서울특별시 강남구 테헤란로8길 13, 9층 (역삼동, WD빌딩) <span>| TEL : 02-6954-0478(회생파산), 02-6954-0378(송무)</span> <span>| FAX : 02-6954-0878</span></li>
						<li>대전지점 : 대전광역시 서구 둔산중로 78번길 26, 민석타워 3층 301호 <span>| TEL : 042-721-0608(회생파산), 042-721-0606(송무)</spaan> <span>| FAX : 042-721-0707</span></li>
					</ul>
					<p class="btm_txt">Copyright © 2023 Law Firm Glory. All Rights Reserved.</p>
				</div>
			</div>
			</div>
		</footer>
	</div><!-- //wrap -->
	
	<script type="text/javascript">
		AOS.init({
			once: true,
			startEvent: 'load',
			disable: function() {
				//var maxWidth = 1024;
				//return window.innerWidth < maxWidth;
			}
		});
                
		
	</script>

		
<!-- NAVER SCRIPT START -->
<script type="text/javascript" src="//wcs.naver.net/wcslog.js"></script>
<script type="text/javascript">
if (!wcs_add) var wcs_add={};
wcs_add["wa"] = "s_35d04fef83bb";
if(window.wcs) {
        wcs.inflow("glorylawfirm.kr");
}
wcs_do();
</script>
<!-- NAVER SCRIPT END -->
	
	<!-- Smartlog -->
    <script type="text/javascript"> 
        var hpt_info={'_account':'UHPT-23580', '_server': 'a26'};
    </script>
    <script language="javascript" src="//cdn.smlog.co.kr/core/smart.js" charset="utf-8"></script>
    <noscript><img src="//a26.smlog.co.kr/smart_bda.php?_account=23580" style="display:none;width:0;height:0;" border="0"/></noscript>  	
</body>
</html>
