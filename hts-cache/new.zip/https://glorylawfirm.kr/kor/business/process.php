<!DOCTYPE html>
<html lang="ko">
<head>
<title>법무법인 글로리 - 개인회생파산센터, 이혼가사센터, 형사전문변호사</title>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="format-detection" content="telephone=no"/>
    
    <link rel="canonical" href="https://glorylawfirm.kr/kor/business/process.php/" />

	<meta name="robots" content="index,follow" />
	<meta name="subject" content="법무법인 글로리" />
	<meta name="title" content="법무법인 글로리 - 개인회생파산센터, 이혼가사센터, 형사전문변호사" />
	<meta name="author" content="법무법인 글로리">
	<meta name="description" content="서울 역삼동 본사, 개인회생파산전문센터, 이혼형사센터, 개인회생파산 및 민형사소송 종합케어, 개인회생 합리적인 수임료 친절한 상담"/>
	<meta name="keywords" content="개인회생, 이혼 재산분할, 위자료 소송, 형사고소, 도산법전문, 이혼법전문, 법무법인 글로리, 업무영역, 절차안내." />

	<meta property="og:type" content="website" />
	<meta property="og:rich_attachment" content="true" />
	<meta property="og:site_name" content="법무법인 글로리" />
	<meta property="og:title" content="법무법인 글로리 - 개인회생파산센터, 이혼가사센터, 형사전문변호사" />
	<meta property="og:description" content="서울 역삼동 본사, 개인회생파산전문센터, 이혼형사센터, 개인회생파산 및 민형사소송 종합케어, 개인회생 합리적인 수임료 친절한 상담" />
	<meta property="og:image" content="https://glorylawfirm.kr/kor/images/og_img2.png" />
	<meta property="og:url" content="https://glorylawfirm.kr/" />

	<meta name="twitter:card" content="summary_large_image">
	<meta name="twitter:title" content="법무법인 글로리 - 개인회생파산센터, 이혼가사센터, 형사전문변호사" />
	<meta name="twitter:description" content="서울 역삼동 본사, 개인회생파산전문센터, 이혼형사센터, 개인회생파산 및 민형사소송 종합케어, 개인회생 합리적인 수임료 친절한 상담" />
	<meta name="twitter:image" content="https://glorylawfirm.kr/kor/images/og_img2.png" />

	<meta itemprop="name" content="법무법인 글로리" />
	<meta itemprop="description" content="서울 역삼동 본사, 개인회생파산전문센터, 이혼형사센터, 개인회생파산 및 민형사소송 종합케어, 개인회생 합리적인 수임료 친절한 상담" />
	<meta itemprop="image" content="https://glorylawfirm.kr/kor/images/og_img2.png" />

	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, minimum-scale=1.0, user-scalable=no" />

	<!-- font -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;500;600;700;800;900&family=Montserrat:wght@100;200;300;400;500;600;700;800;900&family=Nanum+Myeongjo:wght@400;700;800&display=swap" rel="stylesheet">

	<link href="../css/base.css?230830" rel="stylesheet" type="text/css" />
	<link href="../css/common.css?230830" rel="stylesheet" type="text/css" />
	<link href="../css/main.css?230830" rel="stylesheet" type="text/css" />
	<link href="../css/main_2.css?230830" rel="stylesheet" type="text/css" />
	<link href="../css/sub.css?230830" rel="stylesheet" type="text/css" />
	<link href="../css/board.css?230830" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="../images/favicon.ico" type="image/x-icon">

	<!--[if lt IE 9]>
		<script src="../js/html5shiv.js"></script>
		<script src="../js/respond.min.js"></script>
		<script type="text/javascript">
			alert('현재 업데이트의 지원이 중단되어 보안이 취약한 하위버전의 브라우저를 사용하고 계십니다.\n원활한 사이트 이용을 위해서는 Internet Explorer 최신 버전으로 업데이트 하시거나,\n타 브라우저 (구글 크롬, 파이어폭스, 네이버 웨일) 사용을 권장합니다.');
		</script>
	<![endif]-->

	<!-- Google Tag Manager -->
	<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
	new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
	j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
	'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
	})(window,document,'script','dataLayer','GTM-5G8269NP');</script>
	<!-- End Google Tag Manager -->

	<script src="../js/jquery-3.7.0.min.js"></script>
	<script src="../js/slick.min.js"></script>
	<script src="../js/common.js"></script>
    <script src="/aseoul/js/dev.js"></script>

	<!-- aos -->
	<link href="../css/aos.css" rel="stylesheet" type="text/css" />
	<script src="../js/aos.js"></script>

<!-- Enliple Tracker Start -->
<script async src="https://cdn.onetag.co.kr/0/tcs.js?eid=1k1zhc4s5tb8y1k1zhc4s5"></script>
<!-- Enliple Tracker End -->

</head>

<body id="sub">

	<!-- Google Tag Manager (noscript) -->
	<noscript>
	<iframe	src="https://www.googletagmanager.com/ns.html?id=GTM-5G8269NP"	height="0" width="0" style="display:none;visibility:hidden"></iframe>
	</noscript>
	<!-- End Google Tag Manager (noscript) -->

	<div id="skipNavi">
		<ul>
			<li>
				<a href="#container">본문 바로가기</a>
				<a href="#gnb">주메뉴 바로가기</a>
			</li>
		</ul>
	</div>

	<div id="wrap">
		<header id="header" class="type1">
			<div class="bg_bx"></div>
			<div class="h_top">
				<div class="h_inner">
					<ul class="l_bx">
						<li><a href="../main/" class="col2">홈페이지</a></li>
						<li><a href="../revive/">글로리 회생센터</a></li>
						<li><a href="../divorce/">글로리 이혼센터</a></li>
						<li><a href="https://glorylawfirm-crime.com/" target="_blank">글로리 형사센터</a></li>
					</ul>
					<ul class="r_bx">
						<li class="en">Law&amp;Firm Glory</li>
						<!-- <li><a href="tel:1544-0904" class="en col2">1544-0904(대표번호) / 042-721-0608(회생파산) / 042-721-0606(송무)</a></li> -->
						<li><a href="tel:1544-0904" class="en col2">1544-0904(대표번호) / 02-6954-0478(서울회생파산) / 02-6954-0378(서울송무) / 042-721-0608(대전회생파산) / 042-721-0606(대전송무)</a></li>
					</ul>
				</div>
			</div>
			<div class="h_btm">
				<div class="h_inner">
					<a href="../main/" class="logo">법무법인 글로리</a>

					<div class="menu_bx">
						<ul class="dep1_wrap">
							<li class="dep1 dep01">
								<a href="../company/intro.php">법인소개</a>
								<ul class="dep2_wrap">
	<li><a href="../company/intro.php">글로리 소개</a></li>
	<li><a href="../company/speciality.php">글로리 특별함</a></li>
	<li><a href="../company/members.php">구성원 소개</a></li>
	<li><a href="../company/location.php">오시는 길</a></li>
</ul>							</li>
							<li class="dep1 dep02">
								<a href="../business/areas.php">업무영역</a>
								<ul class="dep2_wrap">
	<li><a href="../business/areas.php">분야별 소개</a></li>
	<li><a href="../business/process.php">절차안내</a></li>
</ul>							</li>
							<li class="dep1 dep03 a_none">
								<a href="../review/list.php">후기</a>
								<ul class="dep2_wrap">
	<li><a href="/kor/review/list.php?lawyer=1">이아무 변호사</a></li>
	<li><a href="/kor/review/list.php?lawyer=2">피재경 변호사</a></li>
	<li><a href="/kor/review/list.php?lawyer=3">정유라 변호사</a></li>
</ul>							</li>
							<li class="dep1 dep04 a_none">
								<!--<a class="contact_btn">상담신청</a>-->
								<a class="quick_btn">상담신청</a>
								<ul class="dep2_wrap">
	<!--<li><a href="#" class="contact_btn">상담신청</a></li>-->
	<li><a href="#" class="quick_btn">상담신청</a></li>
</ul>							</li>
							<li class="dep1 dep05">
								<a href="../community/notice.php">커뮤니티</a>
								<ul class="dep2_wrap">
	<li><a href="../community/notice.php">공지사항</a></li>
	<li><a href="../community/faq.php">자주묻는질문</a></li>
	<li><a href="../community/legalInfo.php">법률정보</a></li>
</ul>							</li>
						</ul>
					</div>

					<div class="r_bx">
						<div class="lang">
							<div class="on_t">KOR</div>
							<ul>
								<li><a href="#">KOR</a></li>
								<li><a href="#">ENG</a></li>
							</ul>
						</div>
						<div class="menu_btn">
							<span></span>
							<span></span>
							<span></span>
						</div>
					</div>
				</div>
			</div>

			<div class="sm_bx">
				<div class="sm_w">
					<div class="m_top m_show">
						<ul>
							<li><a href="../main/" class="col2">홈페이지</a></li>
							<li><a href="../revive/">글로리 회생센터</a></li>
							<li><a href="../divorce/">글로리 이혼센터</a></li>
							<li><a href="https://glorylawfirm-crime.com/" target="_blank">글로리 형사센터</a></li>
						</ul>
					</div>
					<div class="sm_inner"></div>
				</div>
			</div>

			<!-- 오른쪽 퀵 -->
			<div id="quick_bx">
	<div class="l_bx">
		<div class="f_btn">
			<strong>Quick Zone</strong>
		</div>
		<div class="q_btn">
			<ul>
				<li>
					<a href="../divorce/">
						<em>D</em>
						<p><span>글로리 이혼/상속센터</span></p>
					</a>
				</li>
				<li>
					<a href="../revive/">
						<em>R</em>
						<p><span>글로리 회생/파산센터</span></p>
					</a>
				</li>
				<li>
					<a href="https://glorylawfirm-crime.com/" target="_blank">
						<em>C</em>
						<p><span>글로리 형사센터</span></p>
					</a>
				</li>
			</ul>
			<a class="naver">naver blog</a>
			<a href="https://pf.kakao.com/_gPkyxj" target="_blank" class="kakao">kakao</a>
			<div class="top_btn">TOP</div>
		</div>
	</div>
	<div class="r_bx">
		<div class="con_bx">
			<div class="con_w">
				<div class="top_txt">
					<strong>Online Solution</strong>
					<p>1:1온라인 상담을 통해 신속하고 정확하게 <br class="pc_show2">고객의 니즈를 충족하는 법률서비스를 <br class="pc_show2">제공하고 있습니다.</p>
					<ul>
						<li>1.  최대 12시간이내, 담당자가 유선 연락을 드립니다.</li>
						<li>2.  예약 후 내방하시면 담당변호사와 1:1심층면담이 이루어집니다.</li>
						<li>3.  상담분야를 특정하여 주시면 즉시 담당자와 연결해 드립니다.</li>
					</ul>
				</div>
				<div class="form_bx">
					<form method="post" action="/process/online.php" id="quickform" enctype="multipart/form-data">
					<input type="hidden" name="gubun" value="online"> <!--온라인상담-->
					<input type="hidden" name="captcha_form" value="quick">
						<input type="text" name="name" placeholder="이름">
						<input type="text" name="tel" placeholder="연락처">
						<select name="region">
							<option value="">지역</option>
															<option  value="1">서울</option>
															<option  value="2">인천</option>
															<option  value="3">세종</option>
															<option  value="4">대전</option>
															<option  value="5">대구</option>
															<option  value="6">울산</option>
															<option  value="7">광주</option>
															<option  value="8">부산</option>
															<option  value="9">제주</option>
															<option  value="10">강원도</option>
															<option  value="11">경기도</option>
															<option  value="12">충청북도</option>
															<option  value="13">충청남도</option>
															<option  value="14">경상북도</option>
															<option  value="15">경상남도</option>
															<option  value="16">전라북도</option>
															<option  value="17">전라남도</option>
													</select>
						<select name="fields">
							<option value="">상담분야</option>
															<option value="1">회생/파산</option>
															<option value="2">이혼</option>
															<option value="3">가사 및 상속</option>
															<option value="4">민사 채권, 채무</option>
															<option value="5">형사</option>
															<option value="6">기업법무/자문</option>
															<option value="7">소년보호</option>
															<option value="8">부동산</option>
															<option value="9">행정</option>
															<option value="10">상가임대차</option>
															<option value="11">의료</option>
															<option value="12">성범죄</option>
															<option value="13">교통사고</option>
													</select>
						<textarea name="content" placeholder="기타 문의내용"></textarea>
						<span class="txt">※ 필요할 경우 상담내용을 입력해 주시면 됩니다.</span>
						<div class="chk_bx">
							<input type="checkbox" id="quick_agree" name="safeguard">
							<label for="quick_agree">개인정보 수집 및 이용에 동의</label>
						</div>
                        <div class="captcha" style="height: 60px">
                            <span id="reCaptcha"><img src="/kor/inc/kcaptcha/?form=quick&PHPSESSID=q25mjso2juik2cjnnsqs3lcugk&rand=752397801"></span>
                            <p><input type="text" name="captcha" placeholder="보안 문자 입력" /></p>
                        </div>
						<a href="#" onclick="quickSend(); return false;" class="btn"><span>법률상담 신청하기</span></a>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>

<script>
function quickSend(){
	var f = document.getElementById('quickform');
	var safeguard = $('#quickform [name=safeguard]:checkbox').prop('checked');

	if(!$.trim(f.name.value)){
		alert("이름을 입력해주세요.");
		f.name.focus();
		return false;
	}else if(!$.trim(f.tel.value)){
		alert("연락처를 입력해주세요.");
		f.tel.focus();
		return false;
	}else if(!$.trim(f.region.value)){
		alert("지역을 선택해주세요.");
		f.region.focus();
		return false;
	}else if(!$.trim(f.fields.value)){
		alert("상담분야를 선택해주세요.");
		return false;
	}else if(safeguard == false){
		alert("개인정보수집 및 이용동의 약관에 동의하세요.");
		return false;
	}else if (!f.captcha.value.trim()) {
        alert("보안 문자를 입력해 주십시오.");
        f.captcha.focus();
        return false;
    }else{
        //console.log( $(f).serialize() );

		f.submit();
	}
}
</script>


<!-- 팝업 -->
<div id="q_pop_bx">
	<div class="pop_w">
		<div class="pop_c">
			<!-- 회생/파산 -->
			<div class="pop_con_bx">
				<div class="ttl_bx">
					<div class="close_btn">닫기</div>
					<strong>Glory Blog</strong>
					<p>법무법인 글로리에서 운영하는 블로그를 소개합니다</p>
				</div>
				<ul class="link_bx">
					<!--<li><a href="https://blog.naver.com/glorylawfirm2" target="_blank"><span><strong>글로리 회생센터</strong> 블로그 바로가기</span></a></li>-->
					<li><a href="https://blog.naver.com/tphyak80" target="_blank"><span><strong>글로리 회생센터</strong> 블로그 바로가기</span></a></li>
					<!--<li><a href="https://blog.naver.com/glorylawfirm" target="_blank"><span><strong>글로리 이혼센터</strong> 블로그 바로가기</span></a></li>-->
					<li><a href="https://blog.naver.com/lawfirmglory/223431902141" target="_blank"><span><strong>글로리 이혼센터</strong> 블로그 바로가기</span></a></li>
					<li><a href="https://blog.naver.com/glorylawfirm3" target="_blank"><span><strong>글로리 민ㆍ형사센터</strong> 블로그 바로가기</span></a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	$("#quick_bx .l_bx .q_btn .naver").click(function(){
		$("#q_pop_bx").stop().fadeIn(300);
		$("html").css("overflow-y", "hidden");
	});
	
	$("#q_pop_bx .ttl_bx .close_btn").click(function(){
		$("#q_pop_bx").stop().fadeOut(300);
		setTimeout(function(){
			$("html").css("overflow-y", "auto");
		},100);
	});
    
    document.querySelector('#reCaptcha').addEventListener('click', function() {
        this.innerHTML = '<img src="/kor/inc/kcaptcha/?form=quick&PHPSESSID=q25mjso2juik2cjnnsqs3lcugk&rand=' + Math.random() + '">';
    });
</script>		</header><!-- //header -->
<div id="s_visual" class="s_visual_02">
	<div class="slogan">
		<div class="title_box">
   			<div class="bg_img"></div>
			<div class="ttl_w">
				<div>
					<div class="title" data-aos="fade-down" data-aos-duration="600">업무영역</div>
					<div class="sub_tit" data-aos="fade-up" data-aos-duration="600"><span>고객의 올바른 동반자로서 진실된 서비스를 제공하기 위하여 구성원 각자 <br class="pc_show2">끊임없이 혁신에 매진하여 고객의 미래를 설계합니다.</span></div>
				</div>
			</div>
		</div>
	</div>
   			<div class="tab_box">
			<div class="on_txt m_show"><span>절차안내</span></div>
			<ul class="dep2_wrap">
	<li><a href="../business/areas.php">분야별 소개</a></li>
	<li><a href="../business/process.php">절차안내</a></li>
</ul>		</div>
	</div>
<script type="text/javascript">
	setTimeout(function(){
		$("#s_visual .slogan .title_box > .bg_img").addClass("on");
	},10);
	
	$("#header .menu_bx .dep02").addClass("on");
	
			$("#header .menu_bx .dep02 .dep2_wrap > li:nth-child(02) a").addClass("colOn");
		setTimeout(function(){
			$("#s_visual .tab_box .dep2_wrap > li:nth-child("+02+")").addClass("on");
		}, 10);
		 
	$("#s_visual .tab_box .on_txt").click(function(){
		$(this).toggleClass("on");
		$("#s_visual .tab_box .dep2_wrap").stop().slideToggle(300);
	});
</script>		<div id="container">
			<div id="contents">
                <div id="process">
                	<div class="box box1">
                		<div class="inner_bx">
                			<div class="ttl_01">
                				<strong>
                					<span>Reorganization/Bankruptcy</span>
                					<p>회생/파산 절차안내</p>
                				</strong>
                			</div>
                			<div class="txt_bx">
                				<div class="txt1">
									회생/파산은 <strong>상담 진행</strong>부터 <strong>신청 완료</strong>까지 <br class="m_show"/><strong>약 10일 정도</strong> 소요됩니다.
                				</div>
                				<div class="txt2">※서류를 준비해 주시는 시간이나 채권자 수에 따라 <br class="m_show"/>차이가 있을 수 있습니다.</div>
                			</div>
                		</div>
                		<div class="con_bx">
                			<ul>
                				<li>
                					<div class="icon">
                						<img src="../images/sub/process_box1_icon1.png">
                						<span>01</span>
                					</div>
                					<div class="txt">
                						무료상담 진행
                					</div>
                				</li>
                				<li>
                					<div class="icon">
                						<img src="../images/sub/process_box1_icon2.png">
                						<span>02</span>
                					</div>
                					<div class="txt">
                						계약서 작성
                					</div>
                				</li>
                				<li class="col2">
                					<div class="icon">
                						<img src="../images/sub/process_box1_icon3.png">
                						<span>03</span>
                					</div>
                					<div class="txt">
                						동사무소 서류 준비
										<span>(1차 필요서류)</span>
                					</div>
                				</li>
                				<li class="col2">
                					<div class="icon">
                						<img src="../images/sub/process_box1_icon4.png">
                						<span>04</span>
                					</div>
                					<div class="txt">
                						부채증명서 발급
                					</div>
                				</li>
                				<li class="col2">
                					<div class="icon">
                						<img src="../images/sub/process_box1_icon5.png">
                						<span>05</span>
                					</div>
                					<div class="txt">
                						그 외 서류 준비
										<span>(2차 필요서류)</span>
                					</div>
                				</li>
                				<li>
                					<div class="icon">
                						<img src="../images/sub/process_box1_icon6.png">
                						<span>06</span>
                					</div>
                					<div class="txt">
                						신청서 제출
                					</div>
                				</li>
                			</ul>
                		</div>
		            </div>
               		<div class="box box2">
                		<div class="inner_bx">
                			<div class="ttl_01">
                				<strong>
                					<span>Complaint Procedure</span>
                					<p>고소 절차안내</p>
                				</strong>
                			</div>
                			<div class="con_bx">
                				<ul>
                					<li>
                						<div class="txt_bx">
											<span class="num">01</span>
											<p>고소장의 작성 및 제출</p>
                						</div>
                					</li>
                					<li>
                						<div class="txt_bx">
											<span class="num">02</span>
											<p>고소장의 검토 접수 및 고소인의 조사</p>
                						</div>
                					</li>
                					<li>
                						<div class="txt_bx">
											<span class="num">03</span>
											<p>피의자 및 참고인 조사</p>
                						</div>
                					</li>
                					<li>
                						<div class="txt_bx">
											<span class="num">04</span>
											<p>범죄혐의 유무 판단</p>
                						</div>
                					</li>
                					<li>
                						<div class="txt_bx">
											<span class="num">05</span>
											<p>사건 송치, 사건수리, 보완수사</p>
                						</div>
                					</li>
                					<li class="col2">
                						<div class="txt_bx">
											<span class="num">06</span>
											<p>수사종결 및 검사처분</p>
                						</div>
                					</li>
                				</ul>
                			</div>
                		</div>
		            </div>
               		<div class="box box3">
                		<div class="inner_bx">
                			<div class="ttl_01">
                				<strong>
                					<span>Civil Proceedings</span> 
                					<p>민사소송 절차안내</p>
                				</strong>
                			</div>
                			<div class="con_bx">
                				<div class="con_w con1">
                					<div class="con_inner">
                						<div>소장접수(원고)</div>
                						<div>소장심사(법원)</div>
                						<div>소장부본 송달(법원 → 피고)</div>
                					</div>
                				</div>
                				<div class="con_w con2">
                					<div class="con_inner col2">
                						<div class="ttl">답변서 미제출</div>
                						<div>판결(자백답변)</div>
                					</div>
                					<div class="con_inner">
                						<div class="ttl">답변서 제출</div>
                						<div>답변서 송달(법원 → 원고)</div>
                						<div>쟁점정리기일</div>
                						<div>변론준비절차(법원)</div>
                						<div>변론기일</div>
                						<div>집중증거조사기일</div>
                						<div>판결</div>
                					</div>
                				</div>
                			</div>
                		</div>
		            </div>
                </div>
	        </div><!-- //contents -->
        </div><!-- //container -->

		<footer id="footer" class="indexNum_">
			<div class="top_bx">
				<div class="f_inner">
					<div class="l_bx">
						<span class="ttl">상담문의</span>
						<!-- <p>
    							<strong>1544-0904(대표번호) / 042-721-0608(회생파산) / 042-721-0606(송무)</strong>업무시간 09:00 ~ 18:00 (주말, 공휴일 휴무)
    						</p> -->
						<p>
							<strong>대표번호 1544-0904</strong>
							<strong>02-6954-0478(서울회생파산) / 02-6954-0378(서울송무)</strong>
							<strong>042-721-0608(대전회생파산) / 042-721-0606(대전송무)</strong>
						<p>업무시간 09:00 ~ 18:00 (주말, 공휴일 휴무)</p>
						</p>
					</div>
					<div class="r_bx">
						<span class="ttl">glory sns</span>
						<ul class="sns_bx">
							<li class="instagram"><a href="https://www.instagram.com/glory_lawfirm/?igshid=MzRlODBiNWFlZA%3D%3D" target="_blank">instagram</a></li>
							<li class="youtube"><a href="#none" >youtube</a></li>
							<li class="facebook"><a href="#none" >facebook</a></li>
						</ul>
					</div>
				</div>
			</div>
			<div class="btm_bx">
				<div class="f_inner">
					<img src="../images/common/logo.png" class="logo" alt="법무법인 글로리">
					<ul class="link_bx">
						<li><a href="../company/intro.php">법인소개</a></li>
						<li><a href="../policy/privacy.php">개인정보처리방침</a></li>
						<li><a href="../business/areas.php">업무영역</a></li>
						<li class="dotN"><a href="../review/list.php">후기</a></li>
													<li><a class="quick_btn">상담신청</a></li>
												<li><a href="../community/notice.php">커뮤니티</a></li>
					</ul>
					<!-- <ul class="info_bx">
    						<li>상호 : 법무법인 글로리</li>
    						<li>사업자등록번호 : 604-86-02992</li>
    						<li>대표변호사 : 이아무</li>
    						<li>주소 : 대전광역시 서구 둔산중로 78번길 26, 민석타워 3층 301호</li>
    						<li>대표번호 : 1544-0904(대표번호) / 042-721-0608(회생파산) / 042-721-0606(송무)</li>
    						<li>팩스 : 042-721-0707</li>
    						<li>이메일 : glory@glorylawfirm.kr</li>
    					</ul> -->
					<ul class="info_bx">
						<li>상호 : 법무법인 글로리</li>
						<li>사업자등록번호 : 604-86-02992</li>
						<li>대표변호사 : 이아무</li>
						<li>대표번호 : 1544-0904</li>
						<li>이메일 : glorylawfirm@daum.net</li>
						<li>서울본사 : 서울특별시 강남구 테헤란로8길 13, 9층 (역삼동, WD빌딩) <span>| TEL : 02-6954-0478(회생파산), 02-6954-0378(송무)</span> <span>| FAX : 02-6954-0878</span></li>
						<li>대전지점 : 대전광역시 서구 둔산중로 78번길 26, 민석타워 3층 301호 <span>| TEL : 042-721-0608(회생파산), 042-721-0606(송무)</spaan> <span>| FAX : 042-721-0707</span></li>
					</ul>
					<p class="btm_txt">Copyright © 2023 Law Firm Glory. All Rights Reserved.</p>
				</div>
			</div>
		</footer>
		</div><!-- //wrap -->

		<script type="text/javascript">
			AOS.init({
				once: true,
				startEvent: 'load',
				disable: function() {
					//var maxWidth = 1024;
					//return window.innerWidth < maxWidth;
				}
			});
								</script>

		
		<!-- 공통 적용 스크립트 , 모든 페이지에 노출되도록 설치. 단 전환페이지 설정값보다 항상 하단에 위치해야함 -->
		<script type="text/javascript" src="//wcs.naver.net/wcslog.js"> </script>
		<script type="text/javascript">
			if (!wcs_add) var wcs_add = {};
			wcs_add["wa"] = "s_35d04fef83bb";
			if (!_nasa) var _nasa = {};
			if (window.wcs) {
				wcs.inflow();
				wcs_do(_nasa);
			}
		</script>


		</body>

		</html>