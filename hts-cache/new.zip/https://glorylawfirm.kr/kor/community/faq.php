<!DOCTYPE html>
<html lang="ko">
<head>
<title>법무법인 글로리 - 개인회생파산센터, 이혼가사센터, 형사전문변호사</title>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="format-detection" content="telephone=no"/>
    
    <link rel="canonical" href="https://glorylawfirm.kr/kor/community/faq.php/" />

	<meta name="robots" content="index,follow" />
	<meta name="subject" content="법무법인 글로리" />
	<meta name="title" content="법무법인 글로리 - 개인회생파산센터, 이혼가사센터, 형사전문변호사" />
	<meta name="author" content="법무법인 글로리">
	<meta name="description" content="서울 역삼동 본사, 개인회생파산전문센터, 이혼형사센터, 개인회생파산 및 민형사소송 종합케어, 개인회생 합리적인 수임료 친절한 상담"/>
	<meta name="keywords" content="개인회생, 이혼 재산분할, 위자료 소송, 형사고소, 도산법전문, 이혼법전문, 법무법인 글로리, 커뮤니티, 자주묻는질문." />

	<meta property="og:type" content="website" />
	<meta property="og:rich_attachment" content="true" />
	<meta property="og:site_name" content="법무법인 글로리" />
	<meta property="og:title" content="법무법인 글로리 - 개인회생파산센터, 이혼가사센터, 형사전문변호사" />
	<meta property="og:description" content="서울 역삼동 본사, 개인회생파산전문센터, 이혼형사센터, 개인회생파산 및 민형사소송 종합케어, 개인회생 합리적인 수임료 친절한 상담" />
	<meta property="og:image" content="https://glorylawfirm.kr/kor/images/og_img2.png" />
	<meta property="og:url" content="https://glorylawfirm.kr/" />

	<meta name="twitter:card" content="summary_large_image">
	<meta name="twitter:title" content="법무법인 글로리 - 개인회생파산센터, 이혼가사센터, 형사전문변호사" />
	<meta name="twitter:description" content="서울 역삼동 본사, 개인회생파산전문센터, 이혼형사센터, 개인회생파산 및 민형사소송 종합케어, 개인회생 합리적인 수임료 친절한 상담" />
	<meta name="twitter:image" content="https://glorylawfirm.kr/kor/images/og_img2.png" />

	<meta itemprop="name" content="법무법인 글로리" />
	<meta itemprop="description" content="서울 역삼동 본사, 개인회생파산전문센터, 이혼형사센터, 개인회생파산 및 민형사소송 종합케어, 개인회생 합리적인 수임료 친절한 상담" />
	<meta itemprop="image" content="https://glorylawfirm.kr/kor/images/og_img2.png" />

	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, minimum-scale=1.0, user-scalable=no" />

	<!-- font -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;500;600;700;800;900&family=Montserrat:wght@100;200;300;400;500;600;700;800;900&family=Nanum+Myeongjo:wght@400;700;800&display=swap" rel="stylesheet">

	<link href="../css/base.css?230830" rel="stylesheet" type="text/css" />
	<link href="../css/common.css?230830" rel="stylesheet" type="text/css" />
	<link href="../css/main.css?230830" rel="stylesheet" type="text/css" />
	<link href="../css/main_2.css?230830" rel="stylesheet" type="text/css" />
	<link href="../css/sub.css?230830" rel="stylesheet" type="text/css" />
	<link href="../css/board.css?230830" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="../images/favicon.ico" type="image/x-icon">

	<!--[if lt IE 9]>
		<script src="../js/html5shiv.js"></script>
		<script src="../js/respond.min.js"></script>
		<script type="text/javascript">
			alert('현재 업데이트의 지원이 중단되어 보안이 취약한 하위버전의 브라우저를 사용하고 계십니다.\n원활한 사이트 이용을 위해서는 Internet Explorer 최신 버전으로 업데이트 하시거나,\n타 브라우저 (구글 크롬, 파이어폭스, 네이버 웨일) 사용을 권장합니다.');
		</script>
	<![endif]-->

	<!-- Google Tag Manager -->
	<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
	new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
	j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
	'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
	})(window,document,'script','dataLayer','GTM-5G8269NP');</script>
	<!-- End Google Tag Manager -->

	<script src="../js/jquery-3.7.0.min.js"></script>
	<script src="../js/slick.min.js"></script>
	<script src="../js/common.js"></script>
    <script src="/aseoul/js/dev.js"></script>

	<!-- aos -->
	<link href="../css/aos.css" rel="stylesheet" type="text/css" />
	<script src="../js/aos.js"></script>

<!-- Enliple Tracker Start -->
<script async src="https://cdn.onetag.co.kr/0/tcs.js?eid=1k1zhc4s5tb8y1k1zhc4s5"></script>
<!-- Enliple Tracker End -->

</head>

<body id="sub">

	<!-- Google Tag Manager (noscript) -->
	<noscript>
	<iframe	src="https://www.googletagmanager.com/ns.html?id=GTM-5G8269NP"	height="0" width="0" style="display:none;visibility:hidden"></iframe>
	</noscript>
	<!-- End Google Tag Manager (noscript) -->

	<div id="skipNavi">
		<ul>
			<li>
				<a href="#container">본문 바로가기</a>
				<a href="#gnb">주메뉴 바로가기</a>
			</li>
		</ul>
	</div>

	<div id="wrap">
		<header id="header" class="type1">
			<div class="bg_bx"></div>
			<div class="h_top">
				<div class="h_inner">
					<ul class="l_bx">
						<li><a href="../main/" class="col2">홈페이지</a></li>
						<li><a href="../revive/">글로리 회생센터</a></li>
						<li><a href="../divorce/">글로리 이혼센터</a></li>
						<li><a href="https://glorylawfirm-crime.com/" target="_blank">글로리 형사센터</a></li>
					</ul>
					<ul class="r_bx">
						<li class="en">Law&amp;Firm Glory</li>
						<!-- <li><a href="tel:1544-0904" class="en col2">1544-0904(대표번호) / 042-721-0608(회생파산) / 042-721-0606(송무)</a></li> -->
						<li><a href="tel:1544-0904" class="en col2">1544-0904(대표번호) / 02-6954-0478(서울회생파산) / 02-6954-0378(서울송무) / 042-721-0608(대전회생파산) / 042-721-0606(대전송무)</a></li>
					</ul>
				</div>
			</div>
			<div class="h_btm">
				<div class="h_inner">
					<a href="../main/" class="logo">법무법인 글로리</a>

					<div class="menu_bx">
						<ul class="dep1_wrap">
							<li class="dep1 dep01">
								<a href="../company/intro.php">법인소개</a>
								<ul class="dep2_wrap">
	<li><a href="../company/intro.php">글로리 소개</a></li>
	<li><a href="../company/speciality.php">글로리 특별함</a></li>
	<li><a href="../company/members.php">구성원 소개</a></li>
	<li><a href="../company/location.php">오시는 길</a></li>
</ul>							</li>
							<li class="dep1 dep02">
								<a href="../business/areas.php">업무영역</a>
								<ul class="dep2_wrap">
	<li><a href="../business/areas.php">분야별 소개</a></li>
	<li><a href="../business/process.php">절차안내</a></li>
</ul>							</li>
							<li class="dep1 dep03 a_none">
								<a href="../review/list.php">후기</a>
								<ul class="dep2_wrap">
	<li><a href="/kor/review/list.php?lawyer=1">이아무 변호사</a></li>
	<li><a href="/kor/review/list.php?lawyer=2">피재경 변호사</a></li>
	<li><a href="/kor/review/list.php?lawyer=3">정유라 변호사</a></li>
</ul>							</li>
							<li class="dep1 dep04 a_none">
								<!--<a class="contact_btn">상담신청</a>-->
								<a class="quick_btn">상담신청</a>
								<ul class="dep2_wrap">
	<!--<li><a href="#" class="contact_btn">상담신청</a></li>-->
	<li><a href="#" class="quick_btn">상담신청</a></li>
</ul>							</li>
							<li class="dep1 dep05">
								<a href="../community/notice.php">커뮤니티</a>
								<ul class="dep2_wrap">
	<li><a href="../community/notice.php">공지사항</a></li>
	<li><a href="../community/faq.php">자주묻는질문</a></li>
	<li><a href="../community/legalInfo.php">법률정보</a></li>
</ul>							</li>
						</ul>
					</div>

					<div class="r_bx">
						<div class="lang">
							<div class="on_t">KOR</div>
							<ul>
								<li><a href="#">KOR</a></li>
								<li><a href="#">ENG</a></li>
							</ul>
						</div>
						<div class="menu_btn">
							<span></span>
							<span></span>
							<span></span>
						</div>
					</div>
				</div>
			</div>

			<div class="sm_bx">
				<div class="sm_w">
					<div class="m_top m_show">
						<ul>
							<li><a href="../main/" class="col2">홈페이지</a></li>
							<li><a href="../revive/">글로리 회생센터</a></li>
							<li><a href="../divorce/">글로리 이혼센터</a></li>
							<li><a href="https://glorylawfirm-crime.com/" target="_blank">글로리 형사센터</a></li>
						</ul>
					</div>
					<div class="sm_inner"></div>
				</div>
			</div>

			<!-- 오른쪽 퀵 -->
			<div id="quick_bx">
	<div class="l_bx">
		<div class="f_btn">
			<strong>Quick Zone</strong>
		</div>
		<div class="q_btn">
			<ul>
				<li>
					<a href="../divorce/">
						<em>D</em>
						<p><span>글로리 이혼/상속센터</span></p>
					</a>
				</li>
				<li>
					<a href="../revive/">
						<em>R</em>
						<p><span>글로리 회생/파산센터</span></p>
					</a>
				</li>
				<li>
					<a href="https://glorylawfirm-crime.com/" target="_blank">
						<em>C</em>
						<p><span>글로리 형사센터</span></p>
					</a>
				</li>
			</ul>
			<a class="naver">naver blog</a>
			<a href="https://pf.kakao.com/_gPkyxj" target="_blank" class="kakao">kakao</a>
			<div class="top_btn">TOP</div>
		</div>
	</div>
	<div class="r_bx">
		<div class="con_bx">
			<div class="con_w">
				<div class="top_txt">
					<strong>Online Solution</strong>
					<p>1:1온라인 상담을 통해 신속하고 정확하게 <br class="pc_show2">고객의 니즈를 충족하는 법률서비스를 <br class="pc_show2">제공하고 있습니다.</p>
					<ul>
						<li>1.  최대 12시간이내, 담당자가 유선 연락을 드립니다.</li>
						<li>2.  예약 후 내방하시면 담당변호사와 1:1심층면담이 이루어집니다.</li>
						<li>3.  상담분야를 특정하여 주시면 즉시 담당자와 연결해 드립니다.</li>
					</ul>
				</div>
				<div class="form_bx">
					<form method="post" action="/process/online.php" id="quickform" enctype="multipart/form-data">
					<input type="hidden" name="gubun" value="online"> <!--온라인상담-->
					<input type="hidden" name="captcha_form" value="quick">
						<input type="text" name="name" placeholder="이름">
						<input type="text" name="tel" placeholder="연락처">
						<select name="region">
							<option value="">지역</option>
															<option  value="1">서울</option>
															<option  value="2">인천</option>
															<option  value="3">세종</option>
															<option  value="4">대전</option>
															<option  value="5">대구</option>
															<option  value="6">울산</option>
															<option  value="7">광주</option>
															<option  value="8">부산</option>
															<option  value="9">제주</option>
															<option  value="10">강원도</option>
															<option  value="11">경기도</option>
															<option  value="12">충청북도</option>
															<option  value="13">충청남도</option>
															<option  value="14">경상북도</option>
															<option  value="15">경상남도</option>
															<option  value="16">전라북도</option>
															<option  value="17">전라남도</option>
													</select>
						<select name="fields">
							<option value="">상담분야</option>
															<option value="1">회생/파산</option>
															<option value="2">이혼</option>
															<option value="3">가사 및 상속</option>
															<option value="4">민사 채권, 채무</option>
															<option value="5">형사</option>
															<option value="6">기업법무/자문</option>
															<option value="7">소년보호</option>
															<option value="8">부동산</option>
															<option value="9">행정</option>
															<option value="10">상가임대차</option>
															<option value="11">의료</option>
															<option value="12">성범죄</option>
															<option value="13">교통사고</option>
													</select>
						<textarea name="content" placeholder="기타 문의내용"></textarea>
						<span class="txt">※ 필요할 경우 상담내용을 입력해 주시면 됩니다.</span>
						<div class="chk_bx">
							<input type="checkbox" id="quick_agree" name="safeguard">
							<label for="quick_agree">개인정보 수집 및 이용에 동의</label>
						</div>
                        <div class="captcha" style="height: 60px">
                            <span id="reCaptcha"><img src="/kor/inc/kcaptcha/?form=quick&PHPSESSID=q25mjso2juik2cjnnsqs3lcugk&rand=32399904"></span>
                            <p><input type="text" name="captcha" placeholder="보안 문자 입력" /></p>
                        </div>
						<a href="#" onclick="quickSend(); return false;" class="btn"><span>법률상담 신청하기</span></a>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>

<script>
function quickSend(){
	var f = document.getElementById('quickform');
	var safeguard = $('#quickform [name=safeguard]:checkbox').prop('checked');

	if(!$.trim(f.name.value)){
		alert("이름을 입력해주세요.");
		f.name.focus();
		return false;
	}else if(!$.trim(f.tel.value)){
		alert("연락처를 입력해주세요.");
		f.tel.focus();
		return false;
	}else if(!$.trim(f.region.value)){
		alert("지역을 선택해주세요.");
		f.region.focus();
		return false;
	}else if(!$.trim(f.fields.value)){
		alert("상담분야를 선택해주세요.");
		return false;
	}else if(safeguard == false){
		alert("개인정보수집 및 이용동의 약관에 동의하세요.");
		return false;
	}else if (!f.captcha.value.trim()) {
        alert("보안 문자를 입력해 주십시오.");
        f.captcha.focus();
        return false;
    }else{
        //console.log( $(f).serialize() );

		f.submit();
	}
}
</script>


<!-- 팝업 -->
<div id="q_pop_bx">
	<div class="pop_w">
		<div class="pop_c">
			<!-- 회생/파산 -->
			<div class="pop_con_bx">
				<div class="ttl_bx">
					<div class="close_btn">닫기</div>
					<strong>Glory Blog</strong>
					<p>법무법인 글로리에서 운영하는 블로그를 소개합니다</p>
				</div>
				<ul class="link_bx">
					<!--<li><a href="https://blog.naver.com/glorylawfirm2" target="_blank"><span><strong>글로리 회생센터</strong> 블로그 바로가기</span></a></li>-->
					<li><a href="https://blog.naver.com/tphyak80" target="_blank"><span><strong>글로리 회생센터</strong> 블로그 바로가기</span></a></li>
					<!--<li><a href="https://blog.naver.com/glorylawfirm" target="_blank"><span><strong>글로리 이혼센터</strong> 블로그 바로가기</span></a></li>-->
					<li><a href="https://blog.naver.com/lawfirmglory/223431902141" target="_blank"><span><strong>글로리 이혼센터</strong> 블로그 바로가기</span></a></li>
					<li><a href="https://blog.naver.com/glorylawfirm3" target="_blank"><span><strong>글로리 민ㆍ형사센터</strong> 블로그 바로가기</span></a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	$("#quick_bx .l_bx .q_btn .naver").click(function(){
		$("#q_pop_bx").stop().fadeIn(300);
		$("html").css("overflow-y", "hidden");
	});
	
	$("#q_pop_bx .ttl_bx .close_btn").click(function(){
		$("#q_pop_bx").stop().fadeOut(300);
		setTimeout(function(){
			$("html").css("overflow-y", "auto");
		},100);
	});
    
    document.querySelector('#reCaptcha').addEventListener('click', function() {
        this.innerHTML = '<img src="/kor/inc/kcaptcha/?form=quick&PHPSESSID=q25mjso2juik2cjnnsqs3lcugk&rand=' + Math.random() + '">';
    });
</script>		</header><!-- //header -->
<div id="s_visual" class="s_visual_05">
	<div class="slogan">
		<div class="title_box">
   			<div class="bg_img"></div>
			<div class="ttl_w">
				<div>
					<div class="title" data-aos="fade-down" data-aos-duration="600">커뮤니티</div>
					<div class="sub_tit" data-aos="fade-up" data-aos-duration="600"><span>고객의 올바른 동반자로서 진실된 서비스를 제공하기 위하여 구성원 각자 <br class="pc_show2">끊임없이 혁신에 매진하여 고객의 미래를 설계합니다.</span></div>
				</div>
			</div>
		</div>
	</div>
   			<div class="tab_box">
			<div class="on_txt m_show"><span>자주묻는질문</span></div>
			<ul class="dep2_wrap">
	<li><a href="../community/notice.php">공지사항</a></li>
	<li><a href="../community/faq.php">자주묻는질문</a></li>
	<li><a href="../community/legalInfo.php">법률정보</a></li>
</ul>		</div>
	</div>
<script type="text/javascript">
	setTimeout(function(){
		$("#s_visual .slogan .title_box > .bg_img").addClass("on");
	},10);
	
	$("#header .menu_bx .dep05").addClass("on");
	
			$("#header .menu_bx .dep05 .dep2_wrap > li:nth-child(02) a").addClass("colOn");
		setTimeout(function(){
			$("#s_visual .tab_box .dep2_wrap > li:nth-child("+02+")").addClass("on");
		}, 10);
		 
	$("#s_visual .tab_box .on_txt").click(function(){
		$(this).toggleClass("on");
		$("#s_visual .tab_box .dep2_wrap").stop().slideToggle(300);
	});
</script>		<div id="container">
			<div id="contents">
                <div id="faq">
                	<div class="box box1">
                		<div class="inner_bx">
                			<div class="ttl_01">
                				<strong>
                					<span>FAQ</span>
                					<p>자주묻는질문</p>
                				</strong>
                			</div>
                			<div id="board">
								<script type="text/javascript" src="/se2/js/HuskyEZCreator.js" charset="utf-8"></script>

<!-- 검색 -->
<div class="list_top">
	<div class="count">총 <span>21</span>개의 게시물</div>
	<div class="search_bx">
		<form name="searchFrm" id="bd_search">	
			<input type="text" name="sorder" id="sorder" value="" placeholder="검색어를 입력해주세요.">
			<a href="#" class="btn" id="btn_search">검색</a>
		</form>
	</div>
</div>

<div class="list_st04"> <!-- 8개씩 -->
        <ul>
        		
        <li>
            <div class="q_bx">
                <strong>Q</strong>
                <div class="txt"><span>일용직도 개인회생을 할 수 있나요?</span></div>
            </div>
            <div class="a_bx">
                <div class="txt"><p>일용직 근로자, 아르바이트 등 매월 소득이 발생하고 있고, 매월 일정 금액을 변제할 수 있는 가능성이 있다면 개인회생이 진행 가능합니다.&nbsp;</p><p>&nbsp;</p><p>근로계약서를 쓰지 않고 재직증명서가 없어도 가능은 하지만, 현재 소득을 얻고 있다는 사실을 소명하기 위하여 근무확인서 등 기타 서류가 필요합니다.&nbsp;</p><p>&nbsp;</p><p>급여명세서 등이 없어도 매월 급여나 일당을 계좌를 통해 지급 받는다면 계좌 입급내역으로 소득을 산정할 수 있기 때문에 급여명세서가 반드시 있어야 하는 것은 아닙니다.</p></div>
            </div>
        </li>
        		
        <li>
            <div class="q_bx">
                <strong>Q</strong>
                <div class="txt"><span>개인회생 신청을 준비하려는데 하면 안되는 일이 뭐가 있을까요?</span></div>
            </div>
            <div class="a_bx">
                <div class="txt"><p>아래에서 안내해드리는 행위들은 기각 사유에 해당될 수도 있고,(기각사유에 해당하지 않더라도 월 변제금이 높게 책정될 수 있습니다) 사기회생죄로 처벌을 받을 수도 있기 때문에 개인회생절차 진행 중이거나 개인회생을 신청하기 위해 준비하고 있는 분들은 아래의 행위를 하지 않도록 유의하시는 것이 좋습니다.&nbsp;</p><p>&nbsp;</p><p>그리고 재산을 은닉하기 위하여 배우자와 위장이혼을 하면서 재산분할을 하지 않고 재산을 넘겨주는 행위 등을 하더라도 넘긴 재산을 청산가치에 반영될 가능성이 많으므로 실익이 없습니다.</p><p>&nbsp;</p><p>&nbsp;</p><p>1. 내 명의의 부동산을 타인의 명의로 돌려놓는 것</p><p>2. 보험료를 수십만원씩 납부하는 것</p><p>3. 소득 및 재산관련 자료를 허위로 작성하는 것</p><p>4. 예금 잔액을 타인의 계좌로 이체하는 것</p><p>5. 개인채권자(지인)들의 빚만을 갚는 것</p><p>6. 배우자 또는 자녀의 명의로 부동산 혹은 고가의 자동차를 구매하는 것</p><p>7. 변제할 수 없는 상황에서 돌려막기, 큰 돈을 대출 받는 것</p><p>8. 카드 연체 직전에 현금서비스, 카드론 등을 많이 받는 것</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p></div>
            </div>
        </li>
        		
        <li>
            <div class="q_bx">
                <strong>Q</strong>
                <div class="txt"><span>금지명령이 기각되는 사유는 어떤 것이 있나요?</span></div>
            </div>
            <div class="a_bx">
                <div class="txt"><p>개인회생으로 인해 얻으실 수 있는 이점 중 하나는 금지명령입니다.&nbsp;</p><p>&nbsp;</p><p>보통 개인회생을 신청함과 동시에 금지명령을 함께 신청하는데요, 금지명령에 대한 결정이 나오기만 하면 개인회생을 신청한 채무자의 재산에 대한 급여 압류, 가압류, 채권압류, 추심명령, 전부명령 등 어떠한 채무독촉 행위도 금지되기 때문입니다.&nbsp;</p><p>(단 부동산, 임대보증금, 자동차, 통장 등의 재산은 금지명령이 나왔다 하더라도 계속 압류될 수 있습니다.)</p><p>&nbsp;</p><p>이러한 사유로 인해 금지명령은 개인회생절차는 진행하기로 결정하게 되는 큰 계기가 되기도 합니다. 그러나 금지명령을 신청하더라도 기각이 되는 경우가 많은데요, 금지명령 기각 사유에 대하여 안내해드리겠습니다.&nbsp;</p><p>&nbsp;</p><p>금지명령을 허가해 줄 것인가 기각할 것인가는 판사님의 재량에 달린 것이기 때문에 정확한 사유를 알기는 힘들지만, 기각 결정에 대한 사류를 문의한다고 하더라도 정확히 알려주지도 않기 때문이죠,</p><p>&nbsp;</p><p>하지만 대략적인 사유를 통해서 금지명령은 기각될 수 있습니다.</p><p>&nbsp;</p><p>1. 최근 채무가 과다한 경우</p><p>2. 도박, 사치 등의 사행성 채무가 과다한 경우</p><p>3. 변제금을 너무 낮게 설정한 경우</p><p>4. 변제율이 너무 낮은 경우</p><p>5. 개인회생을 재신청하는 경우</p><p>&nbsp;</p><p>금지명령이 기각된다 하더라도 개시결정이 나온다면 모든 압류 및 추심은 금지됩니다.&nbsp;</p><p>금지명령이 기각되었을 경우 신청인의 진술서 등을 제출하여 재신청하는 방법도 있겠으나 실무적으로 거의 받아드려지지 않습니다. 따라서 법원에서 내린 보정권고를 성실히 이행하여 신속하게 개실결정을 받아내는 것 또한 바람직한 방법입니다.</p><p>&nbsp;</p><p>&nbsp;</p></div>
            </div>
        </li>
        		
        <li>
            <div class="q_bx">
                <strong>Q</strong>
                <div class="txt"><span>전배우자에게 양육비를 주고 있는데 개인회생을 하기 어려울까요?</span></div>
            </div>
            <div class="a_bx">
                <div class="txt"><p>이혼으로 인해 양육비를 지급하고 계시는 신청인 분들은 개인회생을 할 경우 조정된 생계비에서 양육비까지 지급을 해야하는 것은 아닌지 걱정을 하시는 분들이 많습니다.&nbsp;</p><p>&nbsp;</p><p>그러나 이러한 상황은 걱정하실 필요가 없습니다.&nbsp;</p><p>&nbsp;</p><p>현재 시행되고 있는 개선안은 양육비를 회생절차에서 최우선으로 변제해야할 채권인 "개인회생재단채권"에 포함시킴으로서 양육비가 매월 확실히 지급되고, 전배우자는 개인회생 재단 채권자로서 채무자의 재산상태도 열람할 수 있습니다.&nbsp;</p><p>&nbsp;</p><p>양육비 지급의 부담을 안고 있던 채무자들에게도, 양육비를 받지 못해 전전긍긍하고 있던 전배우자에게도 긍정적인 개선안이라고 생각합니다.</p></div>
            </div>
        </li>
        		
        <li>
            <div class="q_bx">
                <strong>Q</strong>
                <div class="txt"><span>배우자와 장기간 별거 중인데, 파산신청시 필요한 배우자의 서류는 어떻게 발급받나요?</span></div>
            </div>
            <div class="a_bx">
                <div class="txt"><p>파산신청을 하실 때 법원에서 요청하는 서류는 다양합니다.&nbsp;</p><p>&nbsp;</p><p>그 중에서 가족, 특히 배우자의 서류를 요청하는 경우가 많습니다.&nbsp;</p><p>&nbsp;</p><p>배우자의 소득을 확인하기 위한 서류인 소득금액증명, 재산을 확인하기 위한 서류인 지적전산자료조회결과나&nbsp;</p><p>&nbsp;</p><p>지방세 세목별 과세증명서 등 본인이 아니면 발급이 불가능한 서류도 많습니다.</p><p>&nbsp;</p><p>별거 중이라 하더라도 연락이 닿고 도움을 받을 수 있는 상태라면 문제가 되지 않지만,&nbsp;</p><p>&nbsp;</p><p>그렇지 않은 상태라면 개인파산을 신청할 수 있을지부터 고민이 되는 것이 사실입니다.&nbsp;</p><p>&nbsp;</p><p>그러나 위와 같은 경우에는 법원의 사실조회를 통해 해결이 가능합니다.&nbsp;</p><p>&nbsp;</p><p>배우자의 도움을 얻는 것보다 시간도 오래걸리고 절차도 복잡하지만&nbsp;</p><p>&nbsp;</p><p>특별한 이유로 법원에서 요구하는 서류의 제출이 불가능할 경우 법원에서 해당 관공서나 금융기관에 제출 명령을 신청할 수 있</p><p>&nbsp;</p><p>습니다.</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p></div>
            </div>
        </li>
        		
        <li>
            <div class="q_bx">
                <strong>Q</strong>
                <div class="txt"><span>채권자가 급여압류를 한다고 해요. 어떻게 해야하죠?</span></div>
            </div>
            <div class="a_bx">
                <div class="txt"><p>직장인 분들의 경우 채무를 변제하지 못하고 수차례 연체가 진행된 경우 가장 먼저 들어올 수 있는 압류가 급여 압류입니다.</p><p>&nbsp;</p><p>급여를 압류한다고 하여도 모든 급여가 압류되는 것은 아니고,&nbsp;</p><p>민사집행법 제 246조에 의하면 압류가 가능한 금액은 아래와 같습니다.</p><p>&nbsp;</p><p>1. 150만원 미만인 경우 : 0원</p><p>2. 150만원 초과 300만원 미만 : 급여 -150만원</p><p>3. 300만원 초과 600만원 미만 : 급여의 2분의 1</p><p>4. 600만원 초과 : 급여 - [300 + {(급여/2) - 300}/2]</p><p>&nbsp;</p><p>채무가 연체되어 급여를 압류 당할 것 같거나 현재 급여압류가 진행중인 경우의 가장 좋은 해결 방안은 채무를 변제하여 급여압류가 들어오지 못하게 하거나 압류를 해제하는 방법이지만, 이것이 불가능하다면 개인회생을 신청하는 것이 합리적인 해결책이 될 수 있습니다.&nbsp;</p><p>&nbsp;</p><p>개인회생제도의 금지명령과 중지명령제도를 이용하여&nbsp;</p><p>앞으로의 급여의 압류가 들어오지 못 하도록 막고, 급여 압류를 중지시키는 것이 바람직합니다.&nbsp;</p><p>&nbsp;</p><p>그렇다고 중지명령 이후부터 모든 급여를 받을 수 있는 것은 아니고, 압류될 급여부분을 회사에서 적립해두었다가 개인회생 인가결정을 받은 이후 적립되어 있던 급여를 전부 변제금액에 투입하는 것입니다.</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p></div>
            </div>
        </li>
        		
        <li>
            <div class="q_bx">
                <strong>Q</strong>
                <div class="txt"><span>일정한 수입이 없으면 개인회생을 할 수 없나요?</span></div>
            </div>
            <div class="a_bx">
                <div class="txt"><p>개인회생은 자영업자든 직장인이든 자신과 부양가족의 생계비를 초과하는 정기적이고 지속적인 수입이 있어야 하기에 소득이 없어나 일정하지 않은 사람은 개인파산제도의 이용을 고려해보는 것이 좋습니다.</p></div>
            </div>
        </li>
        		
        <li>
            <div class="q_bx">
                <strong>Q</strong>
                <div class="txt"><span>개인회생 소요기간은?</span></div>
            </div>
            <div class="a_bx">
                <div class="txt"><p>개인회생은 보통 총 소요기간이 3 ~ 6개월까지 소요가 됩니다.</p><p>하지만 이는 평균적인 기간이며 사건의 진행내용에 따라 소요기간이 단축되거나 연장될 수 있습니다.&nbsp;</p><p>&nbsp;</p><p>1. 신청서류 준비기간</p><p>최초 개인회생 신청을 위해서 필요한 것은 신청서류 준비입니다.</p><p>개인회생 기본서류에는 동사무소 서류, 직장 및 소득관련 서류, 재산관련 서류, 배우자 및 가족관련 서류, 관공서 서류, 은행서류, 개인회생양식 서류, 채권자별 부채증명서 등이 필요합니다.&nbsp;</p><p>이 기간은 보통 1 ~ 2주 정도 예상됩니다.</p><p>&nbsp;</p><p>2. 개인회생 서류의 작성</p><p>개인회생 신청서류가 모두 준비 되었다면 법원의 양식에 맞추어 작성을 합니다.&nbsp;</p><p>이때 개인회생 금지명령 및 개인회생 중지명령 신청서류도 작성이 되며, 첨부서류와 개인회생 변제계획안 및 변제금 등을 책정합니다. 이 기간이 보통 3 ~ 5일 소요됩니다.</p><p>&nbsp;</p><p>3. 법원 접수</p><p>개인회생 서류를 법원에 직접 접수 시 신청 즉시 사건번호가 나옵니다.&nbsp;</p><p>&nbsp;</p><p>4. 사건접수 후 보정</p><p>사건번호가 부여되고 담당 개인회생 재판부가 지정되면 2 ~ 4주 안에 개인회생위원 보정 사항에 관한 연락을 받습니다.</p><p>&nbsp;</p><p>5. 개시결정</p><p>보정이 완료되고 개인회생 기각사유가 없으면 개시결정이 내려집니다.</p><p>이 기간이 보통 신청일로부터 2 ~ 3개월 정도 예상됩니다.</p><p>&nbsp;</p><p>6. 이의신청기간</p><p>개시결정 후 2개월간 채권자는 이의신청을 할 수 있습니다.</p><p>&nbsp;</p><p>7. 집회기일</p><p>개시결정 후 3월 이내로 한 날짜가 정해지며 채권자 이의기간 후로 1개월 안으로 잡히고 있습니다.</p><p>&nbsp;</p><p>8. 인가결정</p><p>채권자 집회 이후로 인가요건이 충족이 되면 개인회생 인가가 결정됩니다. 이 기간이 보통 채권자집회 후 2 ~ 3주 정도 소요됩니다.</p><p>&nbsp;</p><p>개인회생 인가결정 이후 개인회생 면책결정까지는 총 3년에서 5년 사이로 결정되어집니다.&nbsp;</p><p>이 기간은 인가결정 후 3년에서 5년이 아닌 개인회생 변제금 1회 납부를 시작으로 총 3년에서 5년이며, 최초 1회 납부일은 개인회생 신청일로부터 3개월 사시의 일정한 날로 지정됩니다.&nbsp;</p><p>&nbsp;</p><p>개인회생변제금 기간은 반드시 잘 지켜져야 하고 3개월 3회분 이상 연체시 기각결정이 내려질 수 있으니 이 부분은 신청인이 잘 확인하셔야 합니다.&nbsp;</p></div>
            </div>
        </li>
        		
        <li>
            <div class="q_bx">
                <strong>Q</strong>
                <div class="txt"><span>개인회생이 폐지되는 사유는?</span></div>
            </div>
            <div class="a_bx">
                <div class="txt"><p>1. 변제계획 인가 전 개인회생 절차가 폐지되는 사유</p><p>법원은 채무자가 제출한 개인회생 변제계획안의 인가요건을 충족시키지 못하여 인가할 수 없을 때에는 직권으로 개인회생절차 폐지결정을 합니다. 또한, 채무자가 정당한 사유 없이 채권자집회에 출석하지 아니하거나 출석하더라도 채권자의 설명요구에 응하지 아니하거나 허위의 설명을 한 때에도 개인회생절차 폐지결정을 할 수 있습니다.&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>2. 변제계획 인가 후에 개인회생 절차가 폐지되는 사유</p><p>&nbsp;</p><p>* 인가된 개인회생 변제계획을 이행할 수 없음이 명백한 때에 개인회생절차에 대한 폐지결정이 내려질 수 있습니다.</p><p>예)</p><p>채무자가 변제계획을 이행하지 못하고 있고 앞으로도 변제의 지체가 계속될 것으로 예상되는 경우,</p><p>영업자인 채무자의 영업실적이 변제계획에서 예정된 수준에 비하여 현저히 미달하고 있고 장래에 회복될 전망이 보이지 않는 경우,</p><p>변제계획에서 정한 자산매각계획을 실현하지 못하여 자금수급계획에 현저한 지장을 초래하는 경우,</p><p>개인회생재단 채권이나 우선권이 있는 채권이 과도하게 증가하여 향후 변제계획의 이행에 지장을 초래할 우려가 있는 경우,</p><p>&nbsp;</p><p>* 변제계획을 이행할 수 없음이 명백하지는 아니하지만 채무자가 재산 및 소득의 은닉 그 밖의 부정한 방법으로 인가된 변제계획을 수행하지 아니하는 때에도 개인회생절차에 대한 폐지결정이 내려질 수 있습니다. 이 경우에는 채무자가 변제계획을 이행할 의사가 없는 것으로 간주할 수 있기 때문입니다.&nbsp;</p><p>&nbsp;</p><p>* 면책불허가결정의 확정도 개인회생절차의 폐지사유에 해당됩니다. 개인회생절차를 이용하는 자는 면책결정을 받는 것을 최종 목표로 삼는데 면책불허가결정이 내려지는 경우에 개인회생절차를 진행할 실익이 없기 때문입니다. 면책불허가결정은 채무자가 악의로 개인회생채권자 목록에 기재하지 아니한 개인회생채권이 있거나 채무자가 개인채무자회생법에 정한 채무자의 의무를 이행하지 아니한 경우에 내려질 수 있습니다.</p><p>&nbsp;</p><p>&nbsp;</p><p>3. 개인회생절차가 폐지될 시 효과</p><p>개인회생절차가 폐지되면 회생위원의 권한은 소멸되고, 채권자들은 채무자의 재산에 대하여 강제집행, 가압류, 가처분 등을 할 수 있습니다. 그러나 개인회생절차의 폐지는 이미 행한 변제와 개인채무자회생법의 규정에 의하여 생긴 효력에 미치지 아니합니다. 그러나 개인회생절차가 폐지된다고 하여 채권자나 채무자가 파산신청을 하지 아니하는 한 법원이 직권으로 채무자에 대하여 파산선고를 내려야 하는 것은 아닙니다.</p><p>&nbsp;</p></div>
            </div>
        </li>
        		
        <li>
            <div class="q_bx">
                <strong>Q</strong>
                <div class="txt"><span>개인회생을 빨리 진행해야 하는 경우가 있나요?</span></div>
            </div>
            <div class="a_bx">
                <div class="txt"><p>1. 연체 이자율이 너무나 높은 경우</p><p>채무자가 부담해야하는 이자가 너무 높을 경우 개인회생절차를 통해 채무를 해결하는 것이 더욱 좋습니다. 개인회생절차에서는 원금만 변제하면 되기 때문입니다.(특이사항이 있는 경우 원리금 변제를 하는 사례도 있음)</p><p>&nbsp;</p><p>2. 회사에 급여압류 예치금이 있는 경우</p><p>급여가 압류되어 있는 경우 회사는 일정한 금액이 찰 때까지 급여를 예치합니다. 만약, 회사가 예치된 급여를 공탁하는 경우에는 그 공탁금은 원금보다 연체이자의 변제에 충당되는 경우가 대부분이고, 이렇게 회사에 급여압류 예치금이 있는 경우에는 개인회생신청을 통하여 개시결정 후 압류나 가압류를 취소하여 예치금을 찾아오거나 아니면 원금 변제에 사용하는 것이 채무자에게 유리합니다. 경우에 따라서는 예치금에 대하여 면제재산신청을 할 수도 있습니다. 다만, 면제재산을 신청하는 경우에는 법원으로부터 급여가압류 등에 대한 취소명령을 얻어야 합니다.</p><p>&nbsp;</p><p>3. 채권자가 전부명령을 할 위험성이 있을 경우</p><p>채권자가 채무자의 급여에 대하여 압류 및 전부명령을 받을 수 있는 경우 채무자는 신속하게 개인회생을 신청해야 합니다. 만약 채권자가 급여에 관하여 전부명령을 받으면 채무자의 급여에서 전부명령을 받은 부분은 소득에서 제외되며 개인회생을 신청할 때 법원에서 정한 부양가족 수에 따른 최저생계비 이상의 가용소득이 없게 될 수도 있기 때문입니다. 특히, 채권자가 확정판결이나 혹은 채무자가 작성한 어음을 공증 받아 보유하고 있는 경우애는 채무자는 급여에 대한 압류 및 전부명령을 당할 수 있습니다.&nbsp;</p><p>&nbsp;</p><p>4. 자녀의 나이가 성인에 가까워질 경우</p><p>개인회생이 법원에서 인가 결정이 나올 때에 자녀가 성인이 되면 피부양자에서 제외가 됩니다. 개인회생에서 피부양자 수가 줄어들면 변제계획안의 최저생계비가 줄어들게 되고 변제 기간 동안 생활이 더욱 힘들어 질 수 있습니다. 그러므로 자녀가 성인이 되기 전에 개인회생신청을 하셔야 높은 최저생계비를 확보하실 수 있습니다. 생계비를 계산할 때 최저생계비에 정용되는 비율이 조정됨으로써 성인에 가까운 부양가족이 있는 경우에는 생계비가 일부만 인정될 수 있습니다. 19서의 자녀가 있는 경우에는 생계비는 최저생계비의 1.5배보다 낮은 1.3배나 1.4배가 될 가능성이 있습니다.&nbsp;</p></div>
            </div>
        </li>
            </ul>
    	
	</div>

<!-- 페이징 -->
<div class="page_bx">
    <a class='page_first'>first</a>
<a class='page_prev'>prev</a>
<a class='num on'>1</a>
<a href='/kor/community/faq.php?pNo=2&amp;code=faq' class='num'>2</a>
<a href='/kor/community/faq.php?pNo=3&amp;code=faq' class='num'>3</a>
<a class='page_next'>next</a>
<a class='page_last'>last</a>
</div>

<script>
	$('#spart').on('change', function(){
		$('form#bd_search').submit();
	});

    $('select#sitem').val('');
    $('#btn_search').on('click', function () {
        $('form#bd_search').submit();
    });
</script>

                				                			</div>
                		</div>
		            </div>
                </div>
	        </div><!-- //contents -->
        </div><!-- //container -->
        <script type="text/javascript">
			/*$(".list_st04 .q_bx").click(function(){
				$(".list_st04 li").removeClass("on");
				$(".list_st04 .a_bx").stop().slideUp(300);
				
				if($(this).parent("li").hasClass("on")) {
					
				}else {
					$(this).parent("li").addClass("on");
					$(this).siblings(".a_bx").stop().slideDown(300);
				}
			});*/
			
			
			$(".list_st04 li .q_bx").click(function(){
				if($(this).parent("li").hasClass("on")) {
					$(this).parent("li").removeClass("on");
					$(this).siblings(".a_bx").stop().slideUp("300");
				}else {
					$(".list_st04 li").removeClass("on");
					$(".list_st04 li .a_bx").stop().slideUp("300");
					$(this).parent("li").addClass("on");
					$(this).siblings(".a_bx").stop().slideDown("300");
				}
			});

		</script>

		<footer id="footer" class="indexNum_">
			<div class="top_bx">
				<div class="f_inner">
					<div class="l_bx">
						<span class="ttl">상담문의</span>
						<!-- <p>
    							<strong>1544-0904(대표번호) / 042-721-0608(회생파산) / 042-721-0606(송무)</strong>업무시간 09:00 ~ 18:00 (주말, 공휴일 휴무)
    						</p> -->
						<p>
							<strong>대표번호 1544-0904</strong>
							<strong>02-6954-0478(서울회생파산) / 02-6954-0378(서울송무)</strong>
							<strong>042-721-0608(대전회생파산) / 042-721-0606(대전송무)</strong>
						<p>업무시간 09:00 ~ 18:00 (주말, 공휴일 휴무)</p>
						</p>
					</div>
					<div class="r_bx">
						<span class="ttl">glory sns</span>
						<ul class="sns_bx">
							<li class="instagram"><a href="https://www.instagram.com/glory_lawfirm/?igshid=MzRlODBiNWFlZA%3D%3D" target="_blank">instagram</a></li>
							<li class="youtube"><a href="#none" >youtube</a></li>
							<li class="facebook"><a href="#none" >facebook</a></li>
						</ul>
					</div>
				</div>
			</div>
			<div class="btm_bx">
				<div class="f_inner">
					<img src="../images/common/logo.png" class="logo" alt="법무법인 글로리">
					<ul class="link_bx">
						<li><a href="../company/intro.php">법인소개</a></li>
						<li><a href="../policy/privacy.php">개인정보처리방침</a></li>
						<li><a href="../business/areas.php">업무영역</a></li>
						<li class="dotN"><a href="../review/list.php">후기</a></li>
													<li><a class="quick_btn">상담신청</a></li>
												<li><a href="../community/notice.php">커뮤니티</a></li>
					</ul>
					<!-- <ul class="info_bx">
    						<li>상호 : 법무법인 글로리</li>
    						<li>사업자등록번호 : 604-86-02992</li>
    						<li>대표변호사 : 이아무</li>
    						<li>주소 : 대전광역시 서구 둔산중로 78번길 26, 민석타워 3층 301호</li>
    						<li>대표번호 : 1544-0904(대표번호) / 042-721-0608(회생파산) / 042-721-0606(송무)</li>
    						<li>팩스 : 042-721-0707</li>
    						<li>이메일 : glory@glorylawfirm.kr</li>
    					</ul> -->
					<ul class="info_bx">
						<li>상호 : 법무법인 글로리</li>
						<li>사업자등록번호 : 604-86-02992</li>
						<li>대표변호사 : 이아무</li>
						<li>대표번호 : 1544-0904</li>
						<li>이메일 : glorylawfirm@daum.net</li>
						<li>서울본사 : 서울특별시 강남구 테헤란로8길 13, 9층 (역삼동, WD빌딩) <span>| TEL : 02-6954-0478(회생파산), 02-6954-0378(송무)</span> <span>| FAX : 02-6954-0878</span></li>
						<li>대전지점 : 대전광역시 서구 둔산중로 78번길 26, 민석타워 3층 301호 <span>| TEL : 042-721-0608(회생파산), 042-721-0606(송무)</spaan> <span>| FAX : 042-721-0707</span></li>
					</ul>
					<p class="btm_txt">Copyright © 2023 Law Firm Glory. All Rights Reserved.</p>
				</div>
			</div>
		</footer>
		</div><!-- //wrap -->

		<script type="text/javascript">
			AOS.init({
				once: true,
				startEvent: 'load',
				disable: function() {
					//var maxWidth = 1024;
					//return window.innerWidth < maxWidth;
				}
			});
								</script>

		
		<!-- 공통 적용 스크립트 , 모든 페이지에 노출되도록 설치. 단 전환페이지 설정값보다 항상 하단에 위치해야함 -->
		<script type="text/javascript" src="//wcs.naver.net/wcslog.js"> </script>
		<script type="text/javascript">
			if (!wcs_add) var wcs_add = {};
			wcs_add["wa"] = "s_35d04fef83bb";
			if (!_nasa) var _nasa = {};
			if (window.wcs) {
				wcs.inflow();
				wcs_do(_nasa);
			}
		</script>


		</body>

		</html>