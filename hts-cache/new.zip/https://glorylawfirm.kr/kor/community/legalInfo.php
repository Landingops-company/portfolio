<!DOCTYPE html>
<html lang="ko">
<head>
<title>법무법인 글로리 - 개인회생파산센터, 이혼가사센터, 형사전문변호사</title>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="format-detection" content="telephone=no"/>
    
    <link rel="canonical" href="https://glorylawfirm.kr/kor/community/legalInfo.php/" />

	<meta name="robots" content="index,follow" />
	<meta name="subject" content="법무법인 글로리" />
	<meta name="title" content="법무법인 글로리 - 개인회생파산센터, 이혼가사센터, 형사전문변호사" />
	<meta name="author" content="법무법인 글로리">
	<meta name="description" content="서울 역삼동 본사, 개인회생파산전문센터, 이혼형사센터, 개인회생파산 및 민형사소송 종합케어, 개인회생 합리적인 수임료 친절한 상담"/>
	<meta name="keywords" content="개인회생, 이혼 재산분할, 위자료 소송, 형사고소, 도산법전문, 이혼법전문, 법무법인 글로리, 커뮤니티, 법률정보." />

	<meta property="og:type" content="website" />
	<meta property="og:rich_attachment" content="true" />
	<meta property="og:site_name" content="법무법인 글로리" />
	<meta property="og:title" content="법무법인 글로리 - 개인회생파산센터, 이혼가사센터, 형사전문변호사" />
	<meta property="og:description" content="서울 역삼동 본사, 개인회생파산전문센터, 이혼형사센터, 개인회생파산 및 민형사소송 종합케어, 개인회생 합리적인 수임료 친절한 상담" />
	<meta property="og:image" content="https://glorylawfirm.kr/kor/images/og_img2.png" />
	<meta property="og:url" content="https://glorylawfirm.kr/" />

	<meta name="twitter:card" content="summary_large_image">
	<meta name="twitter:title" content="법무법인 글로리 - 개인회생파산센터, 이혼가사센터, 형사전문변호사" />
	<meta name="twitter:description" content="서울 역삼동 본사, 개인회생파산전문센터, 이혼형사센터, 개인회생파산 및 민형사소송 종합케어, 개인회생 합리적인 수임료 친절한 상담" />
	<meta name="twitter:image" content="https://glorylawfirm.kr/kor/images/og_img2.png" />

	<meta itemprop="name" content="법무법인 글로리" />
	<meta itemprop="description" content="서울 역삼동 본사, 개인회생파산전문센터, 이혼형사센터, 개인회생파산 및 민형사소송 종합케어, 개인회생 합리적인 수임료 친절한 상담" />
	<meta itemprop="image" content="https://glorylawfirm.kr/kor/images/og_img2.png" />

	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, minimum-scale=1.0, user-scalable=no" />

	<!-- font -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;500;600;700;800;900&family=Montserrat:wght@100;200;300;400;500;600;700;800;900&family=Nanum+Myeongjo:wght@400;700;800&display=swap" rel="stylesheet">

	<link href="../css/base.css?230830" rel="stylesheet" type="text/css" />
	<link href="../css/common.css?230830" rel="stylesheet" type="text/css" />
	<link href="../css/main.css?230830" rel="stylesheet" type="text/css" />
	<link href="../css/main_2.css?230830" rel="stylesheet" type="text/css" />
	<link href="../css/sub.css?230830" rel="stylesheet" type="text/css" />
	<link href="../css/board.css?230830" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="../images/favicon.ico" type="image/x-icon">

	<!--[if lt IE 9]>
		<script src="../js/html5shiv.js"></script>
		<script src="../js/respond.min.js"></script>
		<script type="text/javascript">
			alert('현재 업데이트의 지원이 중단되어 보안이 취약한 하위버전의 브라우저를 사용하고 계십니다.\n원활한 사이트 이용을 위해서는 Internet Explorer 최신 버전으로 업데이트 하시거나,\n타 브라우저 (구글 크롬, 파이어폭스, 네이버 웨일) 사용을 권장합니다.');
		</script>
	<![endif]-->

	<!-- Google Tag Manager -->
	<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
	new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
	j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
	'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
	})(window,document,'script','dataLayer','GTM-5G8269NP');</script>
	<!-- End Google Tag Manager -->

	<script src="../js/jquery-3.7.0.min.js"></script>
	<script src="../js/slick.min.js"></script>
	<script src="../js/common.js"></script>
    <script src="/aseoul/js/dev.js"></script>

	<!-- aos -->
	<link href="../css/aos.css" rel="stylesheet" type="text/css" />
	<script src="../js/aos.js"></script>

<!-- Enliple Tracker Start -->
<script async src="https://cdn.onetag.co.kr/0/tcs.js?eid=1k1zhc4s5tb8y1k1zhc4s5"></script>
<!-- Enliple Tracker End -->

</head>

<body id="sub">

	<!-- Google Tag Manager (noscript) -->
	<noscript>
	<iframe	src="https://www.googletagmanager.com/ns.html?id=GTM-5G8269NP"	height="0" width="0" style="display:none;visibility:hidden"></iframe>
	</noscript>
	<!-- End Google Tag Manager (noscript) -->

	<div id="skipNavi">
		<ul>
			<li>
				<a href="#container">본문 바로가기</a>
				<a href="#gnb">주메뉴 바로가기</a>
			</li>
		</ul>
	</div>

	<div id="wrap">
		<header id="header" class="type1">
			<div class="bg_bx"></div>
			<div class="h_top">
				<div class="h_inner">
					<ul class="l_bx">
						<li><a href="../main/" class="col2">홈페이지</a></li>
						<li><a href="../revive/">글로리 회생센터</a></li>
						<li><a href="../divorce/">글로리 이혼센터</a></li>
						<li><a href="https://glorylawfirm-crime.com/" target="_blank">글로리 형사센터</a></li>
					</ul>
					<ul class="r_bx">
						<li class="en">Law&amp;Firm Glory</li>
						<!-- <li><a href="tel:1544-0904" class="en col2">1544-0904(대표번호) / 042-721-0608(회생파산) / 042-721-0606(송무)</a></li> -->
						<li><a href="tel:1544-0904" class="en col2">1544-0904(대표번호) / 02-6954-0478(서울회생파산) / 02-6954-0378(서울송무) / 042-721-0608(대전회생파산) / 042-721-0606(대전송무)</a></li>
					</ul>
				</div>
			</div>
			<div class="h_btm">
				<div class="h_inner">
					<a href="../main/" class="logo">법무법인 글로리</a>

					<div class="menu_bx">
						<ul class="dep1_wrap">
							<li class="dep1 dep01">
								<a href="../company/intro.php">법인소개</a>
								<ul class="dep2_wrap">
	<li><a href="../company/intro.php">글로리 소개</a></li>
	<li><a href="../company/speciality.php">글로리 특별함</a></li>
	<li><a href="../company/members.php">구성원 소개</a></li>
	<li><a href="../company/location.php">오시는 길</a></li>
</ul>							</li>
							<li class="dep1 dep02">
								<a href="../business/areas.php">업무영역</a>
								<ul class="dep2_wrap">
	<li><a href="../business/areas.php">분야별 소개</a></li>
	<li><a href="../business/process.php">절차안내</a></li>
</ul>							</li>
							<li class="dep1 dep03 a_none">
								<a href="../review/list.php">후기</a>
								<ul class="dep2_wrap">
	<li><a href="/kor/review/list.php?lawyer=1">이아무 변호사</a></li>
	<li><a href="/kor/review/list.php?lawyer=2">피재경 변호사</a></li>
	<li><a href="/kor/review/list.php?lawyer=3">정유라 변호사</a></li>
</ul>							</li>
							<li class="dep1 dep04 a_none">
								<!--<a class="contact_btn">상담신청</a>-->
								<a class="quick_btn">상담신청</a>
								<ul class="dep2_wrap">
	<!--<li><a href="#" class="contact_btn">상담신청</a></li>-->
	<li><a href="#" class="quick_btn">상담신청</a></li>
</ul>							</li>
							<li class="dep1 dep05">
								<a href="../community/notice.php">커뮤니티</a>
								<ul class="dep2_wrap">
	<li><a href="../community/notice.php">공지사항</a></li>
	<li><a href="../community/faq.php">자주묻는질문</a></li>
	<li><a href="../community/legalInfo.php">법률정보</a></li>
</ul>							</li>
						</ul>
					</div>

					<div class="r_bx">
						<div class="lang">
							<div class="on_t">KOR</div>
							<ul>
								<li><a href="#">KOR</a></li>
								<li><a href="#">ENG</a></li>
							</ul>
						</div>
						<div class="menu_btn">
							<span></span>
							<span></span>
							<span></span>
						</div>
					</div>
				</div>
			</div>

			<div class="sm_bx">
				<div class="sm_w">
					<div class="m_top m_show">
						<ul>
							<li><a href="../main/" class="col2">홈페이지</a></li>
							<li><a href="../revive/">글로리 회생센터</a></li>
							<li><a href="../divorce/">글로리 이혼센터</a></li>
							<li><a href="https://glorylawfirm-crime.com/" target="_blank">글로리 형사센터</a></li>
						</ul>
					</div>
					<div class="sm_inner"></div>
				</div>
			</div>

			<!-- 오른쪽 퀵 -->
			<div id="quick_bx">
	<div class="l_bx">
		<div class="f_btn">
			<strong>Quick Zone</strong>
		</div>
		<div class="q_btn">
			<ul>
				<li>
					<a href="../divorce/">
						<em>D</em>
						<p><span>글로리 이혼/상속센터</span></p>
					</a>
				</li>
				<li>
					<a href="../revive/">
						<em>R</em>
						<p><span>글로리 회생/파산센터</span></p>
					</a>
				</li>
				<li>
					<a href="https://glorylawfirm-crime.com/" target="_blank">
						<em>C</em>
						<p><span>글로리 형사센터</span></p>
					</a>
				</li>
			</ul>
			<a class="naver">naver blog</a>
			<a href="https://pf.kakao.com/_gPkyxj" target="_blank" class="kakao">kakao</a>
			<div class="top_btn">TOP</div>
		</div>
	</div>
	<div class="r_bx">
		<div class="con_bx">
			<div class="con_w">
				<div class="top_txt">
					<strong>Online Solution</strong>
					<p>1:1온라인 상담을 통해 신속하고 정확하게 <br class="pc_show2">고객의 니즈를 충족하는 법률서비스를 <br class="pc_show2">제공하고 있습니다.</p>
					<ul>
						<li>1.  최대 12시간이내, 담당자가 유선 연락을 드립니다.</li>
						<li>2.  예약 후 내방하시면 담당변호사와 1:1심층면담이 이루어집니다.</li>
						<li>3.  상담분야를 특정하여 주시면 즉시 담당자와 연결해 드립니다.</li>
					</ul>
				</div>
				<div class="form_bx">
					<form method="post" action="/process/online.php" id="quickform" enctype="multipart/form-data">
					<input type="hidden" name="gubun" value="online"> <!--온라인상담-->
					<input type="hidden" name="captcha_form" value="quick">
						<input type="text" name="name" placeholder="이름">
						<input type="text" name="tel" placeholder="연락처">
						<select name="region">
							<option value="">지역</option>
															<option  value="1">서울</option>
															<option  value="2">인천</option>
															<option  value="3">세종</option>
															<option  value="4">대전</option>
															<option  value="5">대구</option>
															<option  value="6">울산</option>
															<option  value="7">광주</option>
															<option  value="8">부산</option>
															<option  value="9">제주</option>
															<option  value="10">강원도</option>
															<option  value="11">경기도</option>
															<option  value="12">충청북도</option>
															<option  value="13">충청남도</option>
															<option  value="14">경상북도</option>
															<option  value="15">경상남도</option>
															<option  value="16">전라북도</option>
															<option  value="17">전라남도</option>
													</select>
						<select name="fields">
							<option value="">상담분야</option>
															<option value="1">회생/파산</option>
															<option value="2">이혼</option>
															<option value="3">가사 및 상속</option>
															<option value="4">민사 채권, 채무</option>
															<option value="5">형사</option>
															<option value="6">기업법무/자문</option>
															<option value="7">소년보호</option>
															<option value="8">부동산</option>
															<option value="9">행정</option>
															<option value="10">상가임대차</option>
															<option value="11">의료</option>
															<option value="12">성범죄</option>
															<option value="13">교통사고</option>
													</select>
						<textarea name="content" placeholder="기타 문의내용"></textarea>
						<span class="txt">※ 필요할 경우 상담내용을 입력해 주시면 됩니다.</span>
						<div class="chk_bx">
							<input type="checkbox" id="quick_agree" name="safeguard">
							<label for="quick_agree">개인정보 수집 및 이용에 동의</label>
						</div>
                        <div class="captcha" style="height: 60px">
                            <span id="reCaptcha"><img src="/kor/inc/kcaptcha/?form=quick&PHPSESSID=q25mjso2juik2cjnnsqs3lcugk&rand=1405650101"></span>
                            <p><input type="text" name="captcha" placeholder="보안 문자 입력" /></p>
                        </div>
						<a href="#" onclick="quickSend(); return false;" class="btn"><span>법률상담 신청하기</span></a>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>

<script>
function quickSend(){
	var f = document.getElementById('quickform');
	var safeguard = $('#quickform [name=safeguard]:checkbox').prop('checked');

	if(!$.trim(f.name.value)){
		alert("이름을 입력해주세요.");
		f.name.focus();
		return false;
	}else if(!$.trim(f.tel.value)){
		alert("연락처를 입력해주세요.");
		f.tel.focus();
		return false;
	}else if(!$.trim(f.region.value)){
		alert("지역을 선택해주세요.");
		f.region.focus();
		return false;
	}else if(!$.trim(f.fields.value)){
		alert("상담분야를 선택해주세요.");
		return false;
	}else if(safeguard == false){
		alert("개인정보수집 및 이용동의 약관에 동의하세요.");
		return false;
	}else if (!f.captcha.value.trim()) {
        alert("보안 문자를 입력해 주십시오.");
        f.captcha.focus();
        return false;
    }else{
        //console.log( $(f).serialize() );

		f.submit();
	}
}
</script>


<!-- 팝업 -->
<div id="q_pop_bx">
	<div class="pop_w">
		<div class="pop_c">
			<!-- 회생/파산 -->
			<div class="pop_con_bx">
				<div class="ttl_bx">
					<div class="close_btn">닫기</div>
					<strong>Glory Blog</strong>
					<p>법무법인 글로리에서 운영하는 블로그를 소개합니다</p>
				</div>
				<ul class="link_bx">
					<!--<li><a href="https://blog.naver.com/glorylawfirm2" target="_blank"><span><strong>글로리 회생센터</strong> 블로그 바로가기</span></a></li>-->
					<li><a href="https://blog.naver.com/tphyak80" target="_blank"><span><strong>글로리 회생센터</strong> 블로그 바로가기</span></a></li>
					<!--<li><a href="https://blog.naver.com/glorylawfirm" target="_blank"><span><strong>글로리 이혼센터</strong> 블로그 바로가기</span></a></li>-->
					<li><a href="https://blog.naver.com/lawfirmglory/223431902141" target="_blank"><span><strong>글로리 이혼센터</strong> 블로그 바로가기</span></a></li>
					<li><a href="https://blog.naver.com/glorylawfirm3" target="_blank"><span><strong>글로리 민ㆍ형사센터</strong> 블로그 바로가기</span></a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	$("#quick_bx .l_bx .q_btn .naver").click(function(){
		$("#q_pop_bx").stop().fadeIn(300);
		$("html").css("overflow-y", "hidden");
	});
	
	$("#q_pop_bx .ttl_bx .close_btn").click(function(){
		$("#q_pop_bx").stop().fadeOut(300);
		setTimeout(function(){
			$("html").css("overflow-y", "auto");
		},100);
	});
    
    document.querySelector('#reCaptcha').addEventListener('click', function() {
        this.innerHTML = '<img src="/kor/inc/kcaptcha/?form=quick&PHPSESSID=q25mjso2juik2cjnnsqs3lcugk&rand=' + Math.random() + '">';
    });
</script>		</header><!-- //header -->
<div id="s_visual" class="s_visual_05">
	<div class="slogan">
		<div class="title_box">
   			<div class="bg_img"></div>
			<div class="ttl_w">
				<div>
					<div class="title" data-aos="fade-down" data-aos-duration="600">커뮤니티</div>
					<div class="sub_tit" data-aos="fade-up" data-aos-duration="600"><span>고객의 올바른 동반자로서 진실된 서비스를 제공하기 위하여 구성원 각자 <br class="pc_show2">끊임없이 혁신에 매진하여 고객의 미래를 설계합니다.</span></div>
				</div>
			</div>
		</div>
	</div>
   			<div class="tab_box">
			<div class="on_txt m_show"><span>법률정보</span></div>
			<ul class="dep2_wrap">
	<li><a href="../community/notice.php">공지사항</a></li>
	<li><a href="../community/faq.php">자주묻는질문</a></li>
	<li><a href="../community/legalInfo.php">법률정보</a></li>
</ul>		</div>
	</div>
<script type="text/javascript">
	setTimeout(function(){
		$("#s_visual .slogan .title_box > .bg_img").addClass("on");
	},10);
	
	$("#header .menu_bx .dep05").addClass("on");
	
			$("#header .menu_bx .dep05 .dep2_wrap > li:nth-child(03) a").addClass("colOn");
		setTimeout(function(){
			$("#s_visual .tab_box .dep2_wrap > li:nth-child("+03+")").addClass("on");
		}, 10);
		 
	$("#s_visual .tab_box .on_txt").click(function(){
		$(this).toggleClass("on");
		$("#s_visual .tab_box .dep2_wrap").stop().slideToggle(300);
	});
</script>		<div id="container">
			<div id="contents">
                <div id="legalInfo">
                	<div class="box box1">
                		<div class="inner_bx">
                			<div class="ttl_01">
                				<strong>
                					<span>Legal Information</span>
                					<p>법률정보</p>
                				</strong>
                			</div>
                			<div id="board">
								<script type="text/javascript" src="/se2/js/HuskyEZCreator.js" charset="utf-8"></script>

<!-- 검색 -->
<div class="list_top">
	<div class="count">총 <span>9</span>개의 게시물</div>
	<div class="search_bx">
		<form name="searchFrm" id="bd_search">	
			<input type="text" name="sorder" id="sorder" value="" placeholder="검색어를 입력해주세요.">
			<a href="#" class="btn" id="btn_search">검색</a>
		</form>
	</div>
</div>

<div class="list_st02"> <!-- 9개씩 -->
	    <div class="list_w">
                <a href="/kor/community/legalInfo.php?m=v&idx=192&pNo=1&code=law" class="con_bx">
            <div class="subject">“불성실 낙인찍힐라”… 채무자 60%, 3년 넘게 버티다 파산신청 [심층기획-벼랑 끝 몰린 자영업자]</div>
            <div class="txt">(하) 새 출발 발목 잡는 도산제도파산신고 기간 증가 추세3년 변제시 탕감하는 개인회생 있지만자영업자 ‘들쭉날쭉’ 수입에 신청 꺼려“남의 돈 떼어먹는 것 같다” 선입견도개인파산은 갱생 출발점취업 제한 등 불이익 차단 규정에도직업상 결격사유 개별 법률만 200개“‘파산선고 복권’ 관련 규정 삭제 필요”채무자 각종 제약 풀어야“파산정보 기록, 경제범죄와 동일 취급‘파산선고’ 용어, 형사사건 피고인 연상”금융거래·신용회복 제한 완화 목소리“자영업자들이 채무조정 절차에 빠르게 진입해 영업을 유지하면서도 할 수 있는 최선의 선택이 개인회생입니다. 그런데 본인이 스스로 버티다가 폐업하고 채무상태가 악성화돼서야 도산 법원에 가는 경우가 더 많아 안타깝습니다.”서울금융복지상담센터 황상진 상담관은 채무조정을 ‘병원 진료’에 비유했다. 몸이 아프면 최대한 빨리 병원에 가 진찰받아야 하듯 채무를 견디기 어려워지면 빠르게 채무조정제도를 접해 상황에 맞는 도산 절차를 밟아야 한다는 취지에서다. 하지만 그는 도산제도에 대한 사회적인 벽이 여전히 존재한다고 지적했다. 황 상담관은 “사회적 분위기가 도산제도에 대해 ‘빚지면 내가 갚아야 하는 건데 남의 돈 떼어먹으려고 하는 것 같다’는 선입견들이 있는 것 같다”고 말했다.7일 도산법연구회에 따르면 2019년부터 지난해까지 경제적 어려움에 처했을 때 조기에 파산신청을 하는 채무자의 비율은 매년 감소 추세에 있는 반면 채무조정을 받지 않고 버티다 채무가 악성화돼서야 법원을 찾는 이들은 늘어나고 있는 것으로 나타났다. 과도한 빚으로 경제활동이 어려운 이들을 빠르게 사회로 복귀시켜 생산력을 높이려는 도산 제도의 취지가 무색해지고 있는 것이다.◆파탄부터 파산신고까지 기간 점점 길어져지난해 개인파산 사건 중 ‘파탄원인이 발생한 때로부터 파산신청 시까지 기간’이 3년 이상인 채무자 비율은 60.2%로 절반 이상인 것으로 집계됐다. 파산 신청까지의 기간이 6년 이상 10년 미만인 채무자의 비율도 16.64%에 달한다.이 같은 현상의 원인은 개인파산을 통해 면책받은 사람을 ‘불성실하다’고 보는 사회적 시선과 차별의 불이익이 꼽힌다. 이성원 한국중소상인자영업자총연합회 사무총장은 “파산까지 가는 건 대부분 꺼리고 주위에 알려지길 원치도 않는다. 파산선고를 받으면 먹고살 길이 없어진다 생각하기 때문”이라고 말했다.변제가 끝나면 기록이 보관되지 않는 개인회생과 다르게 개인파산은 면책을 받고 5년간 그 기록이 남는다. 금융거래가 5년간 사실상 제한된다. 또한 신용회복위원회의 개인워크아웃 절차에서 6개월 이상, 개인회생 절차에서 12개월 이상 성실하게 변제했을 경우 서민금융진흥원의 ‘성실상환자 소액금융대출’ 제도를 이용할 수 있으나 개인파산 절차를 이용한 경우 이러한 금융 지원이 불가능하다. 개인파산을 마치고 나면 최저생계수단을 제외한 재산을 전부 채권자에 돌려준 상태가 된다. 직장에 다니는 급여소득자와 달리, 자영업자가 다시 소득 활동을 하려면 자기 기술을 살려 가게를 열어야 하는데, 금융거래가 막히면 저임금 혹은 비정규직 일자리를 전전해야 한다.회생·파산 사건을 주로 다루는 이아무 법무법인 글로리 변호사는 “채권자 입장에서도 채무자가 빚을 갚기 위해 불필요한 추가대출을 하면 리스크가 더 커지기 때문에 채무자가 제때 개인회생등을 신청하는 것이 유리하다”고 설명했다. 그러나 자영업자는 개인회생을 신청하는 것조차 쉽지 않다는 지적이 나온다. 일반적인 개인회생은 월평균소득에서 최저생계비를 제외한 금액을 3년 동안 변제하면 나머지 채무를 면책해 주는 제도이다. 개인회생 절차를 밟으려면 납부금을 성실하게 낼 수 있는지가 중요한데, 일정한 금액을 정기적으로 받는 직장인은 소득이 분명하게 파악되지만 자영업자는 수입이 매달 다르기 때문이다. 따라서 신청 서류도 복잡하고 인가결정까지 기간도 길다. 황 상담관은 “개인회생을 신청하려고 폐업을 하고 급여소득자 일자리를 잡아 개인회생을 진행하는 경우도 있지만 갑자기 잡은 일자리는 비정규직 등 불안정한 경우가 많아 변제에 실패하고 면책되지 않는 경우도 많다”고 설명했다.◆“파산, 징계 아닌 갱생 위한 절차돼야”파산선고를 받으면 새로운 직업을 구하는 데도 제약이 따를 수 있다. 40대 A씨는 병원에서 간호사로 일하며 안정적인 생활을 했다. ‘파산’은 남의 이야기라고 생각했다. 하지만 갑자기 사기를 당하면서 2억여원의 빚이 생겼다. 자녀 셋을 키우며 이미 빠듯한 생활을 하던 B씨는 빚을 갚는 것이 사실상 불가능했다. 법원에서 개인파산 신청을 하면 빚을 면책받을 수 있다는 것을 알게 됐으나 직장 생활에 문제가 생길까 봐 법원을 찾을 수 없었다. 파산선고를 받으면 간호사 자격과 채용에 불이익이 있는 것으로 잘못 알고 있었기 때문이다. 2007년 전면 개정된 의료법은 의료인의 결격사유 규정에서 ‘파산선고를 받고 복권되지 아니한 자’를 삭제했다. 그로 인해 간호사인 A씨는 파산제도를 이용해도 간호사 자격이 유지될 수 있다.채무자 회생 및 파산에 관한 법률 제32조는 “누구든지 이 법에 따른 회생절차·파산절차 또는 개인회생절차 중에 있다는 이유로 정당한 사유 없이 취업의 제한 또는 해고 등 불이익한 처우를 받지 아니한다”고 규정하고 있다. 그러나 이러한 차별금지 규정에도 불구하고 파산선고를 직업상 결격 사유로 규정하는 개별 법률은 여전히 존재하고 있다. 도산사건 경험이 많은 수도권의 한 판사는 “파산선고를 받고 복권되지 않으면 공무원, 경비원, 아이돌보미 등이 될 수 없고 이와 같은 법률이 현재 200여개 이상 존재하고 있다”며 “파산은 징계가 아닌 갱생을 위한 절차다. ‘자격상실’, ‘복권’과 같은 표현은 전 근대적 유물”이라며 복권에 관한 규정을 없애는 등 변화가 필요하다고 주장했다.◆도산제도, 선순환으로 이어지려면법조계에선 이른바 ‘신용 전과’ 문제 등 개인파산 제도 가운데 새 출발의 발목을 잡는 제약을 완화해 채무자들이 제때 적합한 채무조정을 받도록 해야 한다는 지적이 나온다. 소득이 적고 부채가 많아 개인회생이 아닌 파산 절차를 이용했다는 이유로 각종 제한을 가하는 것은 불합리하다는 것이다.박정만 경기도 금융복지센터장(변호사)은 “금융위원회는 명의도용, 보험사기 등 ‘신용질서 문란행위’에 대해 신용정보를 발생일로부터 5년 내 삭제하도록 규정하는데, 파산선고, 회생 등의 관련 정보도 발생일로부터 5년 내 삭제하도록 한다”며 “이는 개인파산을 경제 범죄와 동일시하는 것”이라고 지적했다.‘파산선고’라는 용어가 형사사건에서의 피고인을 연상시킨다며 용어부터 변경하자는 목소리도 나온다. 일본은 2004년 파산법을 개정하면서 ‘파산선고’를 ‘파산절차개시결정’으로, ‘파산원인’을 ‘파산절차개시원인’ 등으로 용어를 변경했다. 박현근 한국파산회생변호사회장은 “개인 회생에서는 개인회생 개시 결정이라는 용어를 쓴다. 파산도 마찬가지로 파산신청을 해서 절차를 진행하는 것이지 파산신청을 했다고 파산자로 선고를 당하는 것이 아니다”고 말했다.서울 서초구 서울회생법원에서 한 시민이 상담을 위해 기다리고 있다. 연합뉴스도산절차를 이용한 채무자의 금융거래 제한을 완화하자는 목소리도 이어진다. 다수의 도산사건을 맡았던 한 판사는 “도산 제도의 취지는 채무자들이 계속 경제활동을 이어가도록 하는 것”이라며 “조금이라도 신용을 당겨서 활동할 여력을 만들어 주기 위해 개인파산절차 이후에도 햇살론 등 금융지원을 받을 수 있도록 제도 개선이 필요하다”고 언급했다.박 센터장은 “개인파산자는 법원에서 충분한 판단 끝에 도덕적 해이 가능성이 없다고 보고 면책결정을 내린 것”이라며 “면책결정이 내려지면 신용제한을 완화할 필요가 있다”고 제안했다. 대신 제도의 악용과 남용을 막기 위해 재파산의 경우에는 기존대로 각종 제한을 두자는 설명이다. 그는 이어 “개인회생의 경우 대출금으로 변제금을 납부할 가능성이 있긴 하다”면서 “하지만 획일적으로 신용회복에 3년 제한을 두는 것은 과도하기 때문에 이를 1년으로 단축하는 방안을 검토할 필요가 있다”고 덧붙였다.안경준 기자 eyewhere@segye.com참고법률신문https://n.news.naver.com/article/022/0003842564?cds=news_edit</div>
            <div class="date">2023-08-08</div>
        </a>
                <a href="/kor/community/legalInfo.php?m=v&idx=191&pNo=1&code=law" class="con_bx">
            <div class="subject">채무조정 방법 어떤 게 있나 [심층기획-벼랑 끝 몰린 자영업자]</div>
            <div class="txt">채무자 일정한 수입 있을 땐 ‘개인회생제’로 탕감 가능최대 5년 원금 변제 후 나머지 금액 면책소득이 없을땐 ‘개인파산’ 적용 재산 배당채무 30일 이하로 단기 연체 중인 경우엔신복위 채무조정으로 이자 감면 등 가능개인이 악성 채무를 조정할 수 있는 방법은 기관에 따라 크게 두 갈래로 나뉜다. 법원을 통한 개인회생 및 개인파산제도와 신용회복위원회(신복위)의 채무조정이 있다.6일 법조계에 따르면 과다한 채무로 지급불능 상태인 채무자가 일정한 수입이 있는 경우 3년(최대 5년)에 걸쳐 원금 일부를 변제하면 나머지를 면책받는 개인회생 제도를 이용할 수 있다. 채무자가 법원에 신청서를 제출하면 변제계획 인가를 거쳐 변제를 수행하게 된다.사진=뉴스1이 과정에서 산정되는 채무자의 일정 소득은 매월 변제해야 할 금액을 결정하는 데 중요한 기준이 된다. 채무자의 월평균 소득에서 최저생계비를 뺀 돈을 변제 기간 동안 갚게 되기 때문이다. 인가된 계획대로 변제를 마치면 전체 채무 중 갚지 못한 나머지 부분은 면책받게 된다.개인파산은 법원이 채무자의 변제능력이 없음을 인정하고 잔여 재산을 채권자에게 배당한 후 면책하는 제도다. 모든 채권자가 평등하게 채권을 변제받도록 보장하고, 채무자에게는 경제적으로 재기·갱생할 기회를 부여하는 게 개인파산의 주된 목적이다.회생·파산 전문인 이아무 변호사(법무법인 글로리)는 “파산의 경우 전혀 변제를 하지 않는다는 오해가 많다”며 “오히려 신청인이 소유한 재산이나 소유로 인정되는 재산에 해당하는 금액을 일시에 변제해야 가능한 경우가 많고, 경제활동 능력이 있어 파산신청이 받아들여지지 않을 수도 있다”고 설명했다.법원의 회생·파산사건과 달리 신복위는 사적 채무조정제도를 운용한다. 대상은 ‘신용회복지원협약’을 체결한 금융회사의 채무다. 채무를 30일 이하로 단기 연체 중인 경우 연체이자를 감면받고 상환 기간을 연장하는 신속채무조정(연체 전 채무조정)과 연체일에 따라 사전채무조정(이자율 채무조정)과 채무조정(개인워크아웃)으로 구분된다.박정만 경기도금융복지센터장은 “사람이 아프면 의사가 진단을 내리고 약을 먹거나 수술을 하는 처방이 뒤따른다”며 “빚 문제에서도 채무 발생 원인이 어디에서 비롯됐고, 언제 발생했는지, 채무 성격과 채무자 연령 등 채무자가 처한 복합적인 상황에 비춰 가장 적합한 해결방안을 찾는 진단이 먼저 필요하다”고 강조했다.법률신문 참조https://www.segye.com/newsView/20230806508216?OutUrl=naver</div>
            <div class="date">2023-08-07</div>
        </a>
                <a href="/kor/community/legalInfo.php?m=v&idx=68&pNo=1&code=law" class="con_bx">
            <div class="subject">화제의 뉴스  '부산 돌려차기 사건' 가해자, 항소심서 징역 20년 선고 </div>
            <div class="txt">새벽에 귀가하던 20대 여성을 무차별적으로 폭행해 의식을 잃게 한 이른바 '부산 돌려차기' 사건의 가해자에게 항소심에서 징역 20년이 선고됐다.부산고법 형사2-1부(최환, 이재욱, 김대현 부장판사)는 12일 성폭력범죄의 처벌 등에 관한 특례법 위반(강간등살인), 살인미수 등 혐의로 기소된 이모 씨에 대한 항소심에서 징역 20년을 선고했다(2022노497).이와 함께 10년간 정보통신망 신상 공개, 10년간 아동·청소년 및 장애인 관련 기관 취업 제한, 20년간 위치추적 전자장치 부착을 명령했다.이날 재판부는 항소심에서 주위적으로 추가된 성폭력처벌법 위반(강간등살인) 혐의를 유죄로 인정했다. 또 심신미약 주장과 함께 살인의 고의가 없었다는 이 씨의 주장을 모두 배척했다.특히 재판부는 "최초 목격자와 출동 경찰관 등의 증언, 피해자의 청바지에 대한 감정 결과 등을 종합해 피고인이 폭행으로 의식을 잃은 피해자를 CCTV가 설치되지 않은 복도 구석으로 옮긴 뒤 피해자가 입고 있던 청바지와 속옷을 벗긴 사실을 충분히 인정할 수 있다"며 "피해자의 옷을 벗긴 행위에서 나아가 실제로 간음, 유사간음 등 성폭력범죄의 실행행위까지 저지른 사실을 인정할 직접적 증거는 없지만, 앞선 증거들에 의해 인정되거나 추단되는 사정들에 비춰 보면, 피고인은 강간의 목적 내지 수단으로 피해자에게 폭행을 가했다고 봄이 타당하다"고 판단했다.이어 "피고인이 강간의 수단 또는 목적으로 피해자에게 폭행을 가했고, 폭행 당시에 살인의 미필적 고의까지 있었던 이상 성폭력처벌법 제15조, 제9조 제1항에서 정한 강간등살인의 미수죄가 성립한다"고 강조했다.그러면서 "사람의 생명을 침해하는 살인은 어떠한 이유로도 용납될 수 없는 중대한 범죄로서 미수에 그쳤다고 해서 그 죄책이 결코 가볍다고 할 수 없다"며 "이 사건은 성폭력범죄의 수단으로 범행을 저질렀다는 점에서 더욱 죄책이 무겁고, 비난가능성이 매우 크다"고 양형 이유를 설명했다.이 씨는 2022년 5월 22일 오전 5시께 귀가하던 피해자 A 씨를 일정한 거리를 유지한 채 10여 분간 뒤쫓아 가 부산진구의 한 오피스텔 공동현관에서 돌려차는 방법으로 A 씨의 뒷머리를 가격한 혐의(살인미수)로 기소됐다. 하지만 항소심 과정에서 사건 당시 A 씨가 입었던 청바지에서 이 씨의 DNA가 검출되는 등 추가 증거가 드러나면서 검찰은 기존 살인미수 혐의 외에 강간살인미수 혐의를 추가하는 내용으로 공소장을 변경했고, 징역 35년에 위치추적 전자장치 부착, 보호관찰명령 20년을 구형했다.앞서 1심을 맡은 부산지법 형사6부(재판장 김태업 부장판사)는 2022년 10월 이 씨에게 징역 12년을 선고하고 20년간 위치추적 전자장치 부착을 명령했다.법률신문 참조 https://www.lawtimes.co.kr/Case-curation/188284</div>
            <div class="date">2023-06-16</div>
        </a>
                <a href="/kor/community/legalInfo.php?m=v&idx=63&pNo=1&code=law" class="con_bx">
            <div class="subject">대법원," ‘유책배우자의 이혼청구 예외적 허용’ 구체적 판단기준 제시"</div>
            <div class="txt">대법원은 혼인관계가 실질적으로 파탄에 이르렀더라도 파탄에 주된 책임이 되는 유책배우자의 이혼청구는 원칙적으로 허용되지 않는다는 입장을 취하고 있다.(2013므568)이런 와중에 유책배우자의 이혼청구를 예외적으로 허용할 수 있는 경우에 대해 구체적 판단 기준을 제시하는 대법원 판결이 나왔다. 법조계 일각에서는 이 판결이 유책주의를 유지하면서도 그에 대한 예외사유를 구체화·완화했다고 볼 수 있어, 향후 사회적 논의를 통해 파탄주의가 인정되는 길을 열어주는 초석이 될 수 있을 것이란 견해도 나온다.대법원 가사2부(주심 민유숙 대법관)는 A씨가 B씨를 상대로 제기한 이혼 등 소송(2021므14258)에서 원고패소 판결한 원심을 파기하고 지난달 16일 사건을 인천가정법원으로 돌려보냈다.재판부는 "상대방 배우자의 혼인계속의사를 인정하려면 혼인생활의 전 과정과 이혼소송이 진행되는 중 드러난 상대방 배우자의 언행 및 태도를 종합해 원만한 공동생활을 위해 노력해 혼인유지에 협조할 의무를 이행할 의사가 있는지 객관적으로 판단해야 한다"며 "한쪽이 이혼소송을 제기했다가 유책배우자라는 이유로 패소가 확정됐더라도, 이후 상대방도 유책성을 계속 비난하며 전면적인 양보만을 요구하거나, 민·형사소송 등 혼인관계 회복과 양립하기 어려운 사정이 남아있는데도 이를 정리하지 않은 채 장기간의 별거가 고착화된 경우, 이미 혼인관계가 회복될 가능성이 없어 상대방을 설득해 협의에 의해 이혼하는 방법도 불가능해진 상태까지 이르렀다면 종전 이혼소송시 일방배우자의 유책성이 상당히 희석됐다고 볼 수 있고, 이는 현재 이혼소송의 사실심 변론종결시를 기준으로 판단해야 한다"고 판시했다.한쪽이 이혼소송 제기했다가‘유책배우자’ 이유로 패소됐더라도장기별거 고착화 등으로관계 회복 가능성 없다면 유책성 희석취약한 지위로 보호 필요성 있는 경우이혼청구에 신중 기하고미성년자가 있는 경우자녀에게 미칠 영향도 모두 심리 해야다만 "상대방 배우자가 경제적·사회적으로 매우 취약한 지위에 있어 보호의 필요성이 큰 경우에는 유책배우자의 이혼청구를 허용함에 신중을 기해야 한다"며 "상대방 배우자가 혼인의 계속과 양립하기 어려워 보이는 언행을 하더라도, 이혼거절의사가 이혼 후 자신 및 미성년 자녀의 정신적·사회적·경제적 상태와 생활보장에 대한 우려에서 기인한 것으로 볼 여지가 있는 때에는 혼인계속의사가 없다고 섣불리 단정해서는 안된다"고 덧붙였다. 아울러 "미성년 자녀가 있는 경우에는 파탄된 혼인관계를 유지하는 것이 자녀에게 미칠 긍정적·부정적 영향을 모두 심리해야 한다"고 했다.부장판사 출신 변호사는 "기존에도 예외를 인정하는 대법원 판결이 있었지만 이번 판결은 그 예외를 보다 구체화하고 완화했다고 볼 수 있다"며 "이번 판결은 유책주의에 기반한 판결이지만, (이 판결을 통해) 앞으로 사회적 논의가 이뤄질 경우 추후 파탄주의가 인정될 것이라는 견해도 있을 수 있다"고 말했다. 또다른 부장판사 출신 변호사는 "지난 전원합의체 판결이 유책주의를 고착화하는 것이 아니라, 유책주의는 필요하지만 상대방에게 가혹한 사정이 없는 경우에는 파탄주의로 가도 되지 않겠느냐는 의미였다"며 "그런데 전합 판결 이후 하급심에서 대법원이 유책주의로 간다는 시그널로 받아들여 오히려 유책주의에 입각한 판결을 하니, (이번에) 지난 전합 판결의 의미가 무엇인지 다시 풀어서 설시한 것으로 보인다"고 말했다.대법원 관계자는 "대법원 전원합의체 판결(2013므568)을 토대로 유책배우자의 이혼청구를 예외적으로 허용할 수 있는 경우와 허용할 수 없는 경우의 판단기준을 구체적으로 제시하고, '상대방 배우자의 혼인계속의사'의 판단기준과 판단방법을 처음 구체화해 제시한 판결"이라고 말했다.2010년 3월 혼인신고를 한 A, B씨는 그해 12월 딸을 출생했다. A씨는 갈등 끝에 집을 나가 2016년 5월 B씨를 상대로 이혼소송을 청구했지만, 법원은 "A씨에게 혼인관계 파탄에 더 큰 책임이 있다"며 기각했다. 판결 확정 후에도 A씨는 B씨와 별거 중이었다. A씨는 딸의 양육비 및 B씨와 딸이 지내는 아파트 담보대출금을 내고 있었다. B씨는 A씨에게 딸을 만나기 위해서는 자신에게 연락하고 집으로 돌아오라고 한 뒤, 일방적으로 집 잠금장치를 변경하고 A씨에게 열쇠를 주지 않은 채 A씨가 먼저 집으로 들어와야만 한다고 요구했다. A씨는 2019년 다시 이혼소송을 냈다. 1,2심은 원고패소 판결했다.법률신문 참조https://www.lawtimes.co.kr/Case-curation/180157</div>
            <div class="date">2023-06-16</div>
        </a>
                <a href="/kor/community/legalInfo.php?m=v&idx=61&pNo=1&code=law" class="con_bx">
            <div class="subject">대법원 "채무자가 채권목록에 소멸시효 지난 채권 기재시 소멸시효이익포기로 단정 못한다"</div>
            <div class="txt">채무자가 개인회생을 신청하면서 채권자목록에 소멸시효가 지난 채권을 적어냈다고 해서 곧바로 시효이익을 포기한 것으로 봐선 안 된다는 대법원 판결이 나왔다. 채권목록은 채무를 알고 있다는 표시에 불과하기 때문에 시효이익 등 법적인 이익을 포기하겠다는 의사는 별도의 명시적 의사표시가 필요하다는 취지다.대법원 민사2부(주심 김창석 대법관)는 A사가 송모씨를 상대로 낸 배당이의소송(2014다32458)에서 원고패소 판결한 원심을 깨고 최근 사건을 대전지법으로 돌려보냈다.송씨는 김모씨가 소유한 대전 중구의 한 부동산에 1998년 6월 20일부터 5000만원의 근저당권을 갖고 있었다.김씨는 지역 신용협동조합과 신용금고 등 여러 곳에 빚을 지고 있었는데, A사는 신협 등으로부터 김씨에 대한 채권을 인수한 뒤 2011년 8월 김씨의 부동산에 대해 강제경매를 신청했다. 김씨는 2012년 1월 개인회생을 신청하며 채권자목록에 송씨의 근저당권을 담보부회생채권으로 신고했다.그런데 경매 후 근저당권자인 송씨에게 5000만원이 배당되고 A사에는 1400여만원만 배당되자 A사는 "송씨의 채권은 10년이 지나 소멸시효로 사라졌으니 송씨에 대한 배당은 취소하고, 우리 배당액을 6500만원으로 올려달라"며 2013년 6월 소송을 냈다.재판부는 "소멸시효 중단사유로서의 채무승인은 시효이익을 받는 당사자인 채무자가 소멸시효의 완성으로 채권을 상실하게 될 자에 대해 상대방의 권리 또는 자신의 채무가 있음을 알고 있다는 뜻을 표시함으로써 성립하는 '관념의 통지'일 뿐"이라면서 "시효완성 후 시효이익 포기가 인정되려면 시효이익을 받는 채무자가 시효의 완성으로 인한 법적인 이익을 받지 않겠다는 '효과의사'가 필요하기 때문에, 채무의 승인이 있었다 하더라도 그것만으로는 곧바로 소멸시효 이익의 포기라는 의사표시가 있었다고 단정할 수 없다"고 밝혔다.이어 "채무자가 개인회생신청을 하면서 소멸시효기간이 완성된 근저당부 채권을 채권자목록에 적었다 하더라도, 채권의 시효완성으로 인한 법적인 이익을 받지 않겠다는 의사표시까지 있었다고 단정하기 어렵다"면서 "원심의 판단은 소멸시효이익의 포기에 대한 법리를 오해한 잘못이 있다"고 판시했다.앞서 1,2심은 "원래대로라면 소멸시효에 따라 피담보채권이 소멸하는 게 맞지만, 김씨가 시효가 지난 2012년 1월 개인회생을 신청하며서 채권자목록에 송씨의 근저당권을 담보부회생채권으로 신고했고, 이후 강제경매절차가 시작된 후 송씨 앞으로 5000만원을 배당한 배당표가 작성될 때도 별 이의를 제기하지 않은 점 등을 보면 김씨가 채권자목록에 채무를 인정하는 취지로 채권을 기재하면서 송씨에 대한 채무를 승인함으로써 시효이익을 포기했다고 봐야 한다"며 원고패소 판결했다.법률신문 참조https://www.lawtimes.co.kr/Case-curation/119886</div>
            <div class="date">2023-06-16</div>
        </a>
                <a href="/kor/community/legalInfo.php?m=v&idx=60&pNo=1&code=law" class="con_bx">
            <div class="subject">"면책 후 파산채권자의 채무이행 선고 확정됐더라도 면책이 개인파산채무자의 청구이의 사유라면" </div>
            <div class="txt">개인채무자가 면책 결정을 확정 받았지만 이후 파산채권자가 채무 이행을 요구하며 낸 소송에서 사실심 변론종결 시까지 이같은 면책 사실을 주장하지 못해 패소 판결이 확정됐더라도 특별한 사정이 없는 한 개인채무자는 면책된 사실을 내세워 청구이의의 소를 제기할 수 있다는 대법원 판결이 나왔다. 면책이 청구이의 사유인 경우에는 변론종결 후에 면책된 경우뿐만 아니라 변론종결 전에 면책된 경우에도 예외적으로 청구이의의 소를 인용해야 한다는 취지다.대법원 민사3부(주심 김재형 대법관)는 지난달 28일 A 씨가 B 씨를 상대로 낸 청구이의 소송(2017다286492)에서 원고패소 판결한 원심을 파기하고 사건을 서울남부지법으로 돌려보냈다.면책 사유 발생은변론종결 전·후 관계없이 청구사유 인정해야대법원 원고패소 원심파기A 씨는 B 씨의 아버지가 2006년 제기한 대여금 청구 소송에서 패소해 500만 원을 지급하라는 판결을 받았다. B 씨는 이 채권을 자신이 양수했다며 2014년 3월 A 씨를 상대로 양수금 청구 소송을 냈다. 그런데 이 소송에서 A 씨에게 송달이 이뤄지지 않아 법원은 공시송달로 사건을 진행해 A 씨의 변론이 없는 상태로 2014년 12월 B 씨의 손을 들어줬고, 이 판결은 확정됐다. 그러나 사실 A 씨는 2011년 3월 이미 파산 결정을 받아 그해 12월 파산에 따른 면책결정을 확정 받은 상태였다. 결국 A 씨는 B 씨가 낸 양수금 청구 소송에 참여하지 못해 면책 주장을 하지 못했던 것이다. 이후 양수금 청구 소송의 확정 판결을 기초로 B 씨가 강제집행을 하려고 하자, A 씨는 2016년 6월 B 씨를 상대로 "2011년 받은 면책결정에 의해 B 씨에 대한 채무가 면책됐다"며 "양수금 소송에 참여하지 못해 판결이 났을 뿐이니 구제해달라"며 청구이의 소송을 제기했다.1,2심은 "이미 확정된 판결에 기초한 강제집행을 막기 위한 채무자의 청구이의의 소는 확정판결의 변론종결 시 이후에 발생한 사유로만 제기할 수 있는데, A 씨가 주장하는 사유는 양수금 확정판결의 변론종결 시점인 2014년 12월 이전의 면책이어서 A 씨의 청구이의의 소를 받아들일 수 없다"면서 "이를 받아들이는 것은 기판력에 저촉되는 것"이라며 원고패소 판결했다.원칙적으로 확정판결의 변론종결 전에 발생한 사유를 이유로 확정판결의 집행을 막는 청구이의의 소를 제기할 수 없지만 '변론종결 후' 면책된 경우라면 청구이의 사유로 허용된다. 이 사건 상고심에서는 청구이의의 소에서 청구이의 사유는 실체적 채권의 소멸, 감소 사유를 예정한 것이지만 면책결정은 실체적 채권의 소멸, 감소사유가 아니라 책임의 소멸이라는 측면에서 다른 청구이의 사유와 달리 변론종결 전후에 발생했는지와 관계 없이 청구이의사유로 인정해야 하는 것은 아닌지가 쟁점이 됐다.재판부는 "파산선고 후 면책결정이 확정되면 개인채무자의 파산채권자에 대한 채무는 그대로 존속하지만 책임은 소멸하므로 개인채무자의 파산채권자에 대한 책임은 파산선고 당시에 개인채무자가 가진 재산 한도로 한정된다"며 "채무는 존속하지만 책임만 이러한 범위로 제한돼 개인채무자는 파산선고 이후에 취득하는 재산으로 변제할 책임은 지지 않는다"고 밝혔다.이어 "파산채권자가 개인채무자를 상대로 채무 이행을 청구하는 소송에서 면책결정에 따라 발생한 책임 소멸은 소송물인 채무의 존부나 범위 확정과는 직접적인 관계가 없다"면서 "개인채무자가 면책 사실을 주장하지 않는 경우에는 책임 범위나 집행력 문제가 현실적인 심판대상으로 등장하지도 않아 주문이나 이유에서 그에 관한 아무런 판단이 없게 된다. 이런 경우 면책결정으로 인한 책임 소멸에 관해서는 기판력이 미치지 않으므로, 개인채무자에 대한 면책결정이 확정됐는데도 파산채권자가 제기한 소송의 사실심 변론종결 시까지 그 사실을 주장하지 않는 바람에 면책된 채무 이행을 명하는 판결이 선고돼 확정된 경우에도 특별한 사정이 없는 한 개인채무자는 그 후 면책된 사실을 내세워 청구이의의 소를 제기할 수 있다"고 설명했다.또 "면책결정이 확정됐는데도 면책된 채무 이행을 명하는 판결이 확정된 경우 개인채무자가 확정판결에 관한 소송에서 단지 면책 주장을 하지 않았다는 이유만으로 청구이의의 소를 통해 면책된 채무에 관한 확정판결의 집행력을 배제하는 것을 허용하지 않는다면 부당한 결과를 초래한다"면서 "이미 면책결정을 통해 강제집행 위험에서 벗어난 개인채무자로 하여금 그 집행을 다시 수인하도록 하는 것은 면책제도의 취지에 반하고 확정된 면책결정의 효력을 잠탈하는 결과를 가져올 수 있을 뿐만 아니라 확정판결에 관한 소송에서 개인채무자의 면책 주장 여부에 따라 개인채무자가 일부 파산채권자에 대해서만 파산절차에 의한 배당 외에 추가로 책임을 부담하게 된다면 파산채권자들 사이의 형평을 해치게 돼 집단적, 포괄적으로 채무를 처리하면서 개인채무자의 재기를 지원하는 개인파산 및 면책제도의 취지에도 반하게 되기 때문"이라고 덧붙였다.대법원 관계자는 "어떤 판결에 대해 강제집행해서는 안된다고 청구하는 청구이의의 소는 그 사유가 변론종결 이후에 발생한 사유여야만 허용되는 게 원칙이지만, 예외적으로 청구이의사유가 면책결정인 경우에는 그 면책결정이 변론종결 전에 발생한 경우에도 청구이의가 허용된다는 취지"라고 말했다.법률신문 참조https://www.lawtimes.co.kr/Case-curation/181019</div>
            <div class="date">2023-06-16</div>
        </a>
                <a href="/kor/community/legalInfo.php?m=v&idx=55&pNo=1&code=law" class="con_bx">
            <div class="subject">대법원, "부재중 전화라도 전화 계속 걸명 스토킹에 해당한다" 첫 판결</div>
            <div class="txt">[대법원 판결]상대방에게 여러 차례 부재중 전화를 남긴 것도 '스토킹'에 해당한다는 대법원 첫 판단.대법원 형사3부(주심 이흥구 대법관), 2022도12037(2023년 5월 18일 판결)[판결 결과]스토킹범죄의처벌등에관한법률위반 등 혐의로 기소된 A 씨에게 징역 4개월을 선고하고 스토킹 치료프로그램 이수 40시간을 명령한 원심을 파기하고 부산지법으로 환송.[쟁점]전화를 걸었으나 피해자가 이를 수신하지 않아 피해자의 휴대전화에 부재중 전화 문구 등이 남은 경우, 이러한 행위를 '전화 또는 정보통신망을 이용해 글을 도달하게 한 행위'로 포섭해 스토킹처벌법 위반죄로 처벌할 수 있는지 여부[사실관계와 1,2심]A 씨는 2021년 10월 말 경 피해자 B 씨가 자신의 휴대전화 번호를 차단한 사실을 알고, 다른 사람의 휴대전화를 이용하거나 발신자를 알 수 없게 하는 방법 등으로 피해자에게 수차례 전화했다. A 씨는 B 씨의 의사에 반해 정당한 이유 없이 정보통신망을 이용해 피해자에게 글, 말을 도달하게 해 불안감 또는 공포심을 일으켰다는 이유등으로 스토킹처벌법 위반죄 등으로 기소됐다.1심은 A 씨의 혐의를 전부 유죄로 판단해 징역 4개월, 스토킹 치료프로그램 이수 40시간을 선고했다.2심은 1심을 직권파기하고 일부 혐의를 유죄로 판단해 징역 4개월 등을 선고했다. 2심은 "A 씨가 다른 사람의 휴대전화로는 단 1번 전화를 걸었을 뿐이고 통화 내용도 밝혀지지 않았고, A 씨가 전화를 걸어 B 씨의 휴대전화에서 벨소리가 울렸더라도 B 씨가 전화를 받지 않았다면 A 씨가 정보통신망을 통해 B 씨에게 '음향'을 보냈다고 할 수 없고, B 씨의 휴대전화에 표시된 '부재중 전화' 문구는 전화기 자체의 기능에서 나오는 표시에 불과해 A 씨가 보낸 '글'이나 '부호'에 해당한다고 보기 어렵다"고 판단했다.[대법원 판단(요지)]"스토킹처벌법의 문언, 입법목적 등을 종합하면, A 씨가 전화를 걸어 B 씨의 휴대전화에 벨소리가 울리게 하거나 부재중 전화 문구 등이 표시되도록 하여 상대방에게 불안감이나 공포심을 일으키는 행위는 실제 전화통화가 이루어졌는지 여부와 상관없이 쟁점 조항이 정한 스토킹행위에 해당한다고 볼 수 있다.A 씨가 B 씨에게 전화를 걸어 무선 기지국 등에 'A 씨가 B 씨와 전화통화를 원한다'라는 내용이 담긴 정보의 전파를 발신·송신하고, 그러한 정보의 전파가 기지국, 교환기 등을 거쳐 B 씨의 휴대전화에 수신된 후 'A 씨가 B 씨와 전화통화를 원한다' 또는 'A 씨가 B 씨와 전화통화를 원했다'는 내용의 정보가 벨소리, 발신번호 표시, 부재중 전화 문구 표시로 변형되어 B 씨의 휴대전화에 나타났다면, A 씨가 전화 또는 정보통신망을 도구로 사용해 A 씨의 전화기에서의 출발과 장소적 이동을 거친 음향(벨소리), 글(발신번호 표시, 부재중 전화 문구 표시)을 B 씨의 휴대전화에 '도달'하게 한 것으로 평가할 수 있다.A 씨가 전화를 걸어 B 씨의 휴대전화에 벨소리가 울리게 하거나 부재중 전화 문구가 표시되게 했는데도 B 씨가 전화를 수신하지 않았다는 이유만으로 스토킹행위에서 배제하는 것은 우연한 사정에 의하여 처벌 여부가 좌우되도록 하고 처벌 범위도 지나치게 축소시켜 부당하다.A 씨가 B 씨와 전화통화를 의욕하고 전화를 걸었거나 B 씨의 휴대전화 상태나 전화수신 여부를 알 수 없었다고 하더라도 A 씨로서는 적어도 미수신시 피해자의 휴대전화에서 벨소리나 진동음이 울리거나 부재중 전화 문구 등이 표시된다는 점을 알 수 있었고 그러한 결과의 발생을 용인하는 의사도 있었다고 볼 수 있으므로 미필적 고의는 있었다고 봐야 한다."[대법원 관계자]"전화를 걸어 피해자의 휴대전화에 벨소리가 울리게 하거나 부재중 전화 문구 등이 표시되도록 해 상대방에게 불안감이나 공포심을 일으키는 행위는 실제 전화통화가 이루어졌는지 여부와 상관없이 스토킹처벌법이 정한 스토킹행위에 해당한다고 최초로 설시한 판결이다."법률신문 참조https://www.lawtimes.co.kr/Case-curation/187934</div>
            <div class="date">2023-06-16</div>
        </a>
                <a href="/kor/community/legalInfo.php?m=v&idx=51&pNo=1&code=law" class="con_bx">
            <div class="subject">대법원, "미등기 임대인과 전세 계약 후 집주인 바뀌었어도 세입자 임차권은 보호해야" </div>
            <div class="txt">[대법원 판결]미등기 주택이더라도 적법한 임대권한이 있는 임대인과 전세계약을 맺은 임차인은 추후 매매계약 해제로 집주인이 바뀌더라도 새 집주인에게 대항력을 유지할 수 있다는 대법원 판단.대법원 민사1부(주심 노태악 대법관), 2023다201218(2023년 5월 18일 판결)[판결 결과]세입자 A 씨가 집주인과 공인중개사 등을 상대로 낸 보증금반환 청구 소송에서 원고패소 판결한 원심을 파기하고 사건을 수원지법으로 환송.[쟁점]△매수인(B 씨)에게 주택에 대한 적법한 임대권한이 있는지 여부 △적법한 임대권한 있는 미등기 매수인으로부터 주택을 임차해 주택임대차보호법상 대항요건을 갖춘 임차인인 A 씨가 매매계약이 해제된 후 주택 양수인에 대해 대항할 수 있는지 여부[사실관계와 1,2심]B 씨는 경기 광주시의 5층짜리 공동주택을 매수하기로 하고 2016년 11월 건축주와 분양계약을 체결했다. 이때 '잔금일 전에 임대가 이뤄지면 임대 나간 세대는 임차인 입주와 동시에 잔금을 치르고 B 씨 앞으로 소유권을 이전한다'고 약정했다.2017년 10월 B 씨는 건물의 한 호에 대해 A 씨와 2020년 3월까지 기간으로 임대차 계약을 체결했다. 임대차계약서에는 '이 건물을 매수하는 B 씨를 임대인으로 해 계약을 진행하고 건축주에서 매수인에게 등기이전되는 일체의 과정은 공인중개사가 책임지고 진행한다'는 특약 사항이 포함됐다.그런데 B 씨가 잔금을 제때 치르지 못하자, 건축주는 분양 계약을 해제하고 B 씨에게 퇴거를 요구했다. 건축주는 새로운 매수인에게 A 씨가 임차한 호를 팔았다.A 씨는 공인중개사와 건축주, 새 매수인을 상대로 보증금을 돌려달라며 2020년 5월 소송을 냈다. 새 매수인은 A 씨를 상대로 "무단 거주 기간만큼 월세를 지급하라"며 반소를 냈다.1,2심은 공인중개사가 A 씨에게 보증금을 돌려주고 A씨는 새 매수인이 집을 산 시점부터 계산한 월세를 지급하라고 판결했다.[대법원 판단(요지)]"매매계약의 이행으로 매매목적물을 인도받은 매수인은 그 물건을 사용·수익할 수 있는 지위에서 타인에게 적법하게 임대할 수 있다. 이러한 지위에 있는 매수인으로부터 매매계약이 해제되기 전에 매매목적물인 주택을 임차하여 주택의 인도와 주민등록을 마침으로써 주택임대차보호법 제3조 제1항에 따른 대항요건을 갖춘 임차인은 민법 제548조 제1항 단서의 규정에 따라 계약해제로 인하여 권리를 침해받지 않는 제3자에 해당한다. 따라서 임대인의 임대권원의 바탕이 되는 계약의 해제에도 불구하고 자신의 임차권을 새로운 소유자에게 대항할 수 있다.B 씨는 매도인과 주택 매매계약을 체결하면서 매도인으로부터 주택에 관한 임대권한을 부여받아 A 씨와 임대차계약을 체결하고, 부동산 중개인을 통해 매도인의 대리인에게 매매잔금의 일부를 지급하고 매매계약의 이행으로서 이 사건 주택을 인도받았다고 볼 수 있으므로 B 씨는 적법한 임대권한을 가진 것으로 볼 여지가 있다.A 씨는 적법한 임대권한을 가지고 있고 매매 목적물인 이 사건 주택을 인도받은 매수인 B 씨로부터 매매계약이 해제되기 전에 위 주택을 임차하여 주택의 인도와 주민등록을 마침으로써 주택임대차보호법 제3조 제1항에 따른 대항요건을 갖췄다. 따라서 A 씨는 민법 제548조 제1항 단서의 규정에 따라 매수인과 매도인 사이의 계약해제로 인해 권리를 침해받지 않는 제3자에 해당한다. A 씨는 매매계약의 해제에도 불구하고 자신의 임차권을 주택 양수인인 새 집주인에게 대항할 수 있다."[대법원 관계자]"적법한 임대권한이 있는 미등기 매수인으로부터 주택을 임차해 주택임대차보호법상 대항요건을 갖춘 임차인은 이후 매매계약이 해제되었더라도 민법 제548조 제1항 단서의 규정에 따라 계약해제로 인해 권리를 침해받지 않는 제3자로서 보호되므로 임대인 지위를 승계한 주택 양수인에 대하여 그 임차권을 대항할 수 있다고 함으로써, 기존 법리를 재확인한 사례이다."[승소 대리인]임차인 측 소송대리인 법무법인 삼양 황귀빈 변호사(대한변호사협회등록 부동산 전문 변호사)"최근 전세사기 등이 사회적 문제로 대두되는 상황에서 소위 '동시진행' 신축빌라 분양 관련 분쟁 사건을 비롯한 관련 임대차 분쟁 및 실무에 큰 영향을 미칠 것으로 기대한다."&lt;법률신문 참조&gt;  ﻿https://www.lawtimes.co.kr/Case-curation/188233</div>
            <div class="date">2023-06-16</div>
        </a>
                <a href="/kor/community/legalInfo.php?m=v&idx=45&pNo=1&code=law" class="con_bx">
            <div class="subject">서울회생법원 보도자료(서울회생법원, 주식 또는 가상화폐 투자 실패를 겪은 채무자를 위한 지원방안)</div>
            <div class="txt"></div>
            <div class="date">2023-06-15</div>
        </a>
            </div>
		
	</div>


<script>
	$('#spart').on('change', function(){
		$('form#bd_search').submit();
	});

    $('select#sitem').val('');
    $('#btn_search').on('click', function () {
        $('form#bd_search').submit();
    });
</script>

                				                			</div>
                		</div>
		            </div>
                </div>
	        </div><!-- //contents -->
        </div><!-- //container -->

		<footer id="footer" class="indexNum_">
			<div class="top_bx">
				<div class="f_inner">
					<div class="l_bx">
						<span class="ttl">상담문의</span>
						<!-- <p>
    							<strong>1544-0904(대표번호) / 042-721-0608(회생파산) / 042-721-0606(송무)</strong>업무시간 09:00 ~ 18:00 (주말, 공휴일 휴무)
    						</p> -->
						<p>
							<strong>대표번호 1544-0904</strong>
							<strong>02-6954-0478(서울회생파산) / 02-6954-0378(서울송무)</strong>
							<strong>042-721-0608(대전회생파산) / 042-721-0606(대전송무)</strong>
						<p>업무시간 09:00 ~ 18:00 (주말, 공휴일 휴무)</p>
						</p>
					</div>
					<div class="r_bx">
						<span class="ttl">glory sns</span>
						<ul class="sns_bx">
							<li class="instagram"><a href="https://www.instagram.com/glory_lawfirm/?igshid=MzRlODBiNWFlZA%3D%3D" target="_blank">instagram</a></li>
							<li class="youtube"><a href="#none" >youtube</a></li>
							<li class="facebook"><a href="#none" >facebook</a></li>
						</ul>
					</div>
				</div>
			</div>
			<div class="btm_bx">
				<div class="f_inner">
					<img src="../images/common/logo.png" class="logo" alt="법무법인 글로리">
					<ul class="link_bx">
						<li><a href="../company/intro.php">법인소개</a></li>
						<li><a href="../policy/privacy.php">개인정보처리방침</a></li>
						<li><a href="../business/areas.php">업무영역</a></li>
						<li class="dotN"><a href="../review/list.php">후기</a></li>
													<li><a class="quick_btn">상담신청</a></li>
												<li><a href="../community/notice.php">커뮤니티</a></li>
					</ul>
					<!-- <ul class="info_bx">
    						<li>상호 : 법무법인 글로리</li>
    						<li>사업자등록번호 : 604-86-02992</li>
    						<li>대표변호사 : 이아무</li>
    						<li>주소 : 대전광역시 서구 둔산중로 78번길 26, 민석타워 3층 301호</li>
    						<li>대표번호 : 1544-0904(대표번호) / 042-721-0608(회생파산) / 042-721-0606(송무)</li>
    						<li>팩스 : 042-721-0707</li>
    						<li>이메일 : glory@glorylawfirm.kr</li>
    					</ul> -->
					<ul class="info_bx">
						<li>상호 : 법무법인 글로리</li>
						<li>사업자등록번호 : 604-86-02992</li>
						<li>대표변호사 : 이아무</li>
						<li>대표번호 : 1544-0904</li>
						<li>이메일 : glorylawfirm@daum.net</li>
						<li>서울본사 : 서울특별시 강남구 테헤란로8길 13, 9층 (역삼동, WD빌딩) <span>| TEL : 02-6954-0478(회생파산), 02-6954-0378(송무)</span> <span>| FAX : 02-6954-0878</span></li>
						<li>대전지점 : 대전광역시 서구 둔산중로 78번길 26, 민석타워 3층 301호 <span>| TEL : 042-721-0608(회생파산), 042-721-0606(송무)</spaan> <span>| FAX : 042-721-0707</span></li>
					</ul>
					<p class="btm_txt">Copyright © 2023 Law Firm Glory. All Rights Reserved.</p>
				</div>
			</div>
		</footer>
		</div><!-- //wrap -->

		<script type="text/javascript">
			AOS.init({
				once: true,
				startEvent: 'load',
				disable: function() {
					//var maxWidth = 1024;
					//return window.innerWidth < maxWidth;
				}
			});
								</script>

		
		<!-- 공통 적용 스크립트 , 모든 페이지에 노출되도록 설치. 단 전환페이지 설정값보다 항상 하단에 위치해야함 -->
		<script type="text/javascript" src="//wcs.naver.net/wcslog.js"> </script>
		<script type="text/javascript">
			if (!wcs_add) var wcs_add = {};
			wcs_add["wa"] = "s_35d04fef83bb";
			if (!_nasa) var _nasa = {};
			if (window.wcs) {
				wcs.inflow();
				wcs_do(_nasa);
			}
		</script>


		</body>

		</html>